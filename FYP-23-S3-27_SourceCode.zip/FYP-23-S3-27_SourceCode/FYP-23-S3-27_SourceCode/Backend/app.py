# app.py
# Required Imports
import os
from flask_cors import CORS
from flask import Flask, request, Response, jsonify
from api.controller.user import user_routes
from api.controller.listing import listing_routes


import logging

# Initialize Flask App
app = Flask(__name__)
CORS(
    app,
    supports_credentials=True,
    origins=[
        "http://127.0.0.1:5173",
        "http://localhost:5173",
        "https://top-care-fashion.web.app",
        "https://us-central1-top-care-fashion.cloudfunctions.net",
    ],
)
logging.getLogger("flask_cors").level = logging.DEBUG
app.register_blueprint(user_routes, url_prefix="/user")
app.register_blueprint(listing_routes, url_prefix="/listing")
# app.register_blueprint(query_routes, url_prefix="/query")

# app.run(debug=True)
