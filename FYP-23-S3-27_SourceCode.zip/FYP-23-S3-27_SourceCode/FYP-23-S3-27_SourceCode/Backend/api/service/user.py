from firebase import auth, db, pb_auth, exceptions, pb_apiKey
from api.model.user import User
from google.cloud.firestore_v1.base_query import FieldFilter
from os import environ
import requests


user_ref = db.collection("accountDetails")

# FOR ALL BACKEND METHODS
# Whereever possible, take in model object (ie. Listing, User object),  
# For one object, return dict
# For multiple objects, return list[dict]
# For functions like delete, return string indicating success/fail

# create new user
def create_user(user: User) -> str:
    try:
        user_auth_fields = user.get_firebase_auth_fields()
        user_auth_details = auth.create_user(**user_auth_fields)
        user_ref.document(user_auth_details.uid).set(user.get_firestore_fields())
        return "Success"
    except Exception as err:
        print(f"{type(err)}: {err}")
        raise


def get_details(user: User) -> dict:
    user_auth_details = auth.get_user(user.id)
    user_details = user_auth_details._data
    user_details["display_name"] = user_details.pop("displayName")
    user_db_details_doc = user_ref.document(user.id).get()
    user_db_details = user_db_details_doc.to_dict()
    user_details["id"] = user_details.pop("localId")
    user_details.update(user_db_details)
    return User.from_dict(user_details).to_dict()


# login
def sign_in(user: User) -> dict:
    user_details = pb_auth.sign_in_with_email_and_password(user.email, user.password)
    print(user_details)
    user_details["id"] = user_details.pop("localId")
    user_details["id_token"] = user_details.pop("idToken")
    user_details["refresh_token"] = user_details.pop("refreshToken")
    user_db_details_doc = user_ref.document(user_details["id"]).get()
    user_db_details = user_db_details_doc.to_dict()
    user_details.update(user_db_details)
    print(user_details)
    # Convert all details into User object
    # Constructor will ignore any properties not specified in the constructor
    return User.from_dict(user_details).to_dict()


def sign_out(user: User) -> str:
    try:
        auth.revoke_refresh_tokens(user.id)
        return "Success"
    except ValueError as err:
        return "User id is invalid"
    except exceptions.FirebaseError as err:
        return "An error occurred while signing out."


def get_all() -> list[dict]:
    """pages = auth.list_users()"""
    users = []
    """     while page:
            for user_auth_details in page.users:
                user_data = user_auth_details._data
                user_data["id"] = user_data.pop("localId")
                get_user_db_details_query = user_ref.where(
                    filter=FieldFilter("user_id", "==", user_data["id"])
                ).limit_to_last(1)
                user_db_details = get_user_db_details_query.get()[0].to_dict()
                user_data.update(user_db_details)
                users.append(User.from_dict(user_data).to_dict())
            page = page.get_next_page() """

    for user_auth_details in auth.list_users().iterate_all():
        user_details = user_auth_details._data
        user_details["display_name"] = user_details.pop("displayName")
        user_details["id"] = user_details.pop("localId")
        user_db_details_doc = user_ref.document(user_details["id"]).get()
        user_db_details = user_db_details_doc.to_dict()
        user_details.update(user_db_details)
        users.append(User.from_dict(user_details).to_dict())
    return users


def update_password(user: User) -> str:
    try:
        auth.update_user(uid=user.id, password=user.password)
        return "Success"
    except ValueError as err:
        return "User id or password is invalid"
    except exceptions.FirebaseError as err:
        return "An error occurred while updating the user's password."


def update_user(user: User) -> str:
    try:
        # Update details in firebase authentication
        user_auth_details = user.get_firebase_auth_fields()
        user_auth_details.pop("localId")
        print(user_auth_details)
        auth.update_user(uid=user.id, **user_auth_details)
        # Update detials in firestore
        user_ref.document(user.id).update(user.get_firestore_fields())
        return "Success"
    except ValueError as err:
        return "User id or values are invalid"
    except exceptions.FirebaseError as err:
        return "An error occurred while updating the user's details."


def send_password_reset_email(user: User) -> str:
    email = user.email
    link = auth.generate_password_reset_link(email)
    dictToSend = {"requestType": "PASSWORD_RESET", "email": f"{user.email}"}
    print(pb_apiKey)
    response = requests.post(
        f"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={pb_apiKey}",
        json=dictToSend,
    )
    if response.status_code == 200:
        return response.json()
    return {"message": "Something went wrong"}
