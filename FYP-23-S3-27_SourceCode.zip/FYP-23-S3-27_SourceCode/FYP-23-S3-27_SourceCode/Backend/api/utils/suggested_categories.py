from transformers import (
    pipeline,
    AutoProcessor,
    AutoModelForZeroShotImageClassification,
)
from PIL import Image
import requests
import torch

checkpoint = "patrickjohncyh/fashion-clip"
model = AutoModelForZeroShotImageClassification.from_pretrained(checkpoint).cpu()
processor = AutoProcessor.from_pretrained(checkpoint)
""" processor.save_pretrained("./processors/fashion-clip")
model.save_pretrained("./models/fashion-clip") """

clothing_classes_with_candidate_labels = {
    "category": {
        "topwear": "topwear",
        "bottomwear": "bottomwear",
        "footwear": "footwear",
        "outerwear": "outerwear",
        "dress": "dress",
        "jacket": "outerwear",
        "shorts": "bottomwear",
        "cardigan": "outerwear",
    },
    "style": ["formal wear", "casual wear", "smart casual wear"],
    "colour": [
        "beige",
        "black",
        "blue",
        "brown",
        "gold",
        "green",
        "grey",
        "multicoloured",
        "orange",
        "pink",
        "purple",
        "red",
        "silver",
        "turquoise",
        "white",
        "yellow",
    ],
}


def predict_single_class(image: Image.Image, candidate_labels):
    inputs = processor(
        images=image, text=candidate_labels, return_tensors="pt", padding=True
    )
    with torch.no_grad():
        outputs = model(**inputs)
    logits = outputs.logits_per_image[0]
    probs = logits.softmax(dim=-1).numpy()
    scores = probs.tolist()
    result = [
        {"score": score, "label": candidate_label}
        for score, candidate_label in sorted(
            zip(probs, candidate_labels), key=lambda x: -x[0]
        )
    ]
    print(result)
    return result[0]["label"]


def predict_multi_class(image: Image.Image, classes_with_candidate_labels: dict):
    result = {}
    for label_class, candidate_labels in classes_with_candidate_labels.items():
        if isinstance(candidate_labels, dict):
            result[label_class] = candidate_labels[
                predict_single_class(image, list(candidate_labels.keys()))
            ]
        else:
            result[label_class] = predict_single_class(image, candidate_labels)
    return result
