# Import necessary libraries
import pandas as pd
from lightfm import LightFM
from lightfm.data import Dataset
from firebase_admin import credentials, firestore, storage
import firebase_admin
from PIL import Image
import requests
import torch
from transformers import ConvNextImageProcessor, ResNetModel
from sklearn.decomposition import PCA
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
import numpy as np
import pickle as pk
from firebase import db, bucket
from io import BytesIO
import ast


def load_embeddings(file_path: str = "embeddings/embeddings_df.pkl") -> pd.DataFrame:
    embeddings_blob = bucket.blob(file_path)
    file_bytes = embeddings_blob.download_as_bytes()
    embeddings_df = pk.loads(file_bytes)
    return embeddings_df


def load_index(file_path: str = "annoy/index.pkl") -> pd.DataFrame:
    index_blob = bucket.blob(file_path)
    file_bytes = index_blob.download_as_bytes()
    index = pk.loads(file_bytes)
    return index


# Function to load all listings and their embeddings
def load_listings_with_embeddings(file_path: str = "embeddings/embeddings_df.pkl"):
    try:
        # Reference to the Firestore "listings" collection
        listings_ref = db.collection("listings")
        # Retrieve all documents from the "listings" collection
        documents = listings_ref.stream()
        listings_data = [
            {"id": document.id, **document.to_dict()} for document in documents
        ]
        listing_df = pd.DataFrame(listings_data)

        # Download the embeddings file from Firebase Storage
        embeddings_blob = bucket.blob(file_path)
        file_bytes = embeddings_blob.download_as_bytes()
        embeddings_df = pk.loads(file_bytes)

        # Merge the two dictionaries
        merged_df = pd.merge(listing_df, embeddings_df, on="id")

        return merged_df

    except Exception as e:
        print(f"Error: {e}")
        return None


def update_or_add_embedding(
    listing_id: str,
    new_embedding: list,
    file_path: str = "embeddings/embeddings_df.pkl",
) -> str:
    try:
        # Download the embeddings file from Firebase Storage
        embeddings_blob = bucket.blob(file_path)
        file_bytes = embeddings_blob.download_as_bytes()
        embeddings_df = pk.loads(file_bytes)

        # Update or add new embedding for the specific ID
        # If the listing_id exists, update the embedding; otherwise, add a new row
        if listing_id in embeddings_df["id"].values:
            embeddings_df.loc[embeddings_df["id"] == listing_id, "embeddings"] = [
                new_embedding
            ]
        else:
            new_row = pd.DataFrame(
                {"listing_id": [listing_id], "embeddings": [new_embedding]}
            )
            embeddings_df = embeddings_df.concat(
                [embeddings_df, new_row], ignore_index=True
            )

        with embeddings_blob.open("wb") as file:
            pk.dump(embeddings_df, file)

        return f"Embedding for listing ID {listing_id} updated or added successfully."

    except Exception as e:
        print(f"Error: {e}")

        return f"Error: {e}"


# Function to save embeddings in Firebase Cloud Storage
def save_embeddings_to_storage(
    embeddings: pd.DataFrame,
    file_path: str = "embeddings/embeddings_df.pkl",
):
    try:
        # Save embeddings as a file in Firebase Cloud Storage
        embedding_blob = bucket.blob(file_path)
        with embedding_blob.open("wb") as file:
            pk.dump(embeddings, file)

        return f"Embedding saved to {file_path} in Firebase Cloud Storage."

    except Exception as e:
        return f"Error: {e}"


# Function to save embeddings in Firebase Cloud Storage
def save_index_to_storage(
    index,
    file_path: str = "annoy/index.pkl",
):
    try:
        # Save embeddings as a file in Firebase Cloud Storage
        embedding_blob = bucket.blob(file_path)
        with embedding_blob.open("wb") as file:
            pk.dump(index, file)
        return f"Embedding saved to {file_path} in Firebase Cloud Storage."

    except Exception as e:
        return f"Error: {e}"


def load_from_bytes(fileobj):
    while True:
        try:
            yield pickle.load(fileobj)
        except EOFError:
            break


def load_embeddings_and_index(
    file_path: str = "pickles/embeddings_and_index.pkl",
) -> pd.DataFrame:
    embeddings_blob = bucket.blob(file_path)
    file_bytes = embeddings_blob.download_as_bytes()
    files = pk.loads(file_bytes)

    embeddings_df = files[0]
    index = files[1]
    print(files)
    return embeddings_df, index
