import firebase_admin
from firebase_admin import credentials, firestore
from PIL import Image
import torch
from annoy import AnnoyIndex
from transformers import (
    CLIPModel,
    AutoImageProcessor,
    ViTFeatureExtractor,
    ViTModel,
    AutoFeatureExtractor,
    ResNetModel,
    ConvNextImageProcessor,
)
import pickle as pk
import numpy
from sklearn.decomposition import PCA

import os

checkpoint = "microsoft/resnet-50"
cache_dir = "/app/cache"

# Now pass cache_dir to from_pretrained
feature_extractor = ConvNextImageProcessor.from_pretrained(
    checkpoint
)
""" feature_extractor.save_pretrained("./feature_extractors/resnet-50") """
model = ResNetModel.from_pretrained(checkpoint)
""" model.save_pretrained("./models/resnet-50") """


def extract_embeddings_from_image(image: Image.Image):
    inputs = feature_extractor(images=image, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
        embeddings = outputs.last_hidden_state
    embeddings_flat = embeddings.view(embeddings.shape[0], -1)
    embeddings_as_numpy_array = embeddings_flat.detach().numpy()
    """ reduced_embeddings = pca.transform(embeddings_flat) """
    return embeddings_as_numpy_array.flatten().tolist()


def extract_embeddings_from_images(images: list[Image.Image]):
    inputs = feature_extractor(images=images, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
        embeddings = outputs.last_hidden_state
    embeddings_flat = embeddings.view(embeddings.shape[0], -1)
    embeddings_as_numpy_array = embeddings_flat.detach().numpy()
    """ reduced_embeddings = pca.fit_transform(embeddings_as_numpy_array) """
    return [record.flatten().tolist() for record in embeddings_as_numpy_array]
