# Import necessary libraries
import pandas as pd
from lightfm import LightFM
from lightfm.data import Dataset
from lightfm.evaluation import precision_at_k, auc_score
from PIL import Image
import requests
import torch
from transformers import (
    CLIPModel,
    AutoImageProcessor,
    ResNetModel,
    ConvNextImageProcessor,
)
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from firebase import db, bucket
from api.utils.resnet50 import extract_embeddings_from_image
import pickle as pk
import api.utils.embeddings_storage as es
from datetime import datetime

pca = PCA(n_components=100)


# Load data from Firestore into pandas dataframe
def load_data_from_firestore(db):
    listing_docs = db.collection("listings").get()
    account_docs = db.collection("accountDetails").where("role", "==", "customer").get()

    listing_data = [{"id": doc.id, **doc.to_dict()} for doc in listing_docs]
    account_data = [{"id": doc.id, **doc.to_dict()} for doc in account_docs]

    listing_df = pd.DataFrame(listing_data)
    account_df = pd.DataFrame(account_data)

    return listing_data, account_data


# Preprocess listings and generate embeddings
def preprocess_listings(listing_df):
    copy_df = listing_df.copy()
    copy_df["imageUrl"] = copy_df["imageUrls"].apply(lambda photo_urls: photo_urls[0])
    copy_df["image"] = copy_df["imageUrl"].apply(
        lambda url: Image.open(requests.get(url, stream=True).raw).convert("RGB")
    )
    copy_df["embeddings"] = copy_df["image"].apply(extract_embeddings_from_image)

    pca = PCA(n_components=30)
    pca.fit(copy_df["embeddings"].to_list())
    copy_df["embeddings"] = copy_df["embeddings"].apply(
        lambda photo_embedding: pca.transform([photo_embedding])[0]
    )
    features = copy_df[
        [
            "category",
            "style",
            "section",
            "colour",
        ]
    ]
    encoder = OneHotEncoder(sparse=False)
    one_hot = encoder.fit_transform(features)
    combined_features = np.concatenate(
        [copy_df["embeddings"].tolist(), one_hot], axis=1
    )

    scaler = MinMaxScaler()
    embeddings = scaler.fit_transform(combined_features)
    return copy_df, embeddings


def preprocess_listings_with_embeddings(listing_df):
    copy_df = listing_df.copy()
    pca = PCA(n_components=30)
    pca.fit(copy_df["embeddings"].to_list())
    copy_df["embeddings"] = copy_df["embeddings"].apply(
        lambda photo_embedding: pca.transform([photo_embedding])[0]
    )

    features = copy_df[
        [
            "category",
            "style",
            "section",
            "colour",
        ]
    ]
    encoder = OneHotEncoder(sparse=False)
    one_hot = encoder.fit_transform(features)
    combined_features = np.concatenate(
        [copy_df["embeddings"].tolist(), one_hot], axis=1
    )

    scaler = MinMaxScaler()
    embeddings = scaler.fit_transform(combined_features)
    copy_df = copy_df.reset_index(drop=True)
    return copy_df, embeddings


# Build LightFM model
def build_lightfm_model(interactions, item_features, user_features):
    model = LightFM(loss="logistic", no_components=30)
    model.fit(
        interactions,
        item_features=item_features,
        user_features=user_features,
        epochs=1000,
    )
    return model


def calculate_age_and_bin(df):
    # Convert Firestore timestamp to datetime
    df["date"] = pd.to_datetime(df["birthday"], unit="s")

    # Calculate age
    df["age"] = datetime.now().year - df["date"].dt.year

    # Define age bins
    bins = [0, 20, 31, 41, 51, 120]
    labels = ["<20", "20-30", "31-40", "41-50", "50+"]

    # Bin ages
    df["age_group"] = pd.cut(df["age"], bins=bins, labels=labels, right=False)

    return df


# Get recommended listings for a user ID
def get_recommended_listings(user_id, model, dataset, listing_data):
    item_ids = np.arange(dataset.interactions_shape()[1])
    scores = model.predict(dataset.mapping()[0][user_id], item_ids)
    inv_map = {v: k for k, v in dataset.mapping()[2].items()}
    results = []
    # recommendations = listing_df.loc[np.argsort(-scores)]
    for row_no in np.argsort(-scores).tolist():
        print(row_no)
        results.append(listing_data[inv_map[row_no]])
    return results


def create_interaction_data(listing_df):
    interaction_data = []
    for _, row in listing_df.iterrows():
        saved_by = row.get("saved_by")
        if not isinstance(saved_by, list):
            continue
        for user in saved_by:
            interaction_data.append((user, row.get("id"), 2))
    return interaction_data


# Flask endpoint function
""" @listing_routes.route("/recommended/<id>", methods=["POST", "PUT"]) """


# Load pickled LightFM model for recommendation
def load_lightfm_model(model_pathname):
    # Download the pickled model from Firebase Cloud Storage
    blob = bucket.blob(f"{model_pathname}")
    file_bytes = blob.download_as_bytes()
    model = pk.loads(file_bytes)
    return model


def load_lightfm_dataset_and_model(path):
    blob = bucket.blob(f"{path}")
    file_bytes = blob.download_as_bytes()
    model, dataset = pk.loads(file_bytes)
    return model, dataset


# Save LightFM model as a pickled file
def save_to_storage(data, file_path):
    try:
        # Save embeddings as a file in Firebase Cloud Storage
        recommender_blob = bucket.blob(file_path)
        with recommender_blob.open("wb") as file:
            pk.dump(data, file)

        return (
            f"Recommender and dataset saved to {file_path} in Firebase Cloud Storage."
        )

    except Exception as e:
        return f"Error: {e}"


# Save LightFM model as a pickled file
def save_dataset_and_model_to_storage(model, dataset, file_path):
    try:
        # Save embeddings as a file in Firebase Cloud Storage
        recommender_blob = bucket.blob(file_path)
        with recommender_blob.open("wb") as file:
            pk.dump((model, dataset), file)

        return (
            f"Recommender and dataset saved to {file_path} in Firebase Cloud Storage."
        )

    except Exception as e:
        return f"Error: {e}"


def preprocess_users(accounts_df: pd.DataFrame):
    copy_df = accounts_df[["id", "gender", "birthday"]]
    copy_df = calculate_age_and_bin(copy_df)
    copy_df = copy_df.dropna()
    features = copy_df[["gender", "age_group"]]
    encoder = OneHotEncoder(sparse=False)
    processed_features = encoder.fit_transform(features)
    copy_df = copy_df.reset_index(drop=True)
    return copy_df, processed_features


# Flask endpoint function to train a new model and save it
def train_and_save_model():
    listing_data, account_data = load_data_from_firestore(db)
    listing_df = pd.DataFrame(listing_data)
    account_df = pd.DataFrame(account_data)
    modified_listing_df, embeddings = preprocess_listings(listing_df)
    modified_account_df, account_features = preprocess_users(account_df)
    users = modified_account_df["id"].unique().tolist()
    items = modified_listing_df["id"].unique().tolist()
    num_listing_features = embeddings.shape[1]
    num_account_features = account_features.shape[1]
    dataset = Dataset()
    dataset.fit(
        users=users,
        items=items,
        user_features=list(range(num_account_features)),
        item_features=list(range(num_listing_features)),
    )
    interaction_data = create_interaction_data(modified_listing_df)
    embeddings_with_ids = [
        (row["id"], embeddings[index]) for index, row in modified_listing_df.iterrows()
    ]
    account_features_with_ids = [
        (row["id"], account_features[index])
        for index, row in modified_account_df.iterrows()
    ]
    user_features = dataset.build_user_features(
        (
            (id, {fname: fvalue for fname, fvalue in enumerate(features)})
            for id, features in account_features_with_ids
        ),
    )
    item_features = dataset.build_item_features(
        (
            (id, {fname: fvalue for fname, fvalue in enumerate(features)})
            for id, features in embeddings_with_ids
        ),
        normalize=False,
    )
    (interactions, weights) = dataset.build_interactions(interaction_data)

    model = build_lightfm_model(interactions, item_features, user_features)
    save_to_storage(dataset, "recommender/recommended_listings_dataset.pkl")
    save_to_storage(model, "recommender/recommended_listings_model.pkl")
    save_dataset_and_model_to_storage(
        model, dataset, "recommender/recommended_listings_model_and_dataset.pkl"
    )
    return "Model trained and saved successfully"


# Flask endpoint function to get recommended listings for a user ID using the pickled model
def get_listings_for_user(id):
    listing_docs = db.collection("listings").get()
    listing_data = {doc.id: {"id": doc.id, **doc.to_dict()} for doc in listing_docs}
    """ listing_data, account_data = load_data_from_firestore(db) """
    """ listing_df = pd.DataFrame(listing_data)
    account_df = pd.DataFrame(account_data)
    embeddings_df = es.load_embeddings()
    listing_df = pd.merge(listing_df, embeddings_df, on="id")
    modified_listing_df, embeddings = preprocess_listings_with_embeddings(listing_df)
    users = account_df["id"].unique().tolist()
    items = modified_listing_df["id"].unique().tolist()
    num_features = embeddings.shape[1]

    dataset = Dataset()
    dataset.fit(users=users, items=items, item_features=list(range(num_features)))
    interaction_data = create_interaction_data(modified_listing_df)
    embeddings_with_ids = [
        (row["id"], embeddings[index]) for index, row in modified_listing_df.iterrows()
    ]
    item_features = dataset.build_item_features(
        (
            (id, {fname: fvalue for fname, fvalue in enumerate(features)})
            for id, features in embeddings_with_ids
        ),
        normalize=False,
    )
    (interactions, weights) = dataset.build_interactions(interaction_data) """

    # Load the pickled model for recommendation'
    """ dataset = load_lightfm_model("recommender/recommended_listings_dataset.pkl")
    model = load_lightfm_model("recommender/recommended_listings_model.pkl") """
    model, dataset = load_lightfm_dataset_and_model(
        "recommender/recommended_listings_model_and_dataset.pkl"
    )
    recommendations = get_recommended_listings(id, model, dataset, listing_data)

    return recommendations
