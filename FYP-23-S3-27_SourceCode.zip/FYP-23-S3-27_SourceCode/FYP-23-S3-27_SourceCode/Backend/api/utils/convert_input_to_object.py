from flask import request


def convert_input_to(class_):
    def wrap(f):
        def decorator(*args):
            obj = class_(**request.form.to_dict())
            return f(obj)

        return decorator

    return wrap
