import firebase_admin
from firebase_admin import credentials, firestore
from PIL import Image
import requests
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
import torch
from annoy import AnnoyIndex
from transformers import (
    CLIPModel,
    AutoImageProcessor,
    ViTFeatureExtractor,
    ViTModel,
    AutoFeatureExtractor,
    ResNetModel,
    ConvNextImageProcessor,
)
import pickle as pk
import numpy
from sklearn.decomposition import PCA
import os

annoy_index = AnnoyIndex(100, "angular")
# annoy_index.load('image_embeddings.ann')


def train_pca(embeddings):
    pca = PCA(n_components=100)
    reduced_embeddings = pca.fit(embeddings)
    pk.dump(pca, open("pca.pkl", "wb"))


def build_index_from_embeddings(embeddings: list):
    annoy_index = AnnoyIndex(100352, "angular")
    for index, embeddings in enumerate(embeddings):
        annoy_index.add_item(index, embeddings)
    # Build the index
    annoy_index.build(1000)  # 10 trees
    return annoy_index


def query_index(image):
    # Since pca_result is now 2D (samples x features), we need to flatten each transformed sample separately
    similar_images = annoy_index.get_nns_by_vector(image, 100, include_distances=True)
    return similar_images
