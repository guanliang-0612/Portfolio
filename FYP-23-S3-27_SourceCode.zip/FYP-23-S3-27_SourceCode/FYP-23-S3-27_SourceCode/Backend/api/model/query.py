import datetime
class Query:
    def __init__(
        self,
        id: str = None,
        receipt_date: datetime = None,
        email: str = None,
        fname: str = None,
        lname: str = None,
        subject: str = None,
        content: str = None,
        status:str = None,
    ):
        self.id = id
        self.receipt_date = receipt_date
        self.email = email
        self.fname = fname
        self.lname = lname
        self.subject = subject
        self.content = content
        self.status = status
        

    def to_dict(self):
        # Only return properties with attributes present
        return {k: v for k, v in vars(self).items() if v}