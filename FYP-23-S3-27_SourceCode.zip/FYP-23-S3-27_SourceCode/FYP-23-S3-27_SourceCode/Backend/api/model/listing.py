import datetime
import inspect


class Listing:
    def __init__(
        self,
        id: str = None,
        category: str = None,
        name: str = None,
        condition: str = None,
        details: str = None,
        offer_history: list = None,
        imageUrls: list = None,
        post_timestamp: datetime = None,
        price: str = None,
        sellerId: str = None,
        status: str = None,
    ):
        self.id = id
        self.category = category
        self.condition = condition
        self.name = name
        self.details = details
        self.offer_history = offer_history
        self.imageUrls = imageUrls
        self.post_timestamp = post_timestamp
        self.price = price
        self.sellerId = sellerId
        self.status = status

    @classmethod
    def from_dict(cls, dict):
        return cls(
            **{
                key: value
                for key, value in dict.items()
                if key in inspect.signature(cls).parameters
            }
        )

    def to_dict(self):
        # Only return properties with attributes present
        return {k: v for k, v in vars(self).items()}
