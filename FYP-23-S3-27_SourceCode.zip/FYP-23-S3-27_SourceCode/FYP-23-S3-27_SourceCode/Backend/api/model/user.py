from dataclasses import dataclass
import inspect


@dataclass
class User:
    id: str = None
    email: str = None
    password: str = None
    display_name: str = None
    fname: str = None
    lname: str = None
    photo_url: str = None
    phone_number: str = None
    role: str = None
    id_token: str = None
    refresh_token: str = None
    status: str = None
    
    # Think of it as a flexible constructor
    @classmethod
    def from_dict(cls, dict):
        return cls(
            **{
                key: value
                for key, value in dict.items()
                if key in inspect.signature(cls).parameters
            }
        )

    def to_dict(self):
        # Only return properties that contain values
        return {key: value for key, value in vars(self).items() if value}

    def get_firebase_auth_fields(self) -> dict:
        fields = [
            "id",
            "email",
            "password",
            "display_name",
            "photo_url",
            "phone_number",
        ]
        user_firebase_auth_dict = {
            key: value for key, value in vars(self).items() if key in fields and value
        }
        if id in user_firebase_auth_dict:
            user_firebase_auth_dict["localId"] = user_firebase_auth_dict.pop("id")
        return user_firebase_auth_dict

    def get_firestore_fields(self) -> dict:
        fields = ["fname", "lname", "role", "status"]
        return {
            key: value for key, value in vars(self).items() if key in fields and value
        }
