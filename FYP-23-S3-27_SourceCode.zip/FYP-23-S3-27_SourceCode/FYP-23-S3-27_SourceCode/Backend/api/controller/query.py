from flask import Blueprint, jsonify, request
import api.service.query as query_service 
from api.model.query import Query
from api.model.user import User
import datetime

query_routes = Blueprint("query_route", __name__)


@query_routes.route("/view/allQueries", methods=["GET"])
def view_allQueries():
    result = query_service.get_allQueries()
    return result, 200

@query_routes.route("/view/addQuery",  methods=["POST", "PUT"])
def insert_query(query = Query('ABC',datetime.datetime.now(),'abc@gmail.com','abc','efg','screening','subjjjjj','asas') ):
    result = query_service.add_query(query)
    return result, 200

@query_routes.route("/view/individualQuery", methods=["GET"])
def view_IndividualQueries(id ='yUzlMjBeSes14zlbDZcP' ):
    result = query_service.get_individualQuery(id)
    return result, 200

@query_routes.route("/view/searchQuery", methods=["GET"])
def view_SearchQueries(text = 'HELP' ):
    result = query_service.get_searchQuery(text)
    return result, 200

@query_routes.route("/view/updateQueryLog",  methods=["POST", "PUT"])
def update_queryLog(query = Query('yUzlMjBeSes14zlbDZcP',datetime.datetime.now(),'abc@gmail.com','abc','efg','screening','subjjjjj','asas'),
                                    message = "boom",user = User("123","adr@gmail.com",'asasa',"mark","eeqw","1234","admin")):
    result = query_service.update_queryLogHistory(query,message,user)
    return result, 200

@query_routes.route("/view/updateQueryStatus",  methods=["POST", "PUT"])
def view_queryStatus(query = Query('yUzlMjBeSes14zlbDZcP',datetime.datetime.now(),'abc@gmail.com','abc','efg','screening','subjjjjj','asas'),newStatus= 'very okay'):
    result = query_service.update_queryStatus(query,newStatus)
    return result, 200





