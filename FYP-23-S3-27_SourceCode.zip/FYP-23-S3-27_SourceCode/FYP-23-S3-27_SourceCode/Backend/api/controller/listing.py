from flask import Blueprint, jsonify, request, Response
import api.service.listing as listing_service
from api.utils.convert_input_to_object import convert_input_to
from api.model.listing import Listing
import datetime
import io
import base64
from PIL import Image

listing_routes = Blueprint("listing_routes", __name__)


#############################
# Seller Listings
@listing_routes.route("/createlistings", methods=["POST", "PUT"])
def instantiate_listings() -> Response:
    data = request.form.to_dict()
    files = request.files.getlist("files")
    result = listing_service.create_listing(Listing.from_dict(data), files)
    return result, 200


@listing_routes.route("/seller/<sellerId>", methods=["GET"])
def get_sellerListings(sellerId: str) -> Response:
    result = listing_service.view_sellerListings(sellerId)
    return result, 200


@listing_routes.route("/<id>", methods=["GET"])
def get_sellerIndividualListings(id: str) -> Response:
    result = listing_service.get_individualListing(id)
    print(result)
    return result, 200


@listing_routes.route("/updateListingStatus", methods=["POST", "PUT"])
def change_sellerListingStatus(
    id="Xw28HtP1f4D7j6VZK1L3", status="new status"
) -> Response:
    result = listing_service.update_listingStatus(id, status)
    return result, 200


@listing_routes.route("/<id>", methods=["DELETE"])
def remove_listing(id) -> Response:
    try:
        result = listing_service.delete_listing(id)
        return {"message": "Success"}, 200
    except Exception as err:
        print(err)
        return {"message": "Failed"}, 400


@listing_routes.route("/search", methods=["GET"])
def get_searchListing() -> Response:
    search_criteria = request.args.get("criteria")
    result = listing_service.search_listing(search_criteria)
    return result, 200


@listing_routes.route("/updateListing", methods=["POST", "PUT"])
def change_sellerListing(
    listing=Listing(
        "Xw28HtP1f4D7j6VZK1L3",
        "category123",
        "condition",
        "description",
        [{"Abc": "ABC", "efg": "efg"}],
        ["www.abc.com", "www.efg.com"],
        datetime.datetime.now(),
        "20",
        "sellerId",
        "status",
    )
) -> Response:
    result = listing_service.update_listing(listing)
    return result, 200


@listing_routes.route("/filterListings", methods=["GET"])
def view_filteredListing(
    condition="condition", price=[], category="category123"
) -> Response:
    result = listing_service.filter_listing(condition, price, category)
    return result, 200


#########################################
# buyer listings
@listing_routes.route("/", methods=["GET"])
def get_all_listings() -> Response:
    result = listing_service.all_listings()
    return result, 200


@listing_routes.route("/searchListingText", methods=["GET"])
def retrieve_listingByText(text="Blue Top") -> Response:
    result = listing_service.search_ListingByText(text)
    return result, 200


@listing_routes.route("/viewListingsCategory", methods=["GET"])
def view_ListingsCategory(category="Tops") -> Response:
    result = listing_service.view_buyerListingsCategory()
    return result, 200


@listing_routes.route("/imagesearch", methods=["POST", "PUT"])
def image_search_listings() -> Response:
    image = request.files.get("query")
    if not image:
        return "error", 400
    # Remove the "data:image/jpeg;base64," part
    result = listing_service.search_by_image(image)
    return result, 200


@listing_routes.route("/clothingattributes", methods=["POST", "PUT"])
def get_clothing_attributes() -> Response:
    image = request.files.get("query")
    if not image:
        return "error", 400
    # Remove the "data:image/jpeg;base64," part
    result = listing_service.get_clothing_attributes(image)
    return result, 200


@listing_routes.route("/buildembeddings", methods=["POST"])
def build_embeddings() -> Response:
    # Remove the "data:image/jpeg;base64," part
    result = listing_service.build_embeddings_for_all_listings()
    return result, 200


""" @listing_routes.route("/buildembeddingsandindex", methods=["POST"])
def build_embeddings_and_index() -> Response:
    # Remove the "data:image/jpeg;base64," part
    result = listing_service.build_embeddings_and_index_for_all_listings()
    return result, 200 """


@listing_routes.route("/updateembeddings", methods=["POST"])
def update_embeddings():
    data = request.get_json()
    print(data)
    id = data["id"]
    image_url = data["imageUrl"]
    listing_service.update_or_add_listing_image_embeddings(id, image_url)
    return "Success", 200


@listing_routes.route("/recommended/<id>", methods=["GET"])
def get_recommended_listings_for_user(id: str) -> Response:
    result = listing_service.get_recommended_listings_for_user(id)
    return result, 200


@listing_routes.route("/trainrecommender", methods=["POST"])
def train_recommender():
    result = listing_service.train_recommender()
    return result, 200
