from api.model.user import User
from flask import Blueprint, jsonify, request, Response, Request
import api.service.user as user_service
from api.utils.convert_input_to_object import convert_input_to

user_routes = Blueprint("user_routes", __name__)


@user_routes.route("/new", methods=["POST"])
def add_user() -> Response:
    try:
        user = User.from_dict(request.form.to_dict())
        result = user_service.create_user(user)
        return {"message": "success"}, 200
    except Exception as err:
        return {"message": f"{err}"}, 400


@user_routes.route("/all", methods=["GET"])
def view_all() -> Response:
    return user_service.get_all(), 200


@user_routes.route("/<user_id>", methods=["GET"])
def view_user(user_id: str) -> Response:
    return user_service.get_details(User(id=user_id)), 200


@user_routes.route("/login", methods=["POST"])
def login_user() -> Response:
    try:
        email = request.form.get("email")
        password = request.form.get("password")
        user_login_details = User(email=email, password=password)
        user_dict = user_service.sign_in(user_login_details)
        return user_dict, 200
    except Exception as err:
        return {"message": f"{err}"}, 400


@user_routes.route("/<user_id>", methods=["POST"])
def update_user(user_id: str, request: Request = request) -> Response:
    user = User.from_dict(request.json)
    result = user_service.update_user(user)
    if result.upper() == "SUCCESS":
        return {"message": "User details updated successfully"}, 200
    return {"message": f"{result}"}, 400


@user_routes.route("/<user_id>/admin/password", methods=["PUT"])
def update_password(user_id: str, request: Request = request) -> Response:
    new_password = request.form.get("password")
    user_update_details = User(id=user_id, password=new_password)
    result = user_service.update_password(user_update_details)
    if result.upper() == "SUCCESS":
        return {"message": "Password updated successfully"}, 200
    return {"message": f"{result}"}, 400


@user_routes.route("/<user_id>/password", methods=["PUT"])
def send_password_reset_email(user_id: str = None):
    result = user_service.send_password_reset_email(User(id="user_id"))
    if result["message"] == "Something went wrong":
        return result, 400
    return result, 200
