from firebase_admin import (
    credentials,
    firestore,
    storage,
    auth,
    initialize_app,
    exceptions,
)
import pyrebase as pb
import json

with open("pyrebase_key.json") as json_file:
    pyrebaseConfig = json.load(json_file)
pb_app = pb.initialize_app(pyrebaseConfig)
# Initialize Firestore DB
cred = credentials.Certificate("firebase_key.json")
default_app = initialize_app(cred, {"storageBucket": "top-care-fashion.appspot.com"})
db = firestore.client()
bucket = storage.bucket()
auth = auth.Client(app=default_app)
pb_auth = pb_app.auth()
pb_apiKey = pyrebaseConfig["apiKey"]
