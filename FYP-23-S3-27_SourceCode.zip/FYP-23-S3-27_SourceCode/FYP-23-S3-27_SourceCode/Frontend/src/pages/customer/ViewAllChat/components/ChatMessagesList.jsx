import React, { useRef, useEffect } from "react";
import ChatMessageSingle from "./ChatMessageSingle";
import { useAuth } from "../../../../contexts/AuthContext";
import { Stack, ScrollArea, createStyles } from "@mantine/core";

const useStyles = createStyles((theme) => ({
  wrapper: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    height: "100%",
  },
  scrollArea: {
    width: "100%",
    flexGrow: 1,
    flexShrink: 0,
    height: "calc(100%)",
  },
}));

export default function ChatMessagesList({ messages = [] }) {
  const { currentUser } = useAuth();
  const { classes } = useStyles();
  const viewport = useRef();
  function scrollToBottom() {
    viewport.current.scrollTo({
      top: viewport.current.scrollHeight,
      behavior: "smooth",
    });
  }
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <ScrollArea className={classes.scrollArea} viewportRef={viewport}>
      <div className={classes.wrapper}>
        {messages.map((message, index) => {
          return (
            <ChatMessageSingle
              key={index}
              text={message.text}
              timestamp={message.timestamp}
              isSentByCurrentUser={message.senderId === currentUser.id}
            />
          );
        })}{" "}
      </div>
    </ScrollArea>
  );
}
