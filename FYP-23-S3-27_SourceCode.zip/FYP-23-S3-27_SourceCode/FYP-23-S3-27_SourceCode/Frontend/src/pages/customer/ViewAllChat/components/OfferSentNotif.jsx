import { Notification } from "@mantine/core";
import { IconCheck } from "@tabler/icons-react";

export function OfferSentNotif() {
  return (
    <Notification icon={<IconCheck size="1.2rem" />} title="We notify you that">
      Your offer has been sent!
    </Notification>
  );
}
