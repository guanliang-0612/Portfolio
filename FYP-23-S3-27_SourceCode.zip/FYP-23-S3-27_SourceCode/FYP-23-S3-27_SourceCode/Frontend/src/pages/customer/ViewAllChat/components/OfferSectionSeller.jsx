import {
  Grid,
  ScrollArea,
  SimpleGrid,
  Text,
  Stack,
  Container,
  Divider,
  Avatar,
  Space,
  Group,
  NumberInput,
  Button,
  Flex,
  Image,
  Loader,
  Skeleton,
} from "@mantine/core";
import { createStyles } from "@mantine/core";
import { useEffect, useState } from "react";
import { OfferSentNotif } from "./OfferSentNotif";
import { addOfferListings } from "../../../../services/offerService";
import { useAuth } from "../../../../contexts/AuthContext";
import { getListing } from "../../../../services/listingService";
import useOffers from "../../../../hooks/useOffers";
import { respondToBuyerOffer } from "../../../../services/offerService";
import { updateListingStatus } from "../../../../services/listingService";
import { SubmitReview } from "../../SubmitReview/SubmitReview";

export default function OfferSectionSeller({
  chatRoomInfo = {
    sellerName: "",
    sellerImage: "",
    buyerName: "",
    buyerId: "",
    buyerImage: "",
    listingName: "",
    listingImage: "",
    listingPrice: 0,
    sellerId: "",
    listingId: "",
  },
}) {
  const [imgIsLoading, setImgIsLoading] = useState(true);
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [buttonText, setButtonText] = useState("Loading");
  const [isButtonLoading, setIsButtonLoading] = useState(false);
  const [offerPrice, setOfferPrice] = useState(chatRoomInfo.listingPrice);
  const { currentUser } = useAuth();
  const { offers, offersLoading } = useOffers(
    chatRoomInfo.buyerId,
    chatRoomInfo.listingId
  );

  useEffect(() => {
    setImgIsLoading(true);
  }, [chatRoomInfo]);

  //   useEffect(() => {
  //     setIsButtonLoading(true);
  //     if (offersLoading) return;
  //     if (offers[0]?.status === "pending") {
  //       setButtonText("Offer Sent");
  //       setIsButtonLoading(false);
  //       setIsButtonDisabled(true);
  //       return;
  //     }
  //     setIsButtonLoading(false);
  //     setButtonText("Send Offer");
  //   }, [offers, offersLoading]);

  const handleAcceptClick = async (offer) => {
    try {
      const result = await respondToBuyerOffer(offer.id, "accepted");
      if (result === true) {
        /* await updateListingStatus({
          id: chatRoomInfo.listingId,
          status: "unavailable",
        }); */
      } else {
        console.error("Error accepting offer");
      }
    } catch (error) {
      console.error("Error accepting offer:", error);
    }
  };

  const handleRejectClick = async (offer) => {
    try {
      const result = await respondToBuyerOffer(offer.id, "rejected");
      if (result === true) {
        /* await updateListingStatus({
          id: chatRoomInfo.listingId,
          status: "available",
        }); */
      } else {
        console.error("Error rejecting offer");
      }
    } catch (error) {
      console.error("Error rejecting offer:", error);
    }
  };

  return (
    <Flex align="flex-end" gap="xs">
      {/* If offer is pending */}
      {offers[0]?.status === "pending" && (
        <div>
          <NumberInput
            label="Offer Price"
            defaultValue={offerPrice}
            disabled
            hideControls
          />
          <Space h="xs" />
          <Flex align="flex-end" gap="xl">
            <Button
              name="AcceptButton"
              color="dark"
              onClick={() => handleAcceptClick(offers[0])}
            >
              Accept
            </Button>
            <Button
              name="RejectButton"
              color="dark"
              onClick={() => handleRejectClick(offers[0])}
            >
              Reject
            </Button>
          </Flex>
        </div>
      )}

      {/* If offer is accepted */}
      {/*component={Link} to={"/CreateListing"}*/}
      {offers[0]?.status === "accepted" && (
        <div>
          <Text>You accepted an offer: ${offerPrice}</Text>
          <Flex align="flex-end" direction="column">
            {/* <Button color="dark">Submit Review</Button> */}
            <SubmitReview chatRoomInfo={chatRoomInfo} />
          </Flex>
        </div>
      )}

      {/* If offer is rejected */}
      {offers[0]?.status === "rejected" && (
        <div>
          <Text>You rejected an offer: ${offerPrice}</Text>
        </div>
      )}
    </Flex>
  );
}
