import React, { useState } from "react";
import ChatInput from "./ChatInput";
import useChat from "../../../../hooks/useChat";

function ChatInputApp({ onSendMessage }) {
  const [messages, setMessages] = useState([]);

  return (
    <div>
      <ChatInput onSendMessage={onSendMessage} />
      {/* Render the chat messages component here */}
    </div>
  );
}

export default ChatInputApp;
