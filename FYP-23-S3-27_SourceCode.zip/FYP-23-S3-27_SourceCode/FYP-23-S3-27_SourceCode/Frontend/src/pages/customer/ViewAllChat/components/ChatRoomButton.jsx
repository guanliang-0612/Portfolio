import { useAuth } from "../../../../contexts/AuthContext";
import {
  UnstyledButton,
  Group,
  Avatar,
  Text,
  createStyles,
  Skeleton,
} from "@mantine/core";
import { useState } from "react";
// import SingleChat from "./SingleChat";

const useStyles = createStyles((theme) => ({
  chatRoom: {
    display: "flex",
    width: "100%",
    padding: theme.spacing.md,
    color: theme.colorScheme === "dark" ? theme.colors.dark[0] : theme.black,
    flexDirection: "row",
    "&:hover": {
      backgroundColor:
        theme.colorScheme === "dark"
          ? theme.colors.dark[8]
          : theme.colors.gray[3],
    },
  },
  active: {
    backgroundColor: theme.colors.gray[1],
  },
  ellipsisText: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: "150px", // Adjust this value based on your requirements
  },
  root: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    height: "100%",
  },
  scrollArea: {
    width: "100%",
    flexGrow: 1,
    flexShrink: 0,
    height: "calc(100%)",
  },
}));

const ChatRoomButton = ({ chatRoom, active, onClick }) => {
  const { classes, cx } = useStyles();
  const { currentUser } = useAuth();
  const [imgIsLoading, setImgIsLoading] = useState(true);
  return (
    <UnstyledButton
      className={cx(classes.chatRoom, {
        [classes.active]: active,
      })}
      onClick={onClick}
    >
      <Group
        style={{ display: "flex", flexWrap: "nowrap", flexDirection: "row" }}
      >
        <Skeleton visible={imgIsLoading}>
          <Avatar
            src={
              chatRoom.listingImage
              /* chatRoom.buyerId === currentUser.id
                    ? chatRoom.sellerImage
                    : chatRoom.buyerImage */
            }
            imageProps={{ onLoad: () => setImgIsLoading(false) }}
            radius="md"
          />{" "}
        </Skeleton>
        <div>
          <Text
            size="sm"
            weight={500}
            truncate
            className={classes.ellipsisText}
          >
            {chatRoom.listingName}
          </Text>

          <Text color="dimmed" size="xs" className={classes.ellipsisText}>
            {chatRoom.buyerId === currentUser.id
              ? chatRoom.sellerName
              : chatRoom.buyerName}
          </Text>
        </div>{" "}
      </Group>
    </UnstyledButton>
  );
};

export default ChatRoomButton;
