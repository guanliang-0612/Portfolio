import React, { useState } from "react";
import {
  Textarea,
  Button,
  Flex,
  createStyles,
  ActionIcon,
} from "@mantine/core";
import { IconSend } from "@tabler/icons-react";
import { useForm } from "@mantine/form";
import { useAuth } from "../../../../contexts/AuthContext";

// Define the styles for the ChatInput component
const useStyles = createStyles((theme) => ({
  chatInput: {
    display: "flex",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[3]
    }`,
    borderRadius: theme.radius.sm,
    padding: theme.spacing.xs,
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : "white",
  },
  sendButton: {
    backgroundColor:
      theme.colorScheme === "dark"
        ? theme.colors.blue[7]
        : theme.colors.blue[5],
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    border: "none",
    borderRadius: theme.radius.sm,
    marginLeft: theme.spacing.sm,
    cursor: "pointer",
  },
}));

function ChatInput({ onSendMessage }) {
  const [message, setMessage] = useState("");

  const classes = useStyles();

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSendMessage = (message) => {
    if (message.trim() !== "") {
      onSendMessage(message);
      setMessage("");
    }
  };

  return (
    <Flex className={classes.flex} direction="row" gap="xs" align="center">
      <Textarea
        styles={{ root: { width: "100%", border: "0px" } }}
        className={classes.textarea}
        rows="1"
        placeholder="Type a message..."
        value={message}
        onChange={handleMessageChange}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage(message);
          }
        }}
      />
      <ActionIcon
        className={classes.sendButton}
        component={Button}
        size="xl"
        variant="filled"
        onClick={() => {
          handleSendMessage(message);
        }}
      >
        <IconSend size="2rem" />
      </ActionIcon>
      {/* <Button
        className={classes.sendButton}
        onClick={handleSendMessage}
        variant="filled"
        size="sm"
      >
        Send
      </Button> */}
    </Flex>
  );
}

export default ChatInput;
