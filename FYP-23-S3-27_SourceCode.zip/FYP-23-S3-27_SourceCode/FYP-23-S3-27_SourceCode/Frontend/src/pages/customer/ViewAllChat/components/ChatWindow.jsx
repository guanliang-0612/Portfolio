/* import ChatHeaderBuyer from "./ChatHeaderBuyer"; */
/* import ChatHeaderSeller from "./OfferSectionSeller"; */
import ChatMessagesList from "./ChatMessagesList";
import ChatInput from "./ChatInput";
import {
  Stack,
  ScrollArea,
  Flex,
  Textarea,
  ActionIcon,
  Button,
  createStyles,
} from "@mantine/core";
import useChat from "../../../../hooks/useChat";
import { useEffect, useRef, useState } from "react";
import { useChatRooms } from "../../../../contexts/ChatRoomsContext";
import { useAuth } from "../../../../contexts/AuthContext";
import ChatHeader from "./ChatHeader";
import { IconSend } from "@tabler/icons-react";

const useStyles = createStyles((theme) => ({
  chatInput: {
    display: "flex",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[3]
    }`,
    borderRadius: theme.radius.sm,
    padding: theme.spacing.xs,
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : "white",
  },
  sendButton: {
    backgroundColor:
      theme.colorScheme === "dark"
        ? theme.colors.blue[7]
        : theme.colors.blue[5],
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    border: "none",
    borderRadius: theme.radius.sm,
    marginLeft: theme.spacing.sm,
    cursor: "pointer",
  },
}));

export default function ChatWindow({ chatRoomInfo }) {
  const [chatRoomInfoState, setChatRoomInfoState] = useState(null);
  const { messages, sendMessage } = useChat(chatRoomInfoState?.id);
  const { currentUser } = useAuth();
  const [message, setMessage] = useState("");

  useEffect(() => {
    /* if (!chatRoomInfo?.id) return;
    if (chatRoomInfoState?.id !== chatRoomInfo?.id) */
    setChatRoomInfoState(chatRoomInfo);
  }, [chatRoomInfoState, chatRoomInfo]);

  const classes = useStyles();

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSendMessage = (message) => {
    if (message.trim() !== "") {
      sendMessage(message);
      setMessage("");
    }
  };

  return (
    chatRoomInfoState?.id && (
      <div
        style={{
          paddingRight: "10px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          width: "100%",
          padding: "5px",
        }}
      >
        <div>
          <ChatHeader chatRoomInfo={chatRoomInfoState} />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-end",
            overflow: "hidden",
            padding: "5px",
            width: "100%",
            height: "100%",
          }}
        >
          <ChatMessagesList messages={messages} />
        </div>
        <div>
          {/* <ChatInput onSendMessage={sendMessage} /> */}
          <Flex
            className={classes.flex}
            direction="row"
            gap="xs"
            align="center"
          >
            <Textarea
              styles={{ root: { width: "100%", border: "0px" } }}
              className={classes.textarea}
              rows="1"
              placeholder="Type a message..."
              value={message}
              onChange={handleMessageChange}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(message);
                }
              }}
            />
            <ActionIcon
              className={classes.sendButton}
              component={Button}
              size="xl"
              variant="filled"
              onClick={() => {
                handleSendMessage(message);
              }}
            >
              <IconSend size="2rem" />
            </ActionIcon>
            {/* <Button
        className={classes.sendButton}
        onClick={handleSendMessage}
        variant="filled"
        size="sm"
      >
        Send
      </Button> */}
          </Flex>
        </div>
      </div>
    )
  );
}
