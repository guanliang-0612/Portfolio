import { useAuth } from "../../../../contexts/AuthContext";
import {
  Stack,
  ScrollArea,
  UnstyledButton,
  Group,
  Avatar,
  Text,
  createStyles,
} from "@mantine/core";
import { useNavigate, useParams } from "react-router-dom";
import ChatRoomButton from "./ChatRoomButton";
// import SingleChat from "./SingleChat";

const useStyles = createStyles((theme) => ({
  chatRoom: {
    display: "flex",
    width: "100%",
    padding: theme.spacing.md,
    color: theme.colorScheme === "dark" ? theme.colors.dark[0] : theme.black,
    flexDirection: "row",
    "&:hover": {
      backgroundColor:
        theme.colorScheme === "dark"
          ? theme.colors.dark[8]
          : theme.colors.gray[3],
    },
  },
  active: {
    backgroundColor: theme.colors.gray[1],
  },
  ellipsisText: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: "150px", // Adjust this value based on your requirements
  },
  root: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    height: "100%",
  },
  scrollArea: {
    width: "100%",
    flexGrow: 1,
    flexShrink: 0,
    height: "calc(100%)",
  },
}));

export default function ChatList({ chatRooms = [] }) {
  const { classes, cx } = useStyles();
  const { chatRoomId } = useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  return (
    // Solution for dynamic height scrollArea https://github.com/mantinedev/mantine/issues/724
    <div className={classes.root}>
      <ScrollArea className={classes.scrollArea}>
        {chatRooms.map((chatRoom) => (
          <ChatRoomButton
            key={chatRoom.id}
            chatRoom={chatRoom}
            active={chatRoom.id === chatRoomId}
            onClick={() => navigate(`/chats/${chatRoom.id}`)}
          />
        ))}
      </ScrollArea>
    </div>
  );
}
