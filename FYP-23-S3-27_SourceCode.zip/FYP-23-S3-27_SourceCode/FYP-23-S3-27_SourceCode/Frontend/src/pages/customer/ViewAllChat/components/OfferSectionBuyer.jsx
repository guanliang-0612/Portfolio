import {
  Grid,
  ScrollArea,
  SimpleGrid,
  Text,
  Stack,
  Container,
  Divider,
  Avatar,
  Space,
  Group,
  NumberInput,
  Button,
  Flex,
  Image,
  Loader,
  Skeleton,
  ActionIcon,
  rem,
  em,
} from "@mantine/core";
import { createStyles } from "@mantine/core";
import { useEffect, useState } from "react";
import { OfferSentNotif } from "./OfferSentNotif";
import {
  addOfferListings,
  cancelOffer,
} from "../../../../services/offerService";
import { useAuth } from "../../../../contexts/AuthContext";
import {
  getListing,
  updateListingStatus,
} from "../../../../services/listingService";
import useOffers from "../../../../hooks/useOffers";
import { SubmitReview } from "../../SubmitReview/SubmitReview";
import UserProfileButton from "../../../../components/UserProfileButton";
import { calculateUserRating } from "../../../../services/reviewService";
import { Link, useNavigate } from "react-router-dom";
import { IconTrash } from "@tabler/icons-react";
import { useChatRooms } from "../../../../contexts/ChatRoomsContext";

export default function OfferSectionBuyer({
  chatRoomInfo = {
    sellerName: "",
    sellerId: "",
    sellerImage: "",
    buyerName: "",
    buyerId: "",
    buyerImage: "",
    listingName: "",
    listingImage: "",
    listingPrice: 0,
    listingId: "",
    id: "",
  },
  offers = [],
  offersLoading = true,
}) {
  const navigate = useNavigate();
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [isCancelLoading, setIsCancelLoading] = useState(false);
  const [buttonText, setButtonText] = useState("Loading");
  const [isButtonLoading, setIsButtonLoading] = useState(false);
  const [offerPrice, setOfferPrice] = useState(chatRoomInfo.listingPrice);
  const { currentUser } = useAuth();
  const [inputError, setInputError] = useState(null);

  useEffect(() => {
    setIsButtonLoading(true);
    if (offersLoading) return;
    if (offers[0]?.status === "pending") {
      setButtonText("Offer Sent");
      setIsButtonLoading(false);
      setIsButtonDisabled(true);
      return;
    }

    setButtonText("Send Offer");
    setIsButtonDisabled(false);
    setIsButtonLoading(false);
  }, [offers, offersLoading]);

  const handleClick = async () => {
    setIsButtonDisabled(true);
    setIsButtonLoading(true);
    try {
      const priceValue = parseFloat(offerPrice);
      if (isNaN(priceValue) || priceValue <= 0) {
        setInputError("Price is invalid.");
        setIsButtonDisabled(true);
        setIsButtonLoading(false);
        return;
      }

      setIsButtonDisabled(true);
      setIsButtonLoading(true);

      const result = await addOfferListings({
        amount: priceValue,
        buyerId: currentUser.id,
        listingId: chatRoomInfo.listingId,
        sellerId: chatRoomInfo.sellerId,
      });

      if (result === true) {
        OfferSentNotif();
        setButtonText("Offer Sent");
        setIsButtonLoading(false);
        setInputError(null); // Clear the error if the submission is successful
      } else {
        setInputError("Error sending offer");
        setIsButtonDisabled(false);
      }
    } catch (error) {
      console.error("Error sending offer:", error);
      setIsButtonDisabled(false);
    }
  };

  const handleCancel = async () => {
    try {
      setIsCancelLoading(true);
      const result = await cancelOffer(offers[0].id);
    } catch (error) {
      console.error("Error cancelling offer:", error);
    } finally {
      setIsCancelLoading(false);
    }
  };

  return (
    <Flex align="flex-end" gap="xs">
      {offers[0]?.status !== "accepted" && (
        <>
          <NumberInput
            label="Price"
            defaultValue={chatRoomInfo.listingPrice}
            parser={(value) => value.replace(/\$\s?|(,*)/g, "")}
            formatter={(value) =>
              !Number.isNaN(parseFloat(value))
                ? `$ ${parseFloat(value).toFixed(2)}`.replace(
                    /\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g,
                    ","
                  )
                : "$ "
            }
            style={{ width: rem("7rem") }}
            value={offerPrice}
            decimalScale={2}
            onChange={(value) => {
              setOfferPrice(value);
              setInputError(null);
            }}
            error={inputError}
          />
          <Button
            color="dark"
            onClick={handleClick}
            disabled={isButtonDisabled}
            loading={isButtonLoading}
            loaderPosition="left"
          >
            {buttonText}
          </Button>
          {offers[0]?.status === "pending" && (
            <Button
              variant="outline"
              color="red"
              onClick={handleCancel}
              loading={isCancelLoading}
              loaderPosition="left"
            >
              Cancel
            </Button>
          )}
        </>
      )}

      {offers[0]?.status === "accepted" && (
        <div>
          <Text>Offer Accepted: ${offerPrice}</Text>
          <Flex align="flex-end" direction="column">
            {/* <Button color="dark">Submit Review</Button> */}
            <SubmitReview chatRoomInfo={chatRoomInfo} />
          </Flex>
        </div>
      )}
    </Flex>
  );
}
