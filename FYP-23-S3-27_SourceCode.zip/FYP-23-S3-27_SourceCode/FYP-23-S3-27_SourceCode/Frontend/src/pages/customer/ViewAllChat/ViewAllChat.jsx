import {
  Grid,
  Text,
  createStyles,
  Button,
  Container,
  LoadingOverlay,
  Divider,
} from "@mantine/core";
// import ContentContainer from "../../../components/ContentContainer";
import ContentContainerChat from "../../../components/ContentContainerChat";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../../contexts/AuthContext";
import ChatList from "./components/ChatList";
import {
  IconSettings,
  IconListSearch,
  IconMessages,
} from "@tabler/icons-react";
import useChat from "../../../hooks/useChat";
import ChatWindow from "./components/ChatWindow";
import { useChatRooms } from "../../../contexts/ChatRoomsContext";
import { useEffect } from "react";

const useStyles = createStyles((theme) => {
  return {
    headerWrapper: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      height: "100%",
      width: "100%",
      padding: "10px",
    },
    con: {
      padding: 0,
      position: "relative",
      height: "100%",
      display: "flex",
      flexDirection: "row",
    },
  };
});

export default function ViewAllChat({ chats }) {
  const { classes, cx } = useStyles();
  const { chatRooms, getChatRoomInfo, isLoading } = useChatRooms();
  const { chatRoomId } = useParams();

  const navigate = useNavigate();
  useEffect(() => {
    if (!chatRoomId) return;
  }, [chatRoomId, chatRooms, getChatRoomInfo, navigate]);

  return (
    <ContentContainerChat>
      <ContentContainerChat.Header>
        <div className={classes.headerWrapper}>
          <Text c="white">Chats</Text>
          <Button
            compact
            color="white"
            variant="default"
            leftIcon={<IconSettings />}
            component={Link}
            to={"/AutoReply"}
          >
            Auto Reply
          </Button>
        </div>
      </ContentContainerChat.Header>
      <ContentContainerChat.Body>
        {/*         <div className={classes.con}>
          {isLoading ? (
            <LoadingOverlay overlayOpacity={1} transitionDuration={0} />
          ) : (
            <Grid columns={12}>
              <Grid.Col span={3} style={{ display: "flex", height: "100%" }}>
                <ChatList chatRooms={chatRooms} />
              </Grid.Col>
              <Grid.Col span={9} className={classes.window}>
                {chatRoomId && chatRooms.length > 0 && (
                  <ChatWindow chatRoomInfo={getChatRoomInfo(chatRoomId)} />
                )}
              </Grid.Col>
            </Grid>
          )}
        </div> */}
        {/* {isLoading ? (
          <div style={{ position: "relative", height: "100%", width: "100%" }}>
            <LoadingOverlay
              overlayOpacity={1}
              visible={isLoading}
              transitionDuration={0}
            />
          </div>
        ) : ( */}
        <div className={classes.con}>
          <div
            style={{
              width: "25%",
              height: "100%",
            }}
          >
            <ChatList chatRooms={chatRooms} />
          </div>
          <Divider size="sm" orientation="vertical" />
          <div
            style={{
              width: "75%",
              height: "100%",
              display: "flex",
              padding: "0px 10px",
            }}
          >
            {chatRoomId && chatRooms.length > 0 && (
              <ChatWindow chatRoomInfo={getChatRoomInfo(chatRoomId)} />
            )}
            {!chatRoomId && (
              <Container
                style={{
                  display: "flex",
                  height: "100%",
                  width: "100%",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  maxHeight: "50vh",
                }}
              >
                <IconMessages size={60} stroke={1} />
                <Text size="lg" align="center" weight={450} mt="5px">
                  Click on a chatroom to see your conversations!
                </Text>
              </Container>
            )}
          </div>
        </div>
        {/*  )} */}
      </ContentContainerChat.Body>
    </ContentContainerChat>
  );
}
