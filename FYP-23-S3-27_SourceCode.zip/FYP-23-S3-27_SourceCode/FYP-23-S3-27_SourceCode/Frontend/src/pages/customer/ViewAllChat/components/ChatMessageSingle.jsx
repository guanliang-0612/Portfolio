import React from "react";
import {
  Avatar,
  Text,
  Paper,
  MantineProvider,
  Grid,
  Space,
} from "@mantine/core";

export default function ChatMessageSingle({
  text = "",
  timestamp = new Date(),
  isSentByCurrentUser = true,
}) {
  const dateStringOptions = {
    hour: "numeric",
    minute: "numeric",
    year: "numeric",
    month: "short",
    day: "numeric",
  };

  return (
    <Paper
      style={{
        minWidth: "40%",
        maxWidth: "60%",
        padding: "15px",
        alignSelf: isSentByCurrentUser ? "flex-end" : "flex-start",
        backgroundColor: isSentByCurrentUser ? "#505050" : "#f0f0f0",
        color: isSentByCurrentUser ? "white" : "black",
      }}
    >
      <Text
        size="sm"
        style={{
          wordWrap: "anywhere",
          maxWidth: "100%",
        }}
      >
        {text}
      </Text>
      <div style={{ marginTop: "5px", fontSize: "12px" }}>
        {timestamp.toLocaleString("en-sg", dateStringOptions)}
      </div>
    </Paper>
  );
}
