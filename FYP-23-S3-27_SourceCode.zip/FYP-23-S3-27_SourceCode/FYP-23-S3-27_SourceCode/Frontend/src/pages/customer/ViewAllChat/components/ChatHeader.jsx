import {
  Grid,
  ScrollArea,
  SimpleGrid,
  Text,
  Stack,
  Container,
  Divider,
  Avatar,
  Space,
  Group,
  NumberInput,
  Button,
  Flex,
  Image,
  Loader,
  Skeleton,
  ActionIcon,
  Badge,
} from "@mantine/core";
import { createStyles } from "@mantine/core";
import { useEffect, useState } from "react";
import { OfferSentNotif } from "./OfferSentNotif";
import { addOfferListings } from "../../../../services/offerService";
import { useAuth } from "../../../../contexts/AuthContext";
import { getListing } from "../../../../services/listingService";
import useOffers from "../../../../hooks/useOffers";
import { SubmitReview } from "../../SubmitReview/SubmitReview";
import UserProfileButton from "../../../../components/UserProfileButton";
import { calculateUserRating } from "../../../../services/reviewService";
import { Link, useNavigate } from "react-router-dom";
import { IconTrash } from "@tabler/icons-react";
import { useChatRooms } from "../../../../contexts/ChatRoomsContext";
import OfferSectionBuyer from "./OfferSectionBuyer";
import OfferSectionSeller from "./OfferSectionSeller";

export default function ChatHeader({
  chatRoomInfo = {
    sellerName: "",
    sellerId: "",
    sellerImage: "",
    buyerName: "",
    buyerId: "",
    buyerImage: "",
    listingName: "",
    listingStatus: "",
    listingImage: "",
    listingPrice: 0,
    listingId: "",
    id: "",
  },
}) {
  const navigate = useNavigate();
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [buttonText, setButtonText] = useState("Loading");
  const [isButtonLoading, setIsButtonLoading] = useState(false);
  const [offerPrice, setOfferPrice] = useState(chatRoomInfo.listingPrice);
  const [listingImageUrl, setListingImageUrl] = useState("");
  const { deleteChatRoom } = useChatRooms();
  const { currentUser } = useAuth();
  const [userIsLoading, setUserIsLoading] = useState(true);
  const [imgIsLoading, setImgIsLoading] = useState(true);
  const [userInfo, setUserInfo] = useState({
    imageUrl: "",
    dname: "",
    id: "",
    rating: 0,
  });
  const { offers, offersLoading } = useOffers(
    chatRoomInfo.buyerId,
    chatRoomInfo.listingId
  );

  useEffect(() => {
    async function prepUserInfo() {
      setUserIsLoading(true);
      const user =
        chatRoomInfo.buyerId === currentUser.id
          ? {
              imageUrl: chatRoomInfo.sellerImage,
              dname: chatRoomInfo.sellerName,
              id: chatRoomInfo.sellerId,
            }
          : {
              imageUrl: chatRoomInfo.buyerImage,
              dname: chatRoomInfo.buyerName,
              id: chatRoomInfo.buyerId,
            };
      const rating = await calculateUserRating(user.id);
      setUserInfo({
        ...user,
        rating,
      });
      setUserIsLoading(false);
    }
    prepUserInfo();
  }, [chatRoomInfo]);

  useEffect(() => {
    if (chatRoomInfo.listingImage !== listingImageUrl) {
      setImgIsLoading(true);
      setListingImageUrl(chatRoomInfo.listingImage);
    }
  }, [chatRoomInfo]);

  useEffect(() => {
    setIsButtonLoading(true);
    if (offersLoading) return;
    if (offers[0]?.status === "pending") {
      setButtonText("Offer Sent");
      setIsButtonLoading(false);
      setIsButtonDisabled(true);
      return;
    }

    setButtonText("Send Offer");
    setIsButtonDisabled(false);
    setIsButtonLoading(false);
  }, [offers, offersLoading]);

  const handleClick = async () => {
    setIsButtonDisabled(true);
    setIsButtonLoading(true);
    try {
      const result = await addOfferListings({
        amount: offerPrice,
        buyerId: currentUser.id,
        listingId: chatRoomInfo.listingId,
        sellerId: chatRoomInfo.sellerId,
      });
      if (result === true) {
        OfferSentNotif();
        setButtonText("Offer Sent");
        setIsButtonLoading(false);
      } else {
        console.error("Error sending offer");
      }
    } catch (error) {
      console.error("Error sending offer:", error);
    }
  };

  return (
    <div>
      <Space h="sm" />
      <Flex justify="space-between" align="center">
        <UserProfileButton userInfo={userInfo} isLoading={userIsLoading} />
        <ActionIcon
          size="lg"
          variant="filled"
          color="red"
          style={{ alignSelf: "flex-start" }}
          onClick={async () => {
            await deleteChatRoom(chatRoomInfo.id);
            navigate("/chats");
          }}
        >
          <IconTrash />
        </ActionIcon>
      </Flex>

      <Space h="xs" />

      <Group position="apart" style={{ width: "100%" }}>
        <Button
          component={Link}
          variant="subtle"
          color="gray"
          style={{
            width: "min-content",
            maxWidth: "45%",
            height: "max-content",
            color: "black",
            padding: "10px",
            cursor: "pointer",
            ...(chatRoomInfo.listingStatus === "Deleted" && {
              backgroundColor: "transparent",
            }),
          }}
          disabled={chatRoomInfo.listingStatus === "Deleted"}
          styles={{
            label: {
              display: "flex",
              gap: "10px",
            },
          }}
          to={`/listing/${chatRoomInfo.listingId}`}
        >
          <Skeleton height={60} width={60} radius="md" visible={imgIsLoading}>
            <Image
              height={60}
              width={60}
              radius="md"
              /* style={{ display: imgIsLoading ? "none" : "block" }} */
              src={chatRoomInfo.listingImage}
              alt={chatRoomInfo.listingName}
              withPlaceholder
              imageProps={{
                onLoad: () => setImgIsLoading(false),
              }}
            />
          </Skeleton>
          <Skeleton
            visible={imgIsLoading}
            style={{
              whiteSpace: "nowrap",
              textOverflow: "ellipsis",
              overflow: "hidden",
            }}
          >
            <Stack spacing="xs">
              <Text
                style={{
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                }}
              >
                {chatRoomInfo.listingName}
              </Text>
              {chatRoomInfo.listingStatus === "Deleted" ? (
                <Badge
                  variant="light"
                  color="gray"
                  style={{ width: "min-content" }}
                >
                  Deleted
                </Badge>
              ) : (
                <Text>${Number(chatRoomInfo.listingPrice).toFixed(2)}</Text>
              )}
            </Stack>{" "}
          </Skeleton>{" "}
        </Button>
        {chatRoomInfo.listingStatus !== "Deleted" &&
          (chatRoomInfo.buyerId === currentUser.id ? (
            <OfferSectionBuyer
              chatRoomInfo={chatRoomInfo}
              offers={offers}
              offersLoading={offersLoading}
            />
          ) : (
            <OfferSectionSeller
              chatRoomInfo={chatRoomInfo}
              offers={offers}
              offersLoading={offersLoading}
            />
          ))}
      </Group>

      <Space h="xs" />
      <Divider size="sm" />
    </div>
  );
}
