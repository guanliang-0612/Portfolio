import { useDisclosure } from "@mantine/hooks";
import {
  Modal,
  Button,
  Group,
  Rating,
  Textarea,
  Text,
  Space,
  Flex,
} from "@mantine/core";
import { useEffect, useState } from "react";
import { useAuth } from "../../../contexts/AuthContext";
import { useForm } from "@mantine/form";
import { addReview } from "../../../services/reviewService";

export function SubmitReview({
  chatRoomInfo = {
    sellerName: "",
    sellerImage: "",
    buyerName: "",
    buyerId: "",
    buyerImage: "",
    listingName: "",
    listingImage: "",
    listingPrice: 0,
    sellerId: "",
    listingId: "",
  },
}) {
  const [opened, { open, close }] = useDisclosure(false);
  const { currentUser } = useAuth();
  const [isReviewSubmitted, setReviewSubmitted] = useState(false);

  const form = useForm({
    initialValues: {
      listingId: chatRoomInfo.listingId,
      listingName: chatRoomInfo.listingName,
      rating: 1,
      review: "",
      reviewerImage:
        currentUser.id === chatRoomInfo.buyerId
          ? chatRoomInfo.sellerImage
          : chatRoomInfo.buyerImage,
      reviewerName:
        currentUser.id === chatRoomInfo.buyerId
          ? chatRoomInfo.buyerName
          : chatRoomInfo.sellerName,
      dname: currentUser.dname,
      reviewerType:
        currentUser.id === chatRoomInfo.buyerId ? "buyer" : "seller",
      listingImage: chatRoomInfo.listingImage,
      userId:
        currentUser.id === chatRoomInfo.buyerId
          ? chatRoomInfo.sellerId
          : chatRoomInfo.buyerId,
    },
    validate: {
      review: (value) => !value && "Review cannot be empty!",
    },
  });

  const handleSubmit = async (values) => {
    const result = await addReview(values);
    if (result === true) {
      setReviewSubmitted(true);
      close();
    }
  };

  return (
    <div>
      <Modal
        opened={opened}
        onClose={close}
        title="How was your experience?"
        centered
      >
        {/* Modal content */}
        <form onSubmit={form.onSubmit(handleSubmit)}>
          {chatRoomInfo.buyerId === currentUser.id ? (
            <div>
              <Text>Rate the Seller</Text>
              <Rating
                defaultValue={1}
                color="dark"
                {...form.getInputProps("rating")}
              />
              <Space h="md" />

              <Textarea
                label="Write a review"
                withAsterisk
                {...form.getInputProps("review")}
              />
              <Space h="md" />

              <Flex justify="flex-end">
                <Button color="dark" type="submit">
                  Submit
                </Button>
              </Flex>
            </div>
          ) : (
            <div>
              <Text>Rate the Buyer</Text>
              <Rating
                defaultValue={1}
                color="dark"
                {...form.getInputProps("rating")}
              />
              <Space h="md" />

              <Textarea
                label="Write a review"
                withAsterisk
                {...form.getInputProps("review")}
              />
              <Space h="md" />

              <Flex justify="flex-end">
                <Button color="dark" type="submit">
                  Submit
                </Button>
              </Flex>
            </div>
          )}
        </form>
      </Modal>
      <Group position="center">
        <Button color="dark" onClick={open} disabled={isReviewSubmitted}>
          {isReviewSubmitted ? "Review Submitted" : "Submit Review"}
        </Button>
      </Group>
    </div>
  );
}
