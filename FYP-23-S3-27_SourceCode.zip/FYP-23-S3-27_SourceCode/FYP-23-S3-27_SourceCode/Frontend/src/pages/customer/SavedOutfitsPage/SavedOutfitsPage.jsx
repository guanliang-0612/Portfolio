import SavedOutfits from "./SavedOutfits";
const SavedOutfitsPage = () => {
  return (
    <div>
      <SavedOutfits />
      <br />
    </div>
  );
};

export default SavedOutfitsPage;
