/* 
 Usecase:
 B30
 B32
 B33
*/
import { useState } from "react";
import {
  createStyles,
  Text,
  rem,
  SimpleGrid,
  Paper,
  Button,
  TextInput,
  Container,
  Image,
  Overlay,
  ActionIcon,
  Modal,
  Group,
} from "@mantine/core";
import { useForm } from "@mantine/form";
import { IconTrashXFilled, IconArrowNarrowLeft } from "@tabler/icons-react";
import { useNavigate } from "react-router-dom";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "Title-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },

  // for right side
  grid: {
    display: "grid",
    gridTemplateColumns: "1fr 2fr",
    gap: "1rem", // or whatever gap you want between grid items
  },
  hoverIcon: {
    "&:hover": {
      color: "rgb(250, 82, 82)", // Use the specified red color
    },
  },
}));

const mockData = {
  outfitName: "Chic Summer Collection",
  items: [
    {
      category: "Outerwear",
      example: "Example: Jacket, coats, or cardigans",
      imgSrc:
        "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2835&q=80", // Replace with actual image URL
    },
    {
      category: "Top",
      example: "Example: Shirt, blouse, or sweater",
      imgSrc:
        "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80", // Replace with actual image URL
    },
    {
      category: "Bottom",
      example: "Example: Jeans, shorts, or skirt",
      imgSrc:
        "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80", // Replace with actual image URL
    },
    {
      category: "Footwear",
      example: "Example: Sneakers, boots, or sandals",
      imgSrc:
        "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2787&q=80", // Replace with actual image URL
    },
  ],
};

export function SavedOutfits(props) {
  const { classes } = useStyles();
  const [outfitName, setOutfitName] = useState(mockData.outfitName);
  const [modalOpened, setModalOpened] = useState(false);
  const [visible, setVisible] = useState({});
  const navigate = useNavigate();
  const handleNavigate = () => {
    navigate("/MyOutfitsPage");
  };

  const form = useForm({
    initialValues: {
      outfitName: mockData.outfitName,
    },
  });

  return (
    <div className={classes.wrapper}>
      <div className={classes["Title-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          Saved Outfits
        </Text>
        <div onClick={handleNavigate} style={{ cursor: "pointer" }}>
          <IconArrowNarrowLeft color="white" size={24} />
        </div>
      </div>

      <Paper
        padding="md"
        style={{
          width: "100%",
          height: "100%",
          marginTop: "10px",
        }}
      >
        <SimpleGrid cols={2} spacing="xs" verticalSpacing="xs" align="left">
          {/* Left Side Content */}
          <form onSubmit={form.onSubmit(() => {})}>
            <Container>
              <div style={{ marginBottom: "10px" }}>
                <Text weight={500}>Outfit Name</Text>
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  position: "relative",
                }}
              >
                <TextInput
                  name="OutfitName"
                  variant="filled"
                  onChange={(event) => setOutfitName(event.target.value)}
                  styles={(theme) => ({
                    input: {
                      "&:focus-within": {
                        borderColor: theme.colors.dark[7],
                      },
                    },
                  })}
                  style={{ maxWidth: "300px", flex: 1 }}
                  {...form.getInputProps("outfitName")}
                  required
                />
                <ActionIcon
                  style={{ marginTop: "1px", marginLeft: "8px" }}
                  className={classes.hoverIcon}
                  onClick={() => setModalOpened(true)}
                >
                  <IconTrashXFilled size={22} />
                </ActionIcon>
                <Modal
                  opened={modalOpened}
                  onClose={() => setModalOpened(false)}
                  title="Delete Outfit"
                  size="md"
                >
                  <Text>
                    Are you sure you want to delete this Saved Outfit?
                  </Text>
                  <Group position="apart" style={{ marginTop: "20px" }}>
                    <Button
                      onClick={() => {
                        // Handle account deletion logic here
                        setModalOpened(false);
                      }}
                    >
                      Yes, delete it
                    </Button>
                    <Button
                      onClick={() => setModalOpened(false)}
                      style={{ backgroundColor: "black", color: "white" }}
                    >
                      No, keep it
                    </Button>
                  </Group>
                  <ActionIcon
                    style={{ position: "absolute", right: 15, top: 20 }}
                    onClick={() => setModalOpened(false)}
                  >
                    ×
                  </ActionIcon>
                </Modal>
              </div>
              <Button
                type="submit"
                size="xs"
                variant="outline"
                color="dark"
                style={{
                  marginTop: "20px",
                  maxWidth: "100px",
                  maxHeight: "35px",
                }}
              >
                Update
              </Button>

              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  marginTop: "20px",
                }}
              >
                <Text>
                  Tips: You can find similar listing by hovering over the image
                  of the outfit and click on the find similar button.
                </Text>
              </div>
            </Container>
          </form>
          {/* Right Side Content */}
          <Container style={{ marginBottom: "10px" }}>
            {mockData.items.map((item) => (
              //control the image and description
              <Container
                style={{
                  minWidth: "420px",
                  display: "flex",
                  marginBottom: "10px",
                  border: "1px solid black",
                  borderRadius: "5px",
                  overflow: "hidden",
                  padding: "0px",
                }}
                key={item.category}
              >
                {/* Image Container */}
                <Container
                  style={{
                    flex: "0 0 26.00%",
                    height: "130px",
                    width: "10px",
                    position: "relative",
                    overflow: "hidden",
                    padding: "0px",
                  }}
                  key={item.category}
                  onMouseEnter={() =>
                    setVisible((prev) => ({ ...prev, [item.category]: true }))
                  }
                  onMouseLeave={() =>
                    setVisible((prev) => ({ ...prev, [item.category]: false }))
                  }
                >
                  <Image
                    src={item.imgSrc}
                    alt={item.category}
                    width={110}
                    fit="contain"
                    style={{
                      objectFit: "contain",
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  />
                  {visible[item.category] && (
                    <>
                      <Overlay blur={1} center style={{ overflow: "hidden" }}>
                        <Button
                          style={{
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            zIndex: 2, // to ensure the button is above the overlay
                            color: "#fff",
                          }}
                          onClick={() => {
                            // Function to handle "Find Similar" action
                          }}
                          color="dark"
                          size="xs"
                          compact
                        >
                          Find Similar
                        </Button>
                      </Overlay>
                    </>
                  )}
                </Container>
                {/* category & Example */}
                <Container
                  style={{
                    flex: 1,
                    display: "flex", // Use flexbox for center alignment
                    flexDirection: "column", // Stack children vertically
                    justifyContent: "center", // Center children vertically
                    boxSizing: "border-box",
                  }}
                >
                  <Text weight={500}>{item.category}</Text>
                  <Text size="sm">{item.example}</Text>
                </Container>
              </Container>
            ))}
          </Container>
        </SimpleGrid>
      </Paper>
    </div>
  );
}

export default SavedOutfits;
