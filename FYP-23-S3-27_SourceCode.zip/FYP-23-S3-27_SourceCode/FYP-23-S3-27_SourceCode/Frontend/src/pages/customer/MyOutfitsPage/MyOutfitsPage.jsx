import MyOutfits from "./MyOutfits";
const MyOutfitsPage = () => {
  return (
    <div>
      <MyOutfits />
      <br />
    </div>
  );
};

export default MyOutfitsPage;
