/* 
 Usecase:
 B31
 B34
*/
import { useState, useEffect } from "react";
import {
  createStyles,
  Text,
  rem,
  Tabs,
  SimpleGrid,
  Paper,
  ScrollArea,
  Container,
  TextInput,
  Select,
  Image,
} from "@mantine/core";
import { useNavigate } from "react-router-dom";
import { IconSquarePlus, IconSearch } from "@tabler/icons-react";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "Title-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },

  imageGroup: {
    justifyContent: "center", // Centers items horizontally within
    alignItems: "center", // Centers items vertically within the grid
  },
  Image: {
    justifyContent: "center",
    width: "130px", // Set image width (square)
    height: "130px", // Set image height (square)
    objectFit: "cover", // Covers the space without distorting the image
    alignItems: "center",
  },
}));
const mockOutfits = [
  {
    images: [
      "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2835&q=80",
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80",
      "",
    ],
    description: "Outfit 1 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1936&q=80",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1994&q=80",
      "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2030&q=80",
    ],
    description: "Outfit 2 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2835&q=80",
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80",
      "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2787&q=80",
    ],
    description: "Outfit 3 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1936&q=80",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1994&q=80",
      "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2030&q=80",
    ],
    description: "Outfit 4 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2835&q=80",
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80",
      "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2787&q=80",
    ],
    description: "Outfit 5 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1936&q=80",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1994&q=80",
      "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2030&q=80",
    ],
    description: "Outfit 6 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2835&q=80",
      "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80",
      "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2787&q=80",
    ],
    description: "Outfit 7 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1936&q=80",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1994&q=80",
      "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2030&q=80",
    ],
    description: "Outfit 8 ",
  },
  {
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1936&q=80",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1994&q=80",
      "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2030&q=80",
    ],
    description: "Outfit 6 ",
  },

  // ... add more outfits as needed
];
function useViewportWidth() {
  const [width, setWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => setWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return width;
}

export function MyOutfits(props) {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const [outfits, setOutfits] = useState(mockOutfits); // Initialize with mock data. Set to [] if you want to start with no outfits.
  const viewportWidth = useViewportWidth();
  const columns = viewportWidth <= 951.5 ? 2 : 3;

  const handleTabClick = (value) => {
    if (value === "first") {
      navigate("/MyOutfitsPage");
    } else if (value === "second") {
      navigate("/DressMePage");
    }
  };

  const handleIconClick = () => {
    navigate("/DressMePage");
  };

  return (
    <div className={classes.wrapper}>
      <div className={classes["Title-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          MY OUTFIT
        </Text>
      </div>
      <div className={classes["tabs-container"]}>
        <Tabs defaultValue="first" onTabChange={handleTabClick}>
          <Tabs.List
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              flexWrap: "nowrap", // Ensure no wrapping
            }}
          >
            <div style={{ display: "flex" }}>
              {" "}
              {/* Container for the Tabs */}
              <Tabs.Tab value="first" color="dark">
                Outfits
              </Tabs.Tab>
              <Tabs.Tab value="second" color="dark">
                Dress Me
              </Tabs.Tab>
            </div>

            <Container
              style={{
                display: "flex",
                maxWidth: "332px",
                margin: "0px",
                padding: "0px",
              }}
            >
              <TextInput
                placeholder="Search"
                icon={<IconSearch size="0.9rem" stroke={1.5} />}
                style={{
                  maxWidth: "180px",
                  minHeight: "10px",
                  flex: "0 0 auto",
                }}
              />
              <Select
                placeholder="Filter By"
                style={{
                  maxWidth: "110px",
                  marginLeft: "10px",
                  flex: "0 0 auto",
                }}
                data={[
                  { value: "Latest", label: "Latest" },
                  { value: "Oldest", label: "Oldest" },
                ]}
              />
            </Container>
          </Tabs.List>
        </Tabs>
      </div>
      <Paper
        padding="md"
        style={{
          width: "100%",
          height: "70%",
        }}
      >
        <ScrollArea
          h={
            660 *
            0.79 /* 79% of the Paper height in rem units (assuming 1 rem = 10px) */
          }
        >
          {outfits.length > 0 ? (
            <SimpleGrid
              cols={columns}
              spacing="xs"
              style={{ columnGap: "0px", rowGap: "0px" }}
            >
              {outfits.map((outfit, outfitIndex) => (
                <Container
                  key={outfitIndex}
                  style={{
                    marginTop: "10px",
                    padding: "0px",
                  }}
                >
                  <Container
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "center",
                      alignItems: "center",
                      borderRadius: "8px",
                      boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                      overflow: "hidden",
                      padding: "0px",
                    }}
                  >
                    <Container
                      className={classes.imageGroup}
                      style={{ padding: "0px" }}
                    >
                      <SimpleGrid
                        cols={2}
                        spacing={5}
                        className={classes.imageGroup}
                      >
                        {outfit.images.map((image, imageIndex) => (
                          <Image
                            key={imageIndex}
                            src={image}
                            width="130px" // You can adjust this according to your needs
                            height="130px" // You can adjust this according to your needs
                            withPlaceholder
                            placeholder={<Text align="center"></Text>}
                            className={classes.Image}
                            alt={`Image ${imageIndex + 1} of ${
                              outfit.description
                            }`}
                          />
                        ))}
                      </SimpleGrid>
                    </Container>
                  </Container>
                  <Text
                    align="left"
                    style={{
                      fontSize: "0.95rem",
                      fontWeight: 450,
                      color: "#212529",
                      width: "265px",
                      marginTop: "10px",
                    }}
                  >
                    {outfit.description}
                  </Text>
                </Container>
              ))}
            </SimpleGrid>
          ) : (
            <SimpleGrid cols={1} spacing="xs" verticalSpacing="xs">
              <Text
                align="center"
                fz="lg"
                style={{
                  marginTop: "150px",
                  fontSize: "1.2rem",
                  fontWeight: 500,
                  color: "#212529",
                }}
              >
                You Do Not Have An Existing Outfit <br />
                Click On The Plus Icon To Generate New Outfit
              </Text>
              <button
                style={{
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  padding: 0,
                }}
                onClick={handleIconClick}
              >
                <IconSquarePlus
                  size={30}
                  style={{
                    marginLeft: "auto",
                    marginRight: "auto",
                    display: "block",
                  }}
                />
              </button>
            </SimpleGrid>
          )}
        </ScrollArea>
      </Paper>
    </div>
  );
}

export default MyOutfits;
