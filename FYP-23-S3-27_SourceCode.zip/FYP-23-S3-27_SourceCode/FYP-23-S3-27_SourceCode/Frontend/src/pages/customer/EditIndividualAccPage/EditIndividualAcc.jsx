/* 
 Usecase:
 S06
 S07
 B06
 B07
*/
import {
  TextInput,
  SimpleGrid,
  createStyles,
  Container,
  Text,
  Button,
  Group,
  rem,
  Avatar,
  Paper,
  PasswordInput,
  Modal,
  ActionIcon,
  Select,
  FileButton,
  Alert,
  Space,
  Divider,
} from "@mantine/core";
import { DatePickerInput } from "@mantine/dates";
import { useForm, isNotEmpty, isEmail } from "@mantine/form";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../../contexts/AuthContext";
import {
  getUserDetails,
  updateUserDetails,
  deleteAccount,
} from "../../../services/authService";
import {
  IconExclamationCircle,
  IconAlertCircle,
  IconCalendar,
} from "@tabler/icons-react";
import { useNavigate } from "react-router-dom";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: "max-content",
  },

  bottomRightImage: {
    position: "absolute",
    bottom: 0,
    right: 0,
    //  set a width or height if you want to resize the image
    width: "300px",
    height: "300px",
    opacity: 0.2, // opacity
  },

  innerContainer: {
    width: "100%", // This ensures it takes the full width of the wrapper
    height: "8%", // Set the height to be 8% of the wrapper
    backgroundColor: "rgba(0, 0, 0, 1)",
    paddingLeft: "30px",
    display: "flex",
    alignItems: "center",
  },

  inner: {
    position: "relative",
    paddingTop: rem(10),
    marginLeft: rem(-8),

    [theme.fn.smallerThan("sm")]: {
      paddingBottom: rem(80),
      paddingTop: rem(80),
    },
  },

  paperStyle: {
    width: "100%", // or any specific width you want, e.g.
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontSize: rem(62),
    fontWeight: 900,
    lineHeight: 1.1,
    margin: 0,
    padding: 0,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(42),
      lineHeight: 1.2,
    },
  },

  description: {
    marginTop: theme.spacing.xl,
    fontSize: rem(24),

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(18),
    },
  },

  controls: {
    marginTop: `calc(${theme.spacing.xl} * 2)`,

    [theme.fn.smallerThan("sm")]: {
      marginTop: theme.spacing.xl,
    },
  },

  control: {
    height: rem(54),
    paddingLeft: rem(38),
    paddingRight: rem(38),

    [theme.fn.smallerThan("sm")]: {
      height: rem(54),
      paddingLeft: rem(18),
      paddingRight: rem(18),
      flex: 1,
    },
  },

  flexContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  leftGrid: {
    flex: 1,
  },

  rightGrid: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },

  tipText: {
    marginLeft: "10px",
    alignSelf: "center",
  },

  tipAndButtons: {
    marginLeft: "10px",
  },

  avatarGroup: {
    display: "flex",
    alignItems: "center",
  },

  buttonGroup: {
    display: "flex",
    justifyContent: "space-between",
    width: "100%",
    marginTop: "10px",
  },
}));

export function EditIndividualAcc() {
  const { classes } = useStyles();
  const [deleteModalOpened, setDeleteModalOpened] = useState(false);
  const [updateModalOpened, setUpdateModalOpened] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null); // 1. Add a state to hold the uploaded image
  const fileInputRef = useRef(null); // Reference to the hidden file input
  const { currentUser } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [alert, setAlert] = useState({ type: "", message: "" });
  const navigate = useNavigate();
  const form = useForm({
    initialValues: {
      newImage: null,
      id: currentUser.id,
      dname: currentUser.dname,
      fname: currentUser.fname,
      lname: currentUser.lname,
      email: currentUser.email,
      imageUrl: currentUser.imageUrl ? currentUser.imageUrl : "",
      birthday: currentUser.birthday,
      gender: currentUser.gender,
      newPassword: "",
      currentPassword: "",
      confirmPassword: "",
    },
    validate: {
      fname: isNotEmpty("First name is empty."),
      lname: isNotEmpty("Last name is empty."),
      dname: isNotEmpty("Display name is empty."),
      birthday: isNotEmpty("Birthday is empty."),
      gender: isNotEmpty("Gender is empty."),
      email: isEmail("Invalid email"),

      newPassword: (val) =>
        val.length < 8 && val.length > 0
          ? "Password should include more then 8 characters."
          : null,
      confirmPassword: (value) =>
        form.values.newPassword === value ? null : "Passwords do not match.",
    },
  });

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    form.setFieldValue("newImage", file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current.click(); // Trigger the hidden file input's click event
  };

  const handleSaveChanges = async (values) => {
    try {
      setIsLoading(true);
      const result = await updateUserDetails(values);
      /* location.reload(); */
      setAlert({ type: "success", message: "Changes saved." });
      form.setValues((prev) => ({
        ...prev,
        newPassword: "",
        confirmPassword: "",
        currentPassword: "",
      }));
      setUpdateModalOpened(false);
    } catch (error) {
      switch (error.code) {
        case "auth/duplicate-display-name":
          form.setFieldError(
            "dname",
            "An account with this display name already exists"
          );
          form.setFieldValue("currentPassword", "");
          setUpdateModalOpened(false);
          break;
        case "auth/email-already-in-use":
          form.setFieldError(
            "email",
            "An account with this email already exists"
          );
          form.setFieldValue("currentPassword", "");
          break;
        case "auth/wrong-password":
          form.setFieldError(
            "currentPassword",
            "Your current password is incorrect."
          );
          break;
        default:
          setAlert({ type: "failure", message: "Account update failed." });
          setUpdateModalOpened(false);
          form.setFieldValue("currentPassword", "");
      }
    } finally {
      setIsLoading(false);
    }
  };
  return (
    <div className={classes.wrapper}>
      <div className={classes.innerContainer}>
        <Text
          ta="left"
          fz="xl"
          style={{
            marginTop: "0",
            padding: "10px",
            color: "white",
          }}
          weight={500}
          mt="lg"
        >
          Edit Account
        </Text>
      </div>
      <Container size={700} className={classes.inner}>
        <Paper
          radius="md"
          withBorder={false}
          p="lg"
          style={{ maxWidth: "100rem" }}
          sx={(theme) => ({
            backgroundColor:
              theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
          })}
        >
          {alert.type !== "" && (
            <Alert
              icon={<IconAlertCircle size="1rem" />}
              title={alert.type === "success" ? "Success!" : "Bummer!"}
              color={alert.type === "success" ? "green" : "red"}
              style={{ marginBottom: "20px" }}
              withCloseButton
              closeButtonLabel="Close alert"
              onClose={() => {
                setAlert({ type: "", message: "" });
              }}
            >
              {alert.message}
            </Alert>
          )}
          <div className={classes.avatarGroup}>
            <Avatar
              src={uploadedImage ? uploadedImage : form.values.imageUrl}
              size={110}
              radius={120}
            />
            <div className={classes.tipAndButtons}>
              <Text>
                Tips: Its important to use your photo to gain credibility and
                confidence from potential buyers.
              </Text>
              <div className={classes.buttonGroup}>
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                  accept=".png, .jpg, .jpeg"
                  onChange={handleImageChange}
                />
                <Button variant="default" onClick={triggerFileInput}>
                  Update Profile Photo
                </Button>
                <Button
                  variant="default"
                  onClick={() => setDeleteModalOpened(true)} // Open the modal when clicked
                >
                  Delete Account
                </Button>
              </div>
            </div>
          </div>

          <form
            onSubmit={form.onSubmit(() => {
              setAlert({ message: "", type: "" });
              setUpdateModalOpened(true);
            })}
          >
            <TextInput
              label="Display Name"
              variant="filled"
              style={{ width: "50%", marginTop: "10px" }}
              {...form.getInputProps("dname")}
            />

            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <TextInput
                label="First Name"
                variant="filled"
                {...form.getInputProps("fname")}
              />
              <TextInput
                label="Last Name"
                variant="filled"
                {...form.getInputProps("lname")}
              />
            </SimpleGrid>
            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <DatePickerInput
                label="Birthday"
                variant="filled"
                {...form.getInputProps("birthday")}
              />
              <Select
                label="Gender"
                variant="filled"
                data={[
                  { value: "male", label: "Male" },
                  { value: "female", label: "Female" },
                ]}
                {...form.getInputProps("gender")} // Display the error message if validation fails
              />{" "}
              <TextInput
                label="Email"
                variant="filled"
                {...form.getInputProps("email")}
                // Display the error message if validation fails
              />
            </SimpleGrid>

            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <PasswordInput
                label="New Password"
                variant="filled"
                {...form.getInputProps("newPassword")}
              />
              <PasswordInput
                label="Confirm Password"
                variant="filled"
                {...form.getInputProps("confirmPassword")}
              />{" "}
            </SimpleGrid>
            <Group position="left" mt="xl">
              <Button
                type="submit"
                size="md"
                style={{ backgroundColor: "black", color: "white" }}
              >
                Save Changes
              </Button>
            </Group>
          </form>
        </Paper>
      </Container>

      <img
        src="https://img.freepik.com/free-vector/hand-drawn-monstera-leaf-outline-illustration_23-2150437552.jpg?w=826&t=st=1695134308~exp=1695134908~hmac=74776a4fa2441cb17caf364964cd5e1bcab268c056043d0886f7d00c514ddab9"
        alt="Description of Image"
        className={classes.bottomRightImage}
      />

      <Modal
        opened={deleteModalOpened}
        onClose={() => {
          form.setFieldValue("currentPassword", "");
          setDeleteModalOpened(false);
        }}
        title="Delete Account"
        size="md"
      >
        {" "}
        <form
          onSubmit={form.onSubmit(async () => {
            try {
              setIsDeleting(true);
              // Handle account deletion logic here
              await deleteAccount(form.values.currentPassword);
              navigate("/");
            } catch (error) {
              setAlert({
                type: "failure",
                message: "Account deletion failed.",
              });

              form.setFieldValue("currentPassword", "");
              setIsDeleting(false);
              setDeleteModalOpened(false);
            }
          })}
        >
          <Text fw={500}>Are you sure you want to delete your account?</Text>
          <Space h="lg" />
          <PasswordInput
            label="Password"
            description={"Enter your current password to delete your account."}
            {...form.getInputProps("currentPassword")}
          />
          <Group position="apart" style={{ marginTop: "20px" }}>
            <Button
              type="submit"
              style={{ backgroundColor: "black", color: "white" }}
              loading={isDeleting}
            >
              Yes, delete it
            </Button>
            <Button
              onClick={() => {
                form.setFieldValue("currentPassword", "");
                setDeleteModalOpened(false);
              }}
              /* style={{ backgroundColor: "black", color: "white" }} */
              variant="default"
            >
              No, keep it
            </Button>
          </Group>
        </form>
      </Modal>

      <Modal
        opened={updateModalOpened}
        onClose={() => {
          form.setFieldValue("currentPassword", "");
          setUpdateModalOpened(false);
        }}
        title="Save changes"
        size="md"
      >
        <form onSubmit={form.onSubmit(handleSaveChanges)}>
          {/*           <Space h="xl" /> */}
          <PasswordInput
            label="Current Password"
            description={"Enter your current password to update your account."}
            {...form.getInputProps("currentPassword")}
          />
          <Group position="apart" style={{ marginTop: "20px" }}>
            <Button
              type="submit"
              style={{ backgroundColor: "black", color: "white" }}
              color="dark"
              loading={isLoading}
            >
              Submit
            </Button>
            <Button
              onClick={() => {
                form.setFieldValue("currentPassword", "");
                setUpdateModalOpened(false);
              }}
              /* style={{ backgroundColor: "black", color: "white" }} */
              variant="default"
              color="gray"
            >
              Cancel
            </Button>
          </Group>
        </form>
      </Modal>
    </div>
  );
}

export default EditIndividualAcc;
