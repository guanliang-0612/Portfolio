import {
  Card,
  Grid,
  Paper,
  ScrollArea,
  SimpleGrid,
  Skeleton,
  Tabs,
  Text,
  createStyles,
  rem,
  Flex,
  Button,
  Stack,
  Container,
  Divider,
  Avatar,
  Space,
  Group,
  Textarea,
  Switch,
  Alert,
} from "@mantine/core";
import { useForm, isNotEmpty } from "@mantine/form";
import ContentContainer from "../../../components/ContentContainer";
import { IconArrowBadgeLeft, IconAlertCircle } from "@tabler/icons-react";
import { useNavigate, useParams } from "react-router-dom";
import React, { useState, useEffect, useCallback } from "react";
// import TextareaAutosize from "react-textarea-autosize";
// import { useAuth } from "../../../contexts/AuthContext";
import {
  getAutoReply,
  addAutoReply,
  updateAutoReply,
  changeAutoReplyStatus,
} from "../../../services/userService";
import { useAuth } from "../../../contexts/AuthContext";

const useStyles = createStyles((theme) => {
  return {
    headerWrapper: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      height: "100%",
      width: "100%",
      padding: "10px",
    },
  };
});

export default function AutoReplyPage() {
  const { currentUser } = useAuth();
  const { classes, cx } = useStyles();
  const navigate = useNavigate();
  const [alert, setAlert] = useState({ message: "", type: "" });
  const [autoReplyIsNew, setAutoReplyIsNew] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const form = useForm({
    initialValues: {
      message: "",
      isActive: false,
      id: currentUser.id,
    },
    validate: {
      message: (val) =>
        form.values.isActive && val.length === 0
          ? "Fill in an auto reply message."
          : null,
    },
  });

  useEffect(() => {
    async function getData() {
      const data = await getAutoReply(currentUser.id);
      if (!data) {
        setAutoReplyIsNew(true);
      }
      form.setValues(data);
    }
    getData();
  }, [currentUser.id]);

  async function handleSubmit(values) {
    try {
      setIsSubmitting(true);
      setAlert({ type: "", message: "" });
      if (autoReplyIsNew) {
        await addAutoReply(values);
        setAlert({
          type: "success",
          message: "Auto Reply saved.",
        });
      } else {
        await updateAutoReply(values);
        setAlert({
          type: "success",
          message: "Auto Reply saved.",
        });
      }
    } catch (error) {
      setAlert({ type: "failure", message: "Failed to save changes." });
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleStatusChange(isActive) {
    try {
      setAlert({ type: "", message: "" });
      const id = currentUser.id;
      await changeAutoReplyStatus({ isActive, id });
      /* setAlert({ type: "success", message: "Auto reply status updated." }); */
    } catch (error) {
      form.setFieldValue("isActive", !isActive);
      setAlert({ type: "failure", message: error.message });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <ContentContainer>
      <ContentContainer.Header>
        <Group className={classes.headerWrapper}>
          <Text c="white">Auto Reply</Text>
          <Button
            compact
            color="white"
            variant="default"
            leftIcon={<IconArrowBadgeLeft />}
            onClick={() => navigate(-1)}
          >
            Back
          </Button>
        </Group>
      </ContentContainer.Header>
      <Container className={classes.con}>
        <form onSubmit={form.onSubmit(handleSubmit)}>
          {alert.type && (
            <Alert
              icon={<IconAlertCircle size="1rem" />}
              title={alert.type === "success" ? "Success!" : "Bummer!"}
              color={alert.type === "success" ? "green" : "red"}
              style={{ margin: "10px" }}
              withCloseButton
              closeButtonLabel="Close alert"
              onClose={() => {
                setAlert({ type: "", message: "" });
              }}
            >
              {alert.message}
            </Alert>
          )}
          <Space h="md" />
          <Text>Set your automatic reply message here.</Text>
          <Space h="md" />
          <Text>
            This message will be sent to users that message you while you're
            away.
          </Text>
          <Space h="md" />
          <Textarea
            placeholder="Type here..."
            label="Your Auto Reply Message"
            radius="md"
            size="md"
            {...form.getInputProps("message")}
          />
          <Space h="sm" />
          <Switch
            {...form.getInputProps("isActive", { type: "checkbox" })}
            onChange={(event) => {
              const { onChange } = form.getInputProps("isActive", {
                type: "checkbox",
              });
              onChange(event);
              handleStatusChange(event.currentTarget.checked);
            }}
            labelPosition="left"
            label="Auto Reply"
            onLabel="ON"
            offLabel="OFF"
            size="md"
            color="dark"
          />
          <Flex justify="flex-end" align="center">
            <Button type="submit" color="dark" loading={isSubmitting}>
              Save Changes
            </Button>
          </Flex>
        </form>
      </Container>
    </ContentContainer>
  );
}
