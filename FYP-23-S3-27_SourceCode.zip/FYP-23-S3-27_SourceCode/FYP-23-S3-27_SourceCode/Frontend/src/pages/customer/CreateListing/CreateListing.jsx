/* 
 Usecase:
 S08
*/
import { useState, useEffect } from "react";
import { Stepper, Button, Group, Code } from "@mantine/core";
import { useForm, isNotEmpty } from "@mantine/form";
import UploadImage from "./components/UploadImages";
import ListingInfoForm from "./components/ListingInfoForm";
import {
  saveListing,
  getClothingAttributes,
} from "../../../services/listingService";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../../contexts/AuthContext";
//import { getClothingAttributes } from "../../../services/listingService";
export default function CreateListing() {
  const [active, setActive] = useState(0);
  const maxSteps = 1;
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [toSuggest, setToSuggest] = useState(true);
  const [isSuggested, setIsSuggested] = useState({
    category: false,
    style: false,
    colour: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const form = useForm({
    initialValues: {
      files: [],
      name: "",
      price: 0,
      condition: "",
      section: "",
      status: "",
      category: "",
      colour: "",
      details: "",
      style: "",
      sellerId: currentUser?.id,
    },

    validate: (values) => {
      let errors = {};

      if (active === 0) {
        if (!values.files.length) {
          errors.files = "At least one image is required.";
        }
      } else if (active === 1) {
        if (!values.name.trim()) {
          errors.name = "Listing Name is required";
        }
        if (values.price === undefined) {
          errors.price = "Price is required";
        }
        if (!values.details.trim()) {
          errors.details = "Listing Details is required";
        }
        if (!values.section.trim()) {
          errors.section = "Please select a section";
        }
        if (!values.condition.trim()) {
          errors.condition = "Please select a condition";
        }
        if (!values.status.trim()) {
          errors.status = "Please select a status";
        }
      }

      return errors;
    },
  });

  useEffect(() => {
    async function getData() {
      if (!toSuggest) return;
      if (!form.values.files.length) return;
      const imageUrl = URL.createObjectURL(form.values.files[0]);
      const result = await getClothingAttributes(imageUrl);
      URL.revokeObjectURL(imageUrl);
      const { category, colour, style } = result;
      form.setValues((prev) => ({ ...prev, category, colour, style }));
      setToSuggest(false);
      setIsSuggested({
        category: true,
        style: true,
        colour: true,
      });
    }
    getData();
  }, [form, toSuggest]);

  const nextStep = () =>
    setActive((current) => {
      /* if (form.validate().hasErrors) {
        return current;
      } */
      return current < 1 ? current + 1 : current;
    });

  const prevStep = () =>
    setActive((current) => (current > 0 ? current - 1 : current));

  async function handleSubmit(values) {
    // Check if the form is valid before proceeding with the submission
    const errors = form.validate(); // This should run the validation method you provided to useForm
    if (errors.hasErrors) {
      return;
    }

    setIsSubmitting(true); // disable the form/button
    try {
      const data = await saveListing(values);
      if (!data) {
        // TODO ADD ERROR HANDLING

        return null;
      }
      navigate(`/listing/${data}`);
    } finally {
      setIsSubmitting(false); // re-enable the form/button
    }
  }
  return (
    <form onSubmit={form.onSubmit(handleSubmit)} id="createListingForm">
      <Stepper active={active} color="black" breakpoint="sm">
        <Stepper.Step label="First step" description="Upload photos">
          <UploadImage
            files={form.values.files}
            setFiles={(files) => {
              form.setValues((prev) => {
                return {
                  ...prev,
                  files: [...prev.files, ...files],
                };
              });
            }}
            removeFile={(index) => {
              if (index === 0) {
                setToSuggest(true);
              }
              form.setValues((prev) => {
                let filesCopy = [...prev.files];
                filesCopy.splice(index, 1);
                return {
                  ...prev,
                  files: [...filesCopy],
                };
              });
            }}
          />
        </Stepper.Step>

        <Stepper.Step label="Second step" description="Listing information">
          <ListingInfoForm
            form={form}
            isSuggested={isSuggested}
            setIsSuggested={setIsSuggested}
          />
          <Stepper.Completed>
            Completed! Form values:
            <Code block mt="xl">
              {JSON.stringify(form.values, null, 2)}
            </Code>
          </Stepper.Completed>
        </Stepper.Step>
      </Stepper>
      <Group position="right" mt="xl">
        {active !== 0 && (
          <Button variant="default" onClick={prevStep}>
            Back
          </Button>
        )}
        {active === maxSteps ? (
          <Button
            style={{ background: "black" }}
            type="submit"
            form="createListingForm"
            onClick={() => {
              handleSubmit(form.values);
            }}
            loading={isSubmitting} // added this
          >
            Submit
          </Button>
        ) : (
          <Button
            style={{ background: form.values.files.length > 0 && "black" }}
            onClick={(event) => {
              event.preventDefault();

              if (form.values.files.length) nextStep();
            }}
            disabled={form.values.files.length === 0}
            type="button"
          >
            Next step
          </Button>
        )}
      </Group>
    </form>
  );
}
