import {
  Container,
  Flex,
  Select,
  TextInput,
  createStyles,
  Autocomplete,
  SimpleGrid,
  Grid,
  Image,
  Textarea,
  AspectRatio,
  NumberInput,
  Badge,
} from "@mantine/core";
import { useState, useEffect } from "react";
import { IconSearch, IconCurrencyDollarSingapore } from "@tabler/icons-react";

const useStyles = createStyles((theme) => ({
  inputWrapper: {
    display: "flex",
    alignItems: "center",
  },
  inputLabel: {
    width: "5em",
  },
  gridContainer: {
    display: "grid",
    gap: "1em",
    padding: 0,
    gridTemplateColumns: "1fr 5fr 6fr",
    /* gridTemplateAreas: `
    "previews mainImage mainImage mainImage   listingName listingName listingName listingName" 
    "previews mainImage mainImage mainImage    price . . ." 
    "previews mainImage mainImage mainImage    condition condition status status" 
    "previews mainImage mainImage mainImage    category category . ." 
    "previews mainImage mainImage mainImage    colour colour colour colour" 
    "previews mainImage mainImage mainImage    details details details details"`, */
    gridTemplateAreas: `"previews mainImage formContainer"`,
  },
  formContainer: {
    gridArea: "formContainer",
    margin: 0,
    padding: 0,
  },
  fieldContainer: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  previews: {
    gridArea: "previews",
    display: "flex",
    flexDirection: "column",
    gap: "1em",
  },
  mainImage: {
    gridArea: "mainImage",
  },
  listingName: {
    gridArea: "listingName",
  },
  price: {
    gridArea: "price",
  },
  section: {
    gridArea: "section",
  },
  condition: {
    gridArea: "condition",
  },
  status: {
    gridArea: "status",
  },
  category: {
    gridArea: "category",
  },
  colour: {
    gridArea: "colour",
  },
  style: {
    gridArea: "style",
  },
  details: {
    gridArea: "details",
  },
  formFields: {
    gridArea: "formFields",
    display: "grid",
    height: "min-content",
    width: "100%",
    columnGap: "10px",
    gridTemplateColumns: "6fr 4fr",
    gridTemplateAreas: `"listingName listingName"
                        "price price "
                        "condition condition"
                        "category category"
                        "style style"
                        "colour colour"
                        "details details"`,
    gridTemplateRows: " 0.6fr 0.6fr 0.6fr 0.6fr 0.6fr 0.6fr 0.6fr ",
  },
  mainImageContainer: {
    position: "relative",
  },
  mainImageStyle: {
    objectFit: "contain",
  },
  previewImageStyle: {
    objectFit: "cover",
    marginBottom: "5px", // Space between stacked images
    cursor: "pointer",
    borderRadius: "1em",
    borderColor: "black",
  },
}));

export default function ListingInfoForm({
  form,
  isSuggested = { category: false, style: false, colour: false },
  setIsSuggested = () => {},
}) {
  const [fieldsAreSuggested, setFieldsAreSuggested] = useState(isSuggested);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [currentImageUrl, setCurrentImageUrl] = useState("");
  useEffect(() => {
    let imageUrl = "";
    if (typeof form.values.files[currentImageIndex] !== "string") {
      imageUrl = URL.createObjectURL(form.values.files[currentImageIndex]);
    } else {
      imageUrl = form.values.files[currentImageIndex];
    }

    setCurrentImageUrl(imageUrl);
    return () => URL.revokeObjectURL(currentImageUrl);
  }, [currentImageIndex]);
  const { classes, cx } = useStyles();
  const colours = [
    { value: "beige", label: "Beige" },
    { value: "black", label: "Black" },
    { value: "blue", label: "Blue" },
    { value: "brown", label: "Brown" },
    { value: "gold", label: "Gold" },
    { value: "green", label: "Green" },
    { value: "grey", label: "Grey" },
    { value: "multicoloured", label: "Multi-coloured" },
    { value: "orange", label: "Orange" },
    { value: "pink", label: "Pink" },
    { value: "purple", label: "Purple" },
    { value: "red", label: "Red" },
    { value: "silver", label: "Silver" },
    { value: "turquoise", label: "Turquoise" },
    { value: "white", label: "White" },
    { value: "yellow", label: "Yellow" },
  ];
  const styles = [
    { value: "formal wear", label: "Formal" },
    { value: "casual wear", label: "Casual" },
    { value: "smart casual wear", label: "Smart Casual" },
  ];
  const category = [
    { value: "topwear", label: "Tops" },
    { value: "bottomwear", label: "Bottoms" },
    { value: "footwear", label: "Footwear" },
    { value: "outerwear", label: "Outerwear" },
    { value: "dress", label: "Dresses" },
  ];
  return (
    <div className={classes.gridContainer}>
      <Container className={classes.previews}>
        {form.values.files.map((file, index) => {
          const imageUrl =
            typeof file === "string" ? file : URL.createObjectURL(file);

          return (
            <Image
              key={index}
              src={imageUrl}
              onLoad={() => {
                typeof file === "string" || URL.revokeObjectURL(file);
              }}
              alt={`Preview ${index}`}
              className={classes.previewImageStyle}
              onClick={() => setCurrentImageIndex(index)}
            />
          );
        })}
      </Container>

      <AspectRatio className={classes.mainImage} ratio={4 / 5}>
        <Image
          src={currentImageUrl}
          onLoad={() => {
            typeof form.values.files[currentImageIndex] === "string" ||
              URL.revokeObjectURL(currentImageUrl);
          }}
          className={classes.mainImageStyle}
          style={{ height: "540px" }}
        />
      </AspectRatio>
      {console.log()}
      <Container className={classes.formContainer}>
        <Container style={{ padding: "0px" }}>
          <div className={classes.formFields}>
            <TextInput
              label="Listing Name"
              className={classes.listingName}
              {...form.getInputProps("name")}
            />
            <div
              className={classes.price}
              style={{ display: "flex", justifyContent: "space-between" }}
            >
              <NumberInput
                label="Price"
                /*  w={"8em"} */
                min={0}
                icon={<IconCurrencyDollarSingapore size="1rem" />}
                precision={2}
                step={0.01}
                {...form.getInputProps("price")}
              />
              <Select
                className={classes.section}
                label="Section"
                data={["Women", "Men"]}
                {...form.getInputProps("section")}
              />
            </div>
            <div
              className={classes.condition}
              style={{ display: "flex", justifyContent: "space-between" }}
            >
              <Select
                className={classes.condition}
                label="Condition"
                data={["Brand New", "Preloved", "Well Used"]}
                {...form.getInputProps("condition")}
              />

              <Select
                className={classes.status}
                label="Status"
                data={["Available", "Unavailable", "Reserved"]}
                {...form.getInputProps("status")}
              />
            </div>
            <div
              className={cx(classes.category, classes.fieldContainer)}
              style={{ display: "flex" }}
            >
              <Select
                classNames={{
                  root: classes.inputWrapper,
                  label: classes.inputLabel,
                }}
                className={classes.category}
                label="Category"
                data={category}
                {...form.getInputProps("category")}
                onChange={(value) => {
                  const { onChange } = form.getInputProps("category");
                  setIsSuggested((prev) => ({
                    ...prev,
                    category: false,
                  }));
                  onChange(value);
                }}
              />
              {isSuggested?.category && <Badge>Suggested</Badge>}
            </div>
            <div
              className={cx(classes.style, classes.fieldContainer)}
              style={{ display: "flex" }}
            >
              <Select
                classNames={{
                  root: classes.inputWrapper,
                  label: classes.inputLabel,
                }}
                className={classes.style}
                label="Style"
                data={styles}
                {...form.getInputProps("style")}
                onChange={(value) => {
                  const { onChange } = form.getInputProps("style");
                  setIsSuggested((prev) => ({
                    ...prev,
                    style: false,
                  }));
                  onChange(value);
                }}
              />
              {isSuggested?.style && <Badge>Suggested</Badge>}
            </div>
            <div
              className={cx(classes.colour, classes.fieldContainer)}
              style={{ display: "flex" }}
            >
              <Select
                classNames={{
                  root: classes.inputWrapper,
                  label: classes.inputLabel,
                }}
                className={classes.colour}
                label="Colour"
                data={colours}
                inputWrapperOrder={["label", "input", "description", "error"]}
                searchable
                rightSection={
                  <div>
                    <IconSearch
                      size="1rem"
                      style={{ display: "block", opacity: 0.5 }}
                    />
                  </div>
                }
                {...form.getInputProps("colour")}
                onChange={(value) => {
                  const { onChange } = form.getInputProps("colour");
                  setIsSuggested((prev) => ({
                    ...prev,
                    colour: false,
                  }));
                  onChange(value);
                }}
              />
              {isSuggested?.colour && <Badge>Suggested</Badge>}
            </div>
            <div className={classes.details}>
              <Textarea label="Details" {...form.getInputProps("details")} />
            </div>
          </div>
        </Container>
      </Container>
    </div>
    /*     {
        userAction === "signin" ?
        <DisplayLoginForm /> : <DisplayRegisterForm />
    } */
  );
}
