import { useEffect, useRef, useState } from "react";
import {
  Text,
  Group,
  Button,
  createStyles,
  rem,
  Image,
  SimpleGrid,
  Container,
  Space,
  Skeleton,
  Grid,
  getStylesRef,
  Checkbox,
} from "@mantine/core";
import { Dropzone, MIME_TYPES } from "@mantine/dropzone";
import {
  IconCloudUpload,
  IconX,
  IconDownload,
  IconTrash,
} from "@tabler/icons-react";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: rem(30),
  },

  dropzone: {
    borderWidth: rem(1),
    paddingBottom: rem(50),
  },
  overlayBlur: {
    // assign reference to selector
    ref: getStylesRef("overlayBlur"),
    backgroundColor: theme.colors.gray[2],
    height: "100%",
    width: "100%",
    position: "absolute",
    opacity: 0.0,
    display: "flex",

    justifyContent: "center",
    alignItems: "center",
    zIndex: 1,
    transition: "0.05s ease-in-and-out",
  },
  overlayIcon: {
    // assign reference to selector
    ref: getStylesRef("overlayIcon"),
    height: "100%",
    width: "100%",
    position: "absolute",
    opacity: 1,
    display: "flex",
    padding: "0.25em",
    justifyContent: "right",
    alignItems: "start",
    zIndex: 1,
    transition: "0.1s ease-in-out",
  },
  imageWrapper: {
    position: "relative",
    overflow: "clip",
    borderRadius: "5%",
    height: "5em",
    /* [`&:hover .${getStylesRef("overlayIcon")}`]: {
      opacity: 1,
    }, */
    [`&:hover .${getStylesRef("overlayBlur")}`]: {
      opacity: 0.8,
    },
    /* [`&:hover .${getStylesRef("image")}`]: {
      filter: "blur(0.25em)",
    }, */
    [`&:hover .${getStylesRef("icon")}`]: {
      opacity: 1,
    },
    "&:hover": {
      boxShadow: "0 3px 10px rgb(0 0 0 / 0.3)",
    },
    cursor: "pointer",
  },
  image: {
    ref: getStylesRef("image"),
    width: "auto",
    height: "100%",
    objectFit: "cover",
    transition: "0.1s ease-in-out",
  },
  /* iconWrapper: {
    width: "100%",
    height: "100%",
    /* backgroundColor: theme.colors.gray[0],
    borderRadius: "5%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  }, */
  icon: {
    ref: getStylesRef("icon"),
    zIndex: 3,
    opacity: 0,
    margin: "0.1em",
    color: theme.colors.red[9],
    transition: "0.1s ease-in-out",
  },

  disabled: {
    backgroundColor:
      theme.colorScheme === "dark"
        ? theme.colors.dark[6]
        : theme.colors.gray[0],
    borderColor:
      theme.colorScheme === "dark"
        ? theme.colors.dark[5]
        : theme.colors.gray[2],
    cursor: "not-allowed",

    "& *": {
      color:
        theme.colorScheme === "dark"
          ? theme.colors.dark[3]
          : theme.colors.gray[5],
    },
  },
  control: {
    position: "absolute",
    width: rem(250),
    left: `calc(50% - ${rem(125)})`,
    bottom: rem(-20),
  },
}));

export default function UploadImage({
  files = [],
  setFiles = ([]) => {},
  removeFile = () => {},
  maxAllowed = 5,
}) {
  const { classes, theme } = useStyles();
  const openRef = useRef(null);
  const previews = files.map((file, index) => {
    const imageUrl =
      typeof file === "string" ? file : URL.createObjectURL(file);
    return (
      <div
        className={classes.imageWrapper}
        key={index}
        role="button"
        onClick={() => {
          removeFile(index);
        }}
      >
        <div className={classes.overlayBlur}></div>
        <div className={classes.overlayIcon}>
          <IconTrash stroke={1.5} className={classes.icon} />
        </div>
        <Image
          src={imageUrl}
          className={classes.image}
          imageProps={{ onLoad: () => URL.revokeObjectURL(imageUrl) }}
        />
      </div>
    );
  });
  const PRIMARY_COL_HEIGHT = rem(300);
  const SECONDARY_COL_HEIGHT = `calc(${PRIMARY_COL_HEIGHT} / 2 - ${theme.spacing.md} / 2)`;

  return (
    <SimpleGrid cols={2}>
      <Container className={classes.dropzoneWithPreview}>
        <div className={classes.wrapper}>
          <Dropzone
            openRef={openRef}
            onDrop={(newFiles) => {
              if (files.length < 5) {
                const numberOfFilesToAccept = maxAllowed - files.length;
                setFiles(newFiles.slice(0, numberOfFilesToAccept));
              }
            }}
            maxFiles={5}
            className={
              files.length < maxAllowed ? classes.dropzone : classes.disabled
            }
            radius="md"
            multiple={true}
            accept={[
              MIME_TYPES.jpeg,
              MIME_TYPES.png,
              MIME_TYPES.avif,
              MIME_TYPES.webp,
            ]}
            maxSize={30 * 1024 ** 2}
            disabled={files.length < maxAllowed ? false : true}
          >
            <div style={{ pointerEvents: "none" }}>
              <Group position="center">
                <Dropzone.Accept>
                  <IconDownload
                    size={rem(50)}
                    color={theme.colors[theme.primaryColor][6]}
                    stroke={1.5}
                  />
                </Dropzone.Accept>
                <Dropzone.Reject>
                  <IconX
                    size={rem(50)}
                    color={theme.colors.red[6]}
                    stroke={1.5}
                  />
                </Dropzone.Reject>
                <Dropzone.Idle>
                  <IconCloudUpload
                    size={rem(50)}
                    color={
                      theme.colorScheme === "dark"
                        ? theme.colors.dark[0]
                        : theme.black
                    }
                    stroke={1.5}
                  />
                </Dropzone.Idle>
              </Group>

              <Text ta="center" fw={700} fz="lg" mt="xl">
                <Dropzone.Accept>Drop photos here</Dropzone.Accept>
                <Dropzone.Reject>
                  Incorrect file format or larger than 30mb
                </Dropzone.Reject>
                <Dropzone.Idle>Click to select photos</Dropzone.Idle>
              </Text>
              <Text ta="center" fz="sm" mt="xs" c="dimmed">
                Or drag photos here.
                <br /> We only accept <i>.jpeg</i> or <i>.png</i> files that are
                less than 30mb in size.
              </Text>
            </div>
          </Dropzone>

          {/* <Button
              className={classes.control}
              size="md"
              radius="xl"
              onClick={() => openRef.current?.()}
            >
              Select files
            </Button> */}
        </div>
        <Space />{" "}
        <SimpleGrid
          cols={4}
          breakpoints={[{ maxWidth: "sm", cols: 1 }]}
          mt={previews.length > 0 ? "xl" : 0}
        >
          {previews}
        </SimpleGrid>
      </Container>
      <Container className={classes.instruction}>
        <Text fw={700}>Tips for creating a listing :</Text>
        <Text>
          <p>
            The first photo selected would be the cover page for your listing.
          </p>
          <br />
          Please ensure that the product has a clear background.
        </Text>
      </Container>
    </SimpleGrid>
  );
}
