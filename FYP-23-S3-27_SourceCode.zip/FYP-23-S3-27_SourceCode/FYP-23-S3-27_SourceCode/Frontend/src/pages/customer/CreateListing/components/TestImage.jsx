import { Checkbox, Image, createStyles, getStylesRef } from "@mantine/core";
import { IconTrash } from "@tabler/icons-react";
import { useState } from "react";

const useStyles = createStyles((theme) => ({
  imageWrapper: {
    position: "relative",
  },
  checkbox: {
    position: "absolute",
    zIndex: 2,
    height: "25%",
    width: "25%",
  },
}));

export default function TestImage() {
  const { classes } = useStyles();
  const [isChecked, setIsChecked] = useState();

  return (
    <div className={classes.imageWrapper} onMouseEnter={() => {}} role="button">
      <Checkbox className={classes.checkbox} size="xl" />

      <Image
        className={classes.image}
        onMouseEnter={() => {}}
        src={
          "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
        }
      />
    </div>
  );
}
