import DressMe from "./DressMe";
const DressMePage = () => {
  return (
    <div>
      <DressMe />
      <br />
    </div>
  );
};

export default DressMePage;
