/* 
 Usecase:
 B27
 B28
 B29
*/
import { useState } from "react";
import onepiece from "./Image/onepiece.jpg";
import twopiece from "./Image/twopiece.jpg";
import threepiece from "./Image/threepiece.jpg";
import {
  createStyles,
  Text,
  rem,
  Tabs,
  SimpleGrid,
  Paper,
  Button,
  TextInput,
  Container,
  Image,
  Overlay,
  Modal,
  useMantineTheme,
  Group,
  Select,
  Radio,
} from "@mantine/core";
import { useNavigate } from "react-router-dom";
import { useForm } from "@mantine/form";
import { useDisclosure } from "@mantine/hooks";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(800),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "Title-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "71px",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },
  // for right side
  grid: {
    display: "grid",
    gridTemplateColumns: "1fr 2fr",
    gap: "1rem", // or whatever gap you want between grid items
  },
  hoverIcon: {
    "&:hover": {
      color: "rgb(250, 82, 82)", // Use the specified red color
    },
  },
}));

const mockData = {
  outfitName: "Chic Summer Collection",
  items: [
    {
      category: "Outerwear",
      example: "Example: Jacket, coats, or cardigans",
      imgSrc:
        "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2835&q=80", // Replace with actual image URL
    },
    {
      category: "Top",
      example: "Example: Shirt, blouse, or sweater",
      imgSrc:
        "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80", // Replace with actual image URL
    },
    {
      category: "Bottom",
      example: "Example: Jeans, shorts, or skirt",
      imgSrc:
        "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80", // Replace with actual image URL
    },
    {
      category: "Footwear",
      example: "Example: Sneakers, boots, or sandals",
      imgSrc:
        "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2787&q=80", // Replace with actual image URL
    },
  ],
};

export function DressMe(props) {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const handleTabClick = (value) => {
    if (value === "first") {
      navigate("/MyOutfitsPage");
    } else if (value === "second") {
      navigate("/DressMePage");
    }
  };

  const [visible, setVisible] = useState({});
  const [opened, { open, close }] = useDisclosure(false);
  const theme = useMantineTheme();
  const form = useForm({
    initialValues: {
      outfitName: mockData.outfitName,
    },
  });

  return (
    <div className={classes.wrapper}>
      <div className={classes["Title-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          MY OUTFIT
        </Text>
      </div>
      {/* Add Tabs here */}
      <div className={classes["tabs-container"]}>
        <Tabs defaultValue="second" onTabChange={handleTabClick}>
          <Tabs.List>
            <Tabs.Tab value="first" color="dark">
              Outfits
            </Tabs.Tab>
            <Tabs.Tab value="second" color="dark">
              Dress Me
            </Tabs.Tab>
          </Tabs.List>
        </Tabs>
      </div>
      {/* End of Tabs */}

      <Paper
        padding="md"
        style={{
          width: "100%",
          height: "100%",
          marginTop: "10px",
        }}
      >
        <SimpleGrid cols={2} spacing="xs" verticalSpacing="xs" align="left">
          {/* Left Side Content */}
          <form onSubmit={form.onSubmit(() => {})}>
            <Container>
              <div style={{ marginBottom: "10px" }}>
                <Text weight={500}>Dress Me</Text>
                <Text style={{ marginTop: "10px", marginBottom: "10px" }}>
                  Please select the department and the type of outfit and let
                  our AI suggest it for you ~{" "}
                </Text>
                <Select
                  label="Department of outfit"
                  placeholder="Pick one"
                  required
                  data={[
                    {
                      value: "Women’s Department",
                      label: "Women’s Department",
                    },
                    { value: "Mens’s Department", label: "Mens’s Department" },
                  ]}
                  style={{ maxWidth: "300px", flex: 1 }}
                  styles={(theme) => ({
                    input: {
                      "&:focus-within": {
                        borderColor: theme.colors.dark[7],
                      },
                    },
                  })}
                />
                <Radio.Group
                  style={{ marginTop: "10px" }}
                  name="selectoutfit"
                  label="Select the types of outfit"
                  withAsterisk
                >
                  <Group mt="xs" style={{ marginTop: "10px", padding: "0" }}>
                    <Radio
                      value="onepiece"
                      label="One Piece"
                      style={{ margin: "0", padding: "0 32px 0 0" }}
                      color="dark"
                    />
                    <Radio
                      value="twopiece"
                      label="Two Piece"
                      style={{ margin: "0", padding: "0 34px 0 0" }}
                      color="dark"
                    />
                    <Radio
                      value="threepiece"
                      label="Three Piece"
                      style={{ margin: "0", padding: "0 0 0 0" }}
                      color="dark"
                    />
                  </Group>
                </Radio.Group>
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  position: "relative",
                }}
              >
                <SimpleGrid cols={3} spacing="xs" verticalSpacing="xs">
                  <Image
                    src={onepiece}
                    alt="Image 1"
                    style={{ width: "100%" }}
                    withPlaceholder
                    placeholder={<Text align="center"></Text>}
                  />
                  <Image
                    src={twopiece}
                    alt="Image 2"
                    style={{ width: "100%" }}
                    withPlaceholder
                    placeholder={<Text align="center"></Text>}
                  />
                  <Image
                    src={threepiece}
                    alt="Image 3"
                    style={{ width: "100%" }}
                    withPlaceholder
                    placeholder={<Text align="center"></Text>}
                  />
                </SimpleGrid>
              </div>
              <Button
                type="submit"
                size="xs"
                variant="outline"
                color="dark"
                style={{
                  marginTop: "20px",
                  maxWidth: "100px",
                  maxHeight: "35px",
                }}
              >
                Generate
              </Button>
              <Button
                size="xs"
                variant="outline"
                color="dark"
                style={{
                  marginTop: "20px",
                  marginLeft: "10px",
                  maxWidth: "150px",
                  maxHeight: "35px",
                }}
                onClick={open}
              >
                Save Generated Outfit
              </Button>

              <Modal
                opened={opened}
                onClose={close}
                title="Save Generated Outfit"
                overlayProps={{
                  color:
                    theme.colorScheme === "dark"
                      ? theme.colors.dark[9]
                      : theme.colors.gray[2],
                  opacity: 0.55,
                  blur: 3,
                }}
              >
                <form onSubmit={form.onSubmit(() => {})}>
                  {/* Modal content */}
                  <Text>
                    Enter the Outfit Name and click on save to save outfit.
                  </Text>
                  <TextInput
                    name="OutfitName"
                    label="Outfit Name"
                    styles={(theme) => ({
                      input: {
                        "&:focus-within": {
                          borderColor: theme.colors.dark[7],
                        },
                      },
                    })}
                    style={{ maxWidth: "300px", flex: 1 }}
                    required
                  />
                  <Group position="apart" style={{ marginTop: "20px" }}>
                    <Button
                      type="submit"
                      style={{ backgroundColor: "black", color: "white" }}
                    >
                      Save it
                    </Button>
                  </Group>
                </form>
              </Modal>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  marginTop: "20px",
                }}
              >
                <Text>
                  Tips: You can save the generated outfit by clicking on save
                  generated outfit button.
                </Text>
              </div>
            </Container>
          </form>
          {/* Right Side Content */}
          <Container style={{ marginBottom: "10px" }}>
            {mockData.items.map((item) => (
              //control the image and description
              <Container
                style={{
                  minWidth: "420px",
                  display: "flex",
                  marginBottom: "10px",
                  border: "1px solid black",
                  borderRadius: "5px",
                  overflow: "hidden",
                  padding: "0px",
                }}
                key={item.category}
              >
                {/* Image Container */}
                <Container
                  style={{
                    flex: "0 0 26.00%",
                    height: "130px",
                    width: "10px",
                    position: "relative",
                    overflow: "hidden",
                    padding: "0px",
                  }}
                  key={item.category}
                  onMouseEnter={() =>
                    setVisible((prev) => ({ ...prev, [item.category]: true }))
                  }
                  onMouseLeave={() =>
                    setVisible((prev) => ({ ...prev, [item.category]: false }))
                  }
                >
                  <Image
                    src={item.imgSrc}
                    alt={item.category}
                    width={110}
                    fit="contain"
                    style={{
                      objectFit: "contain",
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  />
                  {visible[item.category] && (
                    <>
                      <Overlay blur={1} center style={{ overflow: "hidden" }}>
                        <Button
                          style={{
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            zIndex: 2, // to ensure the button is above the overlay
                            color: "#fff",
                          }}
                          onClick={() => {
                            // Function to handle "Find Similar" action
                          }}
                          color="dark"
                          size="xs"
                          compact
                        >
                          Find Similar
                        </Button>
                      </Overlay>
                    </>
                  )}
                </Container>
                {/* category & Example */}
                <Container
                  style={{
                    flex: 1,
                    display: "flex", // Use flexbox for center alignment
                    flexDirection: "column", // Stack children vertically
                    justifyContent: "center", // Center children vertically
                    boxSizing: "border-box",
                  }}
                >
                  <Text weight={500}>{item.category}</Text>
                  <Text size="sm">{item.example}</Text>
                </Container>
              </Container>
            ))}
          </Container>
        </SimpleGrid>
      </Paper>
    </div>
  );
}

export default DressMe;
