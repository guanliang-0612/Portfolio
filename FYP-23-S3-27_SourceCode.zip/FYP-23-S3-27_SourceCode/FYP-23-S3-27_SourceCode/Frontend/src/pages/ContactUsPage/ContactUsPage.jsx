import ContactUsSection from "./ContactUsSection";
import Banner from "./ContactUsBanner";
const ContactUsPage = () => {
  return (
    <div>
      <Banner />

      <ContactUsSection />
      <br />
    </div>
  );
};

export default ContactUsPage;
