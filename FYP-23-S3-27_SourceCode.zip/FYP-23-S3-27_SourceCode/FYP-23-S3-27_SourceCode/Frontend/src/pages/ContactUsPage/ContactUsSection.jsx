/* 
 Usecase:
 S29
 B35
*/
import {
  TextInput,
  Textarea,
  SimpleGrid,
  Group,
  Title,
  Button,
} from "@mantine/core";
import { useForm } from "@mantine/form";
import { addQuery } from "../../services/queryService";
import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";

export function ContactUsSection() {
  const form = useForm({
    initialValues: {
      fname: "",
      lname: "",
      email: "",
      subject: "",
      message: "",
    },
    validate: {
      fname: (value) => value.trim().length < 2,
      lname: (value) => value.trim().length < 2,
      email: (value) => !/^\S+@\S+$/.test(value),
      subject: (value) => value.trim().length === 0,
      message: (value) => value.trim().length === 0, // This makes field required
    },
  });
  return (
    <form
      onSubmit={form.onSubmit(() => {
        addQuery({
          fname: form.getInputProps("fname").value,
          lname: form.getInputProps("lname").value,
          email: form.getInputProps("email").value,
          subject: form.getInputProps("subject").value,
          details: form.getInputProps("message").value,
        });

        //location.reload()
        // Your application has indicated there's an error
        window.setTimeout(function () {
          alert(
            "Thank you for submitting your query. We will come back to you shortly."
          );
          // Move to a new location or you can do something else
          window.location.href = "/ContactUs";
        }, 1500);
      })}
    >
      <SimpleGrid cols={2} mt="xl" breakpoints={[{ maxWidth: "sm", cols: 1 }]}>
        <TextInput
          label="First Name *"
          placeholder="e.g. James"
          name="fname"
          variant="filled"
          {...form.getInputProps("fname")}
        />
        <TextInput
          label="Last Name *"
          placeholder="e.g. Lim"
          name="lname"
          variant="filled"
          {...form.getInputProps("lname")}
        />
        <TextInput
          label="Email *"
          placeholder="Your email"
          name="email"
          variant="filled"
          {...form.getInputProps("email")}
        />
      </SimpleGrid>

      <TextInput
        label="Subject *"
        placeholder="Subject"
        mt="md"
        name="subject"
        variant="filled"
        {...form.getInputProps("subject")}
      />
      <Textarea
        mt="md"
        label="What's on your Mind *"
        placeholder="Your message"
        maxRows={10}
        minRows={5}
        autosize
        name="message"
        variant="filled"
        {...form.getInputProps("message")}
      />

      <Group position="left" mt="xl">
        <Button variant="default" type="submit" size="md">
          Send message
        </Button>
      </Group>
    </form>
  );
}

export default ContactUsSection;
