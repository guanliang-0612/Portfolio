import FAQSection from "./FAQSection";
import Banner from "./FAQBanner";
const FAQPage = () => {
  return (
    <div>
      <Banner />
      <FAQSection />
    </div>
  );
};

export default FAQPage;
