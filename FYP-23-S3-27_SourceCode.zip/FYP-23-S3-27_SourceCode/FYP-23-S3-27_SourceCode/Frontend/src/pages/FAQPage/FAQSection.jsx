import {
  Container,
  Accordion,
  createStyles,
  rem,
  Text,
  List,
} from "@mantine/core";

const useStyles = createStyles((theme) => ({
  wrapper: {
    paddingTop: `calc(${theme.spacing.xl} * 2)`,
    paddingBottom: `calc(${theme.spacing.xl} * 2)`,
    minHeight: 100,
  },

  title: {
    marginBottom: `calc(${theme.spacing.xl} * 1.5)`,
  },

  item: {
    borderRadius: theme.radius.md,
    marginBottom: theme.spacing.lg,
    border: `${rem(1)} solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[3]
    }`,
  },
}));

export function FAQSection() {
  const { classes } = useStyles();
  return (
    <Container size="sm" className={classes.wrapper}>
      <Accordion variant="separated">
        <Accordion.Item className={classes.item} value="reset-password">
          <Accordion.Control>How can I reset my password?</Accordion.Control>
          <Accordion.Panel>
            <List>
              <List.Item>
                If you are logged in, you can change your password by going to
                "My Profile".
              </List.Item>
              <List.Item>
                If you are logged out and have forgotten your password, you can
                click on "Forgot password?" on the login/signup page.
              </List.Item>
            </List>
          </Accordion.Panel>
        </Accordion.Item>

        <Accordion.Item className={classes.item} value="another-account">
          <Accordion.Control>
            Can I create more than one account?
          </Accordion.Control>
          <Accordion.Panel>
            <List>
              <List.Item>
                Yes, you can! As long as you use a different email for each
                account.
              </List.Item>
            </List>
          </Accordion.Panel>
        </Accordion.Item>

        <Accordion.Item className={classes.item} value="newsletter">
          <Accordion.Control>
            Do I need an account to use your platform?
          </Accordion.Control>
          <Accordion.Panel>
            <List>
              <List.Item>
                Yes, you do. An account is needed for you to fully appreciate
                the features that we have such as being able to chat with our
                users and make offers for items that you want to purchase.
              </List.Item>
            </List>
          </Accordion.Panel>
        </Accordion.Item>

        <Accordion.Item className={classes.item} value="credit-card">
          <Accordion.Control>
            What are the main products being sold on your platform?
          </Accordion.Control>
          <Accordion.Panel>
            <List>
              <List.Item>
                We are a platform that lets users sell brand new or used fashion
                items from clothing to shoes.
              </List.Item>
            </List>
          </Accordion.Panel>
        </Accordion.Item>
      </Accordion>
    </Container>
  );
}
export default FAQSection;
