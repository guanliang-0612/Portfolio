import ViewIndividualListing from "./ViewingIndividualListing";
import { mockdata2 } from "./Listingmockdata";
import { useParams, useNavigate } from "react-router-dom";
import { getListing } from "../../services/listingService";
import { useEffect, useState } from "react";
const ViewIndividualListingPage = () => {
  // Get the listing id from the url
  const { id } = useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [listing, setListing] = useState({
    id: "",
    imageUrls: [""],
    name: "",
    price: "",
    category: "",
    status: "",
    condition: "",
    section: "",
    style: "",
    details: "",
    colour: "",
  });
  useEffect(() => {
    async function getData() {
      const data = await getListing(id);

      if (data?.status === "Deleted" || !data) navigate("/unavailable");
      setListing(data);
    }

    getData();
  }, [id]);

  useEffect(() => {}, []);

  // Prepare an object to store the listing details
  /* const [listing, setListing] = useState({})

    
    // Function to fetch data with the listing id eg. mockdata
    async function getListingData(id) {
      response = await httpClient.get(`/listings/${id}`)
      setListing(response.data)
    }

    // Call the function to fetch data the moment this component is initialised
    useEffect(() => {
      getListingData(id)
    }, []) */

  return (
    <div className="ViewingIndividualListing">
      <ViewIndividualListing listing={listing} loading={isLoading} />
      <br />
    </div>
  );
};

export default ViewIndividualListingPage;
