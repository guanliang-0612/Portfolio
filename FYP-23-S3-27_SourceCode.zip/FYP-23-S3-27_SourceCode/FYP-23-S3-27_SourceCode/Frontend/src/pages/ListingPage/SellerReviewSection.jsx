/* 
 Usecase:
 B26
*/
import {
  Card,
  Container,
  ScrollArea,
  Select,
  Text,
  createStyles,
  Group,
  Avatar,
  Rating,
  Button,
  Skeleton,
  UnstyledButton,
} from "@mantine/core";
import { IconComet } from "@tabler/icons-react";
import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getListingsBySeller } from "../../services/listingService";
import { getReviews } from "../../services/reviewService";
import { getUserDetails } from "../../services/userService";
import { calculateUserRating } from "../../services/reviewService";
import { useParams } from "react-router-dom";
import { getListing } from "../../services/listingService";
import { Link } from "react-router-dom";
import UserProfileButton from "../..//components/UserProfileButton";

const useStyles = createStyles((theme) => {
  return {
    scrollable: {
      maxHeight: "100%",
    },
  };
});

export default function SellerReviews() {
  const { id } = useParams();
  const { classes } = useStyles();
  const { currentUser } = useAuth();
  const [expandedIndexes, setExpandedIndexes] = useState([]);
  const [storeReviews, setGetReviews] = useState([]);
  const [userInfo, setUserInfo] = useState([]);
  const [storeRating, setRating] = useState(0);
  const [storeListing, setStoreListing] = useState([]);
  const toggleExpanded = (index) => {
    setExpandedIndexes((prevIndexes) =>
      prevIndexes.includes(index)
        ? prevIndexes.filter((i) => i !== index)
        : [...prevIndexes, index]
    );
  };
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function getData() {
      const allListings = await getListing(id);
      if (!allListings?.sellerId) return;
      let storeList = [];
      storeList.push(allListings);
      //setListings(data);
      // setIsLoading(false);
      setStoreListing(id);
      const data = await getListingsBySeller(storeList[0].sellerId);
      const reviews = await getReviews(storeList[0].sellerId);
      setGetReviews(reviews);
      const getUser = await getUserDetails(storeList[0].sellerId);
      const getRating = await calculateUserRating(storeList[0].sellerId);

      setUserInfo({ ...getUser, rating: getRating });

      setIsLoading(false);
    }
    getData();
  }, [id]);

  const dateStringOptions = {
    hour: "numeric",
    minute: "numeric",
    year: "numeric",
    month: "short",
    day: "numeric",
  };

  const mockSellerData = [
    {
      sellerimg:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&w=2070",
      sellername: "CX Thong",
      sellerrating: 3.5,
    },
  ];
  const mockUserData = [
    {
      listingname: "Pants",
      datetime: "2023-10-15 15:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. test test test",
      rating: 3.5,
    },
    {
      listingname: "Shirt",
      datetime: "2023-10-14 14:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John Wick",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 124 ",
      rating: 4,
    },
    {
      listingname: "Jacket",
      datetime: "2023-10-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John Wick 2",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 2.5,
    },
    {
      listingname: "Jacket",
      datetime: "2023-10-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John Wick 3",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 3.5,
    },
    {
      listingname: "Blue Short",
      datetime: "2023-10-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John wick's Dog",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 4,
    },
    {
      listingname: "Blue dress",
      datetime: "2023-09-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John wick's Dog 2",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 3.5,
    },
    {
      listingname: "Red dress",
      datetime: "2023-09-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John wick's Dog 3",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 4,
    },
  ];

  return (
    <Container
      style={{
        margin: "0px",
        padding: "0px",
      }}
    >
      <Container
        style={{
          display: "flex",
          margin: "0px",
          padding: "0px",
          justifyContent: "space-between",
          marginBottom: "14px",
        }}
      >
        <Text fw={700} size="xl">
          Seller Reviews
        </Text>
      </Container>
      <Card withBorder>
        <Container style={{ margin: "0px", padding: "0px" }}>
          <Container style={{ margin: "0px", padding: "0px" }}>
            <Card
              style={{
                marginBottom: "10px",
                marginRight: "10px",
                padding: "0px",
              }}
            >
              <Text weight={500} style={{ marginBottom: "10px" }}>
                Meet The Seller:
              </Text>
              <UserProfileButton userInfo={userInfo} isLoading={isLoading} />
            </Card>
          </Container>
        </Container>
        <ScrollArea.Autosize
          type="always"
          h={500}
          className={classes.scrollable}
        >
          <Container
            style={{
              margin: "0px",
              padding: "0px",
            }}
          >
            {storeReviews.length > 0 ? (
              storeReviews.map((review, index) => (
                <Container
                  key={review.id}
                  style={{ margin: "2px", padding: "0px" }}
                >
                  <hr
                    style={{
                      border: "0",
                      borderTop: "1px solid #e0e0e0",
                      width: "100%",
                    }}
                  />
                  <Container
                    style={{
                      display: "flex",
                      margin: "0px",
                      padding: "0px",
                      flexDirection: "row",
                    }}
                  >
                    <Avatar src={review.listingImage} radius="xl" />

                    <Container style={{ margin: "0px" }}>
                      <Text
                        size="sm"
                        weight={500}
                        className={classes.ellipsisText}
                      >
                        {review.dname}
                      </Text>
                      <Rating
                        value={review.rating}
                        fractions={2}
                        readOnly
                        size="xs"
                      />
                    </Container>
                  </Container>

                  <Container style={{ marginBottom: "10px", padding: "0px" }}>
                    <Text size="xs" className={classes.ellipsisText}>
                      {review.timestamp.toLocaleString(
                        "en-sg",
                        dateStringOptions
                      )}{" "}
                      | {review.listingName}
                    </Text>
                    <Text size="xs" className={classes.ellipsisText}>
                      {expandedIndexes.includes(index)
                        ? review.review
                        : `${review.review.substring(0, 160)}${
                            review.review.length > 160 ? "..." : ""
                          }`}
                    </Text>
                    {review.review.length > 160 && (
                      <Button
                        color="dark"
                        variant="outline"
                        compact
                        onClick={() => toggleExpanded(index)}
                        size="xs"
                        style={{ marginTop: "5px" }}
                      >
                        {expandedIndexes.includes(index)
                          ? "Read Less"
                          : "Read More"}
                      </Button>
                    )}
                  </Container>
                </Container>
              ))
            ) : (
              <Container
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  height: "300px",
                }}
              >
                <IconComet size={45} stroke={0.8} /* color="lightgrey" */ />
                <Text size="lg" align="center" weight={450}>
                  No reviews yet
                </Text>
              </Container>
            )}
          </Container>
        </ScrollArea.Autosize>
      </Card>
    </Container>
  );
}
