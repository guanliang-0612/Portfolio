/* 
 Usecase:
 S10
 S12
 B13
 B18
 A18
*/
/* eslint-disable react/prop-types */
import React, { useState, useRef, useEffect } from "react"; // Added useRef import
import {
  Button,
  Paper,
  Text,
  Image,
  Divider,
  Space,
  Container,
  Modal,
  Select,
  Textarea,
  rem,
  Flex,
} from "@mantine/core";
import {
  IconHeart,
  IconMessageCircle2,
  IconFlag2,
  IconEdit,
  IconTrash,
  IconHeartFilled,
} from "@tabler/icons-react";
import { createStyles, Skeleton } from "@mantine/core";
import { useAuth } from "../../contexts/AuthContext";
import { deleteListing } from "../../services/listingService";
import SellerReviews from "./SellerReviewSection";
import { useForm, isNotEmpty } from "@mantine/form";
import { Link, useNavigate } from "react-router-dom";
import { useChatRooms } from "../../contexts/ChatRoomsContext";
import { addReport } from "../../services/reportService";
import { getUserDetails } from "../../services/userService";
import { isListingSaved } from "../../services/listingService";
import { saveIndividualListing } from "../../services/listingService";
import { removeSavedListing } from "../../services/listingService";
import ListingPreviewImage from "./components/ListingPreviewImage";
import { useDisclosure } from "@mantine/hooks";

const useStyles = createStyles((theme) => ({
  likeButtonUnclicked: {
    position: "absolute",
    bottom: rem(10),
    right: rem(10),
    color: "black", // Set the color of the heart icon to black
    borderColor: "black", // Set the border color of the button to black
  },

  likeButtonClicked: {
    position: "absolute",
    bottom: rem(10),
    right: rem(10),
    color: "black", // Set the color of the heart icon to white when clicked
    borderColor: "black", // Set the border color of the button to blue when clicked
    backgroundColor: "grey", // Set the background color to blue when clicked
  },
}));

const mainImageContainerStyle = {
  width: "400px",
  height: "600px",
  position: "relative",
};
const mainImageStyle = {
  width: "400px",
  height: "600px",
  objectFit: "cover",
  overflow: "hidden", // hide the overflowing parts of the child elements (the image)
};

const buttonStyle = {
  padding: "4px 4px", // Adjust these values as needed
  color: "#333",
  borderStyle: "none", // Defines the type of border; in this case, a solid line
  fontWeight: "400", // Normal font weight
};

const iconStyle = {
  opacity: 0.8, // Adjust as needed
};

const iconSavedStyle = {
  opacity: 1, // Adjust as needed
  color: "#FF8787",
};

const mainAndZoomContainerStyle = {
  position: "relative", // This is crucial
  width: "480px",
  height: "600px", // Adjusted the height to match the main image
  marginLeft: "20px",
};

const categoryMappings = {
  topwear: "Tops",
  bottomwear: "Bottoms",
  footwear: "Footwear",
  outerwear: "Outerwear",
  dress: "Dresses",
};
const colourMappings = {
  beige: "Beige",
  black: "Black",
  blue: "Blue",
  brown: "Brown",
  gold: "Gold",
  green: "Green",
  grey: "Grey",
  multicoloured: "Multi-coloured",
  orange: "Orange",
  pink: "Pink",
  purple: "Purple",
  red: "Red",
  silver: "Silver",
  turquoise: "Turquoise",
  white: "White",
  yellow: "Yellow",
};
const styleMappings = {
  ["formal wear"]: "Formal",
  ["casual wear"]: "Casual",
  ["smart casual wear"]: "Smart Casual",
};

function ViewIndividualListing({
  listing: {
    id = "",
    imageUrls = [""], // New prop: an array of image URLs
    name = "",
    price = "",
    category = "",
    status = "",
    section = "",
    condition = "",
    style = "",
    details = "",
    sellerId = "",
    savedBy = "",
    colour = "",
  },
}) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0); // State to manage the currently displayed image
  const { currentUser } = useAuth();
  const { createChatRoom, getChatRoomIdIfExists } = useChatRooms();
  const { classes } = useStyles();
  const [imgIsLoading, setImgIsLoading] = useState(true);
  const [buttonClicked, setButtonClicked] = useState(
    currentUser && savedBy.includes(currentUser.id)
  );
  const navigate = useNavigate();
  const [showZoom, setShowZoom] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  /*   const [dropDownValue, setDropDownValue] = useState(""); */
  const imageRef = useRef(null);
  const [reportIsSubmitting, setReportIsSubmitting] = useState(false);
  const reportForm = useForm({
    initialValues: {
      subject: "",
      email: currentUser?.email,
      dname: currentUser?.dname,
      details: "",
      listingId: "",
      reportedUserId: "",
    },

    validate: {
      subject: isNotEmpty("Select a reason."),
      details: isNotEmpty("The report description cannot be empty."),
    },
  });

  // TODO
  useEffect(() => {
    // Check if the listing is already saved
    const checkSavedStatus = async () => {
      const isSaved = await isListingSaved(id, currentUser.id);
      setButtonClicked(isSaved);
    };

    if (!(id && currentUser?.id)) return;
    reportForm.setValues({ listingId: id, reportedUserId: sellerId });

    checkSavedStatus();
  }, [id, currentUser]);

  const handleClick = async () => {
    // e.preventDefault();
    setButtonClicked((prev) => !prev);
    // Check if the listing is already saved
    const isSaved = await isListingSaved(id, currentUser.id);

    if (isSaved) {
      // If the listing is already saved, remove it
      try {
        const result = await removeSavedListing(id, currentUser.id);
        if (result === true) {
          setButtonClicked(false);
        } else {
          console.error("Error removing the listing");
        }
      } catch (error) {
        console.error("Error removing the listing:", error);
      }
    } else {
      // If the listing is not saved, save it
      try {
        const result = await saveIndividualListing(id, currentUser.id);
        if (result === true) {
          setButtonClicked(true);
        } else {
          console.error("Error saving the listing");
        }
      } catch (error) {
        console.error("Error saving the listing:", error);
      }
    }
  };

  const handleMouseMove = (e) => {
    const { left, top, width, height } =
      imageRef.current.getBoundingClientRect();
    const x = ((e.pageX - left) / width) * 100;
    // Calculate the ratio of the zoomed image height to the main image height
    const ratio = 400 / 600; // 400px is the height of the zoomed image, 600px is the height of the main image
    // Adjust the y position based on the ratio
    const y = ((e.pageY - top) / height) * 100 * ratio;
    setMousePosition({ x, y });
  };

  const handleReportSubmit = async ({
    email,
    dname: username,
    subject,
    details,
    listingId,
    reportedUserId,
  }) => {
    setReportIsSubmitting(true);
    await addReport({
      email,
      username,
      subject,
      details,
      listingId,
      reportedUserId,
    });
    setReportIsSubmitting(false);
    window.setTimeout(function () {
      alert(
        "Thank you for submitting your report. Our team will investigate the issue."
      );
      // Move to a new location or you can do something else
      window.location.href = `/listing/${id}`;
    }, 1000);
  };
  const [opened, setOpened] = useState(false);
  const openModal = () => {
    setOpened(true);
  };
  const closeModal = () => {
    setOpened(false);
  };
  const handleDropDown = (event) => {
    setDropDownValue(event);
  };

  const zoomedImageStyle = {
    width: "435px",
    height: "400px",
    backgroundImage: `url(${imageUrls[currentImageIndex]})`,
    backgroundPosition: `${mousePosition.x}% ${mousePosition.y}%`,
    backgroundSize: "800px", // This determines the zoom level
    border: "1px solid #ccc",
    display: showZoom ? "block" : "none",
    position: "absolute", // Added this line
    zIndex: 10, // Added this line to ensure it overlays other elements
    left: "401px", // Adjust this value based on your layout
    top: "0px", // Adjust this value based on your layout
  };

  return (
    <Container style={{ padding: "0px" }}>
      <div style={{ display: "flex", padding: "20px", position: "relative" }}>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "5px",
          }}
        >
          {imageUrls.map((url, index) => {
            return (
              <ListingPreviewImage
                key={index}
                src={url}
                index={index}
                onClick={() => {
                  if (index !== currentImageIndex) {
                    setCurrentImageIndex(index);
                    setImgIsLoading(true);
                  }
                }}
              />
            );
          })}
        </div>
        <div style={mainAndZoomContainerStyle}>
          <Skeleton visible={imgIsLoading}>
            <div
              style={mainImageContainerStyle}
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setShowZoom(true)}
              onMouseLeave={() => setShowZoom(false)}
              ref={imageRef}
            >
              <Image
                src={imageUrls[currentImageIndex]}
                alt={name}
                style={{
                  ...mainImageStyle,
                  position: "absolute",
                  top: "0",
                  left: "0",
                }}
                imageProps={{ onLoad: () => setImgIsLoading(false) }}
              />
            </div>
          </Skeleton>
          <div style={zoomedImageStyle}></div>
        </div>
        <Container padding="md" style={{ flex: 0.1 }}>
          {/* Reduced width by adjusting the flex property */}
          <Text align="left" size="xl" style={{ fontWeight: "bold" }}>
            {name}
          </Text>
          <Text align="left" size="lg" style={{ fontWeight: "bold" }}>
            S$ {Number(price).toFixed(2)}
          </Text>
          <Space h="md" />
          <Flex direction="column" gap={7}>
            <Text>
              <Text align="left" span fw={500} size="md">
                Section:
              </Text>{" "}
              <Text align="left" span size="md">
                {section}
              </Text>
            </Text>
            <Text>
              <Text align="left" span fw={500} size="md">
                Condition:
              </Text>{" "}
              <Text align="left" span size="md">
                {condition}
              </Text>
            </Text>
            <Text>
              <Text align="left" span fw={500} size="md">
                Category:
              </Text>{" "}
              <Text align="left" span size="md">
                {categoryMappings[category]}
              </Text>
            </Text>

            <Text>
              <Text align="left" span fw={500} size="md">
                Style:
              </Text>{" "}
              <Text align="left" span size="md">
                {styleMappings[style]}
              </Text>
            </Text>

            <Text>
              <Text align="left" span fw={500} size="md">
                Colour:
              </Text>{" "}
              <Text align="left" span size="md">
                {colourMappings[colour]}
              </Text>
            </Text>
            <Text>
              <Text align="left" span fw={500} size="md">
                Status:
              </Text>{" "}
              <Text align="left" span size="md">
                {status}
              </Text>
            </Text>
          </Flex>
          <Divider style={{ margin: "10px 0" }} />
          <Text align="left" fw={500}>
            Details:
          </Text>
          <Text align="left">{details}</Text>
          {/* <Text align="left">Size: {details.size}</Text> */}
          {currentUser?.id !== sellerId && (
            <Container
              style={{
                marginTop: "20px",
                display: "flex",
                gap: "10px",
                padding: "0px",
              }}
            >
              <Button
                leftIcon={
                  buttonClicked ? (
                    <IconHeartFilled style={iconSavedStyle} />
                  ) : (
                    <IconHeart style={iconStyle} />
                  )
                }
                variant="outline"
                color="black"
                size="sm"
                style={buttonStyle}
                onClick={() => {
                  if (!currentUser) navigate("/LoginSignUp");
                  handleClick();
                }}
              >
                Save Listing
              </Button>
              <Button
                leftIcon={<IconMessageCircle2 style={iconStyle} />}
                variant="outline"
                color="black"
                size="sm"
                style={buttonStyle}
                onClick={() => {
                  if (!currentUser) navigate("/LoginSignUp");
                  let chatRoomId = getChatRoomIdIfExists(sellerId, id);

                  if (!chatRoomId) chatRoomId = createChatRoom(sellerId, id);

                  navigate(`/chats/${chatRoomId}`);
                }}
              >
                Chat With Seller
              </Button>
              <Button
                leftIcon={<IconFlag2 style={iconStyle} />}
                variant="outline"
                color="red"
                size="sm"
                style={buttonStyle}
                onClick={() => {
                  if (!currentUser) navigate("/LoginSignUp");
                  openModal();
                }}
              >
                Report Listing
              </Button>
            </Container>
          )}
          <div style={{ marginTop: "20px", display: "flex", gap: "10px" }}>
            {currentUser?.id === sellerId && (
              <Button
                variant="default"
                component={Link}
                to={`/EditListing/${id}`}
              >
                Update Listing
                <IconEdit
                  style={{ marginLeft: "5px" }}
                  size="1.4rem"
                  stroke={1.5}
                />
              </Button>
            )}

            {(currentUser?.id === sellerId ||
              currentUser?.role === "admin") && (
              <Button
                variant="default"
                onClick={async () => {
                  const result = await deleteListing(id);
                  if (result) {
                    navigate("/");
                  }
                }}
              >
                Delete Listing
                <IconTrash
                  style={{ marginLeft: "5px" }}
                  size="1.4rem"
                  stroke={1.5}
                />
              </Button>
            )}
          </div>
        </Container>
      </div>
      {/* Modal code starts here */}
      <Modal
        opened={opened}
        onClose={closeModal}
        size="md"
        title="Why are you reporting this listing?"
      >
        {/* You can also include forms, textareas, etc. */}
        <form onSubmit={reportForm.onSubmit(handleReportSubmit)}>
          <Select
            label="Please select a reason"
            placeholder="Pick one"
            onChange={(event) => handleDropDown(event)}
            data={[
              {
                value: "Inappropriate Listing",
                label: "Inappropriate Listing",
              },
              { value: "Offensive Language", label: "Offensive Language" },
              { value: "Others", label: "Others" },
            ]}
            dropdownPosition="bottom"
            styles={(theme) => ({
              item: {
                // applies styles to selected item
                "&[data-selected]": {
                  "&, &:hover": {
                    backgroundColor:
                      theme.colorScheme === "dark"
                        ? theme.colors.dark[10]
                        : theme.colors.dark[5],
                    color:
                      theme.colorScheme === "dark"
                        ? theme.white
                        : theme.colors.dark[20],
                  },
                },
                // applies styles to hovered item (with mouse or keyboard)
                "&[data-hovered]": {},
              },
            })}
            {...reportForm.getInputProps("subject")}
          />
          <Textarea
            label="Report Description"
            autosize
            minRows={2}
            maxRows={2}
            {...reportForm.getInputProps("details")}
          />
          <Button
            type="submit"
            style={{ marginTop: "10px" }}
            color="dark"
            loading={reportIsSubmitting}
          >
            Send
          </Button>
        </form>
      </Modal>
      {/* Modal code ends here */}

      <SellerReviews />
    </Container>
  );
}

export default ViewIndividualListing;
