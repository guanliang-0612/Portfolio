import { Skeleton, Image, createStyles } from "@mantine/core";
import { useState } from "react";

const useStyles = createStyles((theme) => ({
  root: {
    cursor: "pointer",
    "&:hover": {
      boxShadow: theme.shadows.sm,
    },
  },
  wrapper: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
    width: "75px",
    height: "100px",
  },
  img: {
    flexShrink: "0",
    minWidth: "100%",
    minHeight: "100%",
    objectFit: "cover",
  },
}));

const ListingPreviewImage = ({ onClick = () => {}, src = "", index = 0 }) => {
  const [previewLoading, setPreviewLoading] = useState(true);
  const { classes } = useStyles();
  return (
    <Skeleton visible={previewLoading}>
      <Image
        src={src}
        alt={`Preview ${index}`}
        /* style={previewImageStyle} */
        imageProps={{
          onLoad: () => setPreviewLoading(false),
        }}
        onClick={onClick}
        classNames={{
          root: classes.root,
          imageWrapper: classes.wrapper,
          image: classes.img,
        }}
      />
    </Skeleton>
  );
};

export default ListingPreviewImage;
