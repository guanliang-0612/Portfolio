import React, { useState, useEffect } from "react";
import { Stepper, Button, Group, Code } from "@mantine/core";
import { useForm } from "@mantine/form";
import ListingInfoForm from "../customer/CreateListing/components/ListingInfoForm"; // Assuming you have a similar form component
import UploadImage from "../customer/CreateListing/components/UploadImages";
import {
  getListing,
  updateListing,
  getClothingAttributes,
} from "../../services/listingService"; // Define an updateListing function
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";

export default function EditListing() {
  const [active, setActive] = useState(0);
  const maxSteps = 1;
  const navigate = useNavigate();
  const { listingId } = useParams();
  const [toSuggest, setToSuggest] = useState(true);
  const [isSuggested, setIsSuggested] = useState({
    category: false,
    style: false,
    colour: false,
  });
  const { currentUser } = useAuth();
  const form = useForm({
    initialValues: {
      files: [],
      name: "",
      price: 0,
      condition: "",
      section: "",
      status: "",
      category: "",
      colour: "",
      details: "",
      style: "",
      sellerId: currentUser?.id,
    },

    validate: (values) => {
      /*       if (active === 0) {
        return {
          username:
            values.username.trim().length < 6
              ? "Username must include at least 6 characters"
              : null,
          password:
            values.password.length < 6
              ? "Password must include at least 6 characters"
              : null,
        };
      } */

      if (active === 1) {
        return {
          name:
            values.name.trim().length < 2
              ? "Name must include at least 2 characters"
              : null,
          email: /^\S+@\S+$/.test(values.email) ? null : "Invalid email",
        };
      }

      return {};
    },
  });

  const nextStep = () =>
    setActive((current) => {
      if (form.validate().hasErrors) {
        return current;
      }
      return current < 2 ? current + 1 : current;
    });

  const prevStep = () =>
    setActive((current) => (current > 0 ? current - 1 : current));

  const [isSubmitting, setIsSubmitting] = useState(false);
  useEffect(() => {
    // Fetch the existing listing data based on the listingId
    async function fetchListingData() {
      try {
        const listingData = await getListing(listingId);

        // Populate the form fields with the fetched data
        form.setValues({ ...listingData, files: listingData.imageUrls });
      } catch (error) {
        console.error("Error fetching listing data", error);
        // Handle error and possibly redirect the user
      }
    }

    fetchListingData();
  }, [listingId]);

  useEffect(() => {
    async function getData() {
      if (!toSuggest) return;
      if (!form.values.files.length) return;
      const imageUrl = URL.createObjectURL(form.values.files[0]);
      const result = await getClothingAttributes(imageUrl);
      URL.revokeObjectURL(imageUrl);
      const { category, colour, style } = result;
      form.setValues((prev) => ({ ...prev, category, colour, style }));
      setToSuggest(false);
      setIsSuggested({
        category: true,
        style: true,
        colour: true,
      });
    }
    getData();
  }, [form, toSuggest]);

  const handleSubmit = async (values) => {
    try {
      // Update the listing with the new data
      setIsSubmitting(true);
      await updateListing(values);
      // Redirect the user to the listing details page or any other appropriate page
      navigate(`/listing/${values.id}`);
    } catch (error) {
      console.error("Error updating listing", error);
      // Handle error and display a message to the user
    }
  };

  // Rest of the component rendering (similar to CreateListing)

  return (
    <form onSubmit={form.onSubmit(handleSubmit)} id="createListingForm">
      <Stepper active={active} color="black" breakpoint="sm">
        <Stepper.Step label="First step" description="Upload photos">
          <UploadImage
            files={form.values.files}
            setFiles={(files) => {
              form.setValues((prev) => {
                return {
                  ...prev,
                  files: [...prev.files, ...files],
                };
              });
            }}
            removeFile={(index) => {
              if (index === 0) {
                setToSuggest(true);
              }
              form.setValues((prev) => {
                let filesCopy = [...prev.files];
                filesCopy.splice(index, 1);
                return {
                  ...prev,
                  files: [...filesCopy],
                };
              });
            }}
          />
        </Stepper.Step>

        <Stepper.Step label="Second step" description="Listing information">
          <ListingInfoForm
            form={form}
            isSuggested={isSuggested}
            setIsSuggested={setIsSuggested}
          />
          <Stepper.Completed>
            Completed! Form values:
            <Code block mt="xl">
              {JSON.stringify(form.values, null, 2)}
            </Code>
          </Stepper.Completed>
        </Stepper.Step>
      </Stepper>
      <Group position="right" mt="xl">
        {active !== 0 && (
          <Button variant="default" onClick={prevStep}>
            Back
          </Button>
        )}
        {active === maxSteps ? (
          <Button
            style={{ background: "black" }}
            type="submit"
            form="createListingForm"
            onClick={() => {
              handleSubmit(form.values);
            }}
            loading={isSubmitting} // added this
          >
            Submit
          </Button>
        ) : (
          <Button
            style={{ background: form.values.files.length > 0 && "black" }}
            onClick={(event) => {
              event.preventDefault();

              if (form.values.files.length) nextStep();
            }}
            disabled={form.values.files.length === 0}
            type="button"
          >
            Next step
          </Button>
        )}
      </Group>
    </form>
  );
}
