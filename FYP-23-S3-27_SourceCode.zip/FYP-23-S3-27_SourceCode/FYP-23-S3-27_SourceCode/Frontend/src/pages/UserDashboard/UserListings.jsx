/* 
 Usecase:
 S09
 S14
 S15
*/
import {
  Button,
  Card,
  Container,
  ScrollArea,
  Select,
  SimpleGrid,
  Text,
  TextInput,
  createStyles,
  LoadingOverlay,
} from "@mantine/core";
import { IconListSearch } from "@tabler/icons-react";
import ListingCard from "../../components/ListingCard";
import { mockdata } from "../ListingPage/Listingmockdata";
import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getListingsBySeller } from "../../services/listingService";
import { useParams } from "react-router-dom";

const items = mockdata.map((product) => (
  <ListingCard key={product.id} product={product} />
));

const useStyles = createStyles((theme) => {
  return {
    grid: {
      maxWidth: "100%",
    },
    root: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      height: "100%",
    },
    scrollArea: {
      width: "100%",
      flexGrow: 1,
      flexShrink: 0,
      height: "calc(100%)",
    },
    headerContainer: {
      display: "flex",
      paddingTop: "0px",
      paddingLeft: "0px",
      paddingRight: "0px",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      height: "60px",
    },
    centerContainer: {
      padding: "0px",
      display: "flex",
      height: "calc(100% - 60px)",
      width: "100%",
      position: "relative",
    },
    searchFilterContainer: {
      display: "flex",
      gap: "10px",
      flexDirection: "row",
      justifyContent: "end",
    },
  };
});
export default function UserListings() {
  const { classes } = useStyles();
  const [searchCriteria, setSearchCriteria] = useState("");
  const [filterCriteria, setFilterCriteria] = useState(""); // New state for filter
  const [listings, setListings] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const { id } = useParams();
  const { currentUser } = useAuth();

  useEffect(() => {
    async function getData() {
      setIsLoading(true);
      const data = await getListingsBySeller(id);
      setListings(data);
      setIsLoading(false);
    }

    getData();
  }, [id]);
  const applyFilters = (products) => {
    let filteredProducts = products;

    // Applying search filter
    filteredProducts = filteredProducts.filter((value) =>
      value.name.toLowerCase().includes(searchCriteria.toLowerCase())
    );

    // Applying sort filter based on criteria
    switch (filterCriteria) {
      case "priceAsc":
        filteredProducts.sort((a, b) => a.price - b.price);
        break;
      case "priceDesc":
        filteredProducts.sort((a, b) => b.price - a.price);
        break;
      case "alphaAsc":
        filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case "alphaDesc":
        filteredProducts.sort((a, b) => b.name.localeCompare(a.name));
        break;
      default:
        break;
    }

    return filteredProducts;
  };
  return (
    <Card style={{ paddingBottom: "0", width: "100%" }}>
      <Container className={classes.headerContainer}>
        <Text fw={700} size="xl">
          Listings
        </Text>
        <div className={classes.searchFilterContainer}>
          <TextInput
            placeholder={"Search"}
            size="sm"
            value={searchCriteria}
            onChange={(event) => {
              setSearchCriteria(event.target.value);
            }}
          />
          <Select
            placeholder={"Filter by"}
            onChange={(value) => setFilterCriteria(value)} // directly use value
            data={[
              { value: "priceAsc", label: "Price: Low to High" },
              { value: "priceDesc", label: "Price: High to Low" },
              { value: "alphaAsc", label: "A to Z" },
              { value: "alphaDesc", label: "Z to A" },
            ]}
            styles={(theme) => ({
              item: {
                // applies styles to selected item
                "&[data-selected]": {
                  "&, &:hover": {
                    backgroundColor:
                      theme.colorScheme === "dark"
                        ? theme.colors.dark[10]
                        : theme.colors.dark[5],
                    color:
                      theme.colorScheme === "dark"
                        ? theme.white
                        : theme.colors.dark[20],
                  },
                },

                // applies styles to hovered item (with mouse or keyboard)
                "&[data-hovered]": {},
              },
            })}
          />
        </div>
      </Container>
      <Container className={classes.centerContainer}>
        {isLoading ? (
          // Show a loading indicator while data is being fetched
          <LoadingOverlay visible={isLoading} color="dark" />
        ) : listings.length > 0 ? (
          <div className={classes.root}>
            <ScrollArea className={classes.scrollArea} scrollbarSize={10}>
              <SimpleGrid
                className={classes.grid}
                // TODO: Responsive layout
                cols={3}
                /*         breakpoints={[
          { maxWidth: "md", cols: 2 },
          { maxWidth: "xxxxl", cols: 3 },
        ]} */
              >
                {applyFilters(listings).map((product) => (
                  <Container
                    style={{ transform: "scale(0.95)", padding: "0px" }}
                    key={product.id}
                  >
                    <ListingCard
                      product={{ ...product, image: product.imageUrls[0] }}
                    />
                  </Container>
                ))}
              </SimpleGrid>
            </ScrollArea>
          </div>
        ) : (
          <Container
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "300px",
            }}
          >
            <IconListSearch size={40} stroke={0.8} />
            <Text size="lg" align="center" weight={450} mt="5px">
              No listings found
            </Text>
          </Container>
        )}
      </Container>
    </Card>
  );
}
