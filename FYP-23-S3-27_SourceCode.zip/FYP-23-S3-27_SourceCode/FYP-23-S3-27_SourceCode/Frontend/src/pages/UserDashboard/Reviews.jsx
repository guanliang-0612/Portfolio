/* 
 Usecase:
 S16
*/
import {
  Card,
  Container,
  ScrollArea,
  Select,
  Text,
  createStyles,
  Group,
  Avatar,
  Rating,
  Button,
} from "@mantine/core";
import { IconComet } from "@tabler/icons-react";
import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getListingsBySeller } from "../../services/listingService";
import { getReviews } from "../../services/reviewService";
import { useParams } from "react-router-dom";

const useStyles = createStyles((theme) => {
  return {
    grid: {
      maxWidth: "100%",
    },
    scrollable: {
      width: "100%",
      flexGrow: 1,
      flexShrink: 0,
      height: "calc(100%)",
    },
    headerContainer: {
      display: "flex",
      margin: "0px",
      padding: "0px",
      height: "2rem",
      justifyContent: "space-between",
    },
    searchFilterContainer: {
      display: "flex",
      gap: "10px",
      flexDirection: "row",
      justifyContent: "end",
    },
    centerContainer: {
      padding: "0px",
      display: "flex",
      height: "calc(100% - 2rem)",
      width: "100%",
      position: "relative",
    },
    root: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      height: "100%",
    },
  };
});

export default function Reviews() {
  const { classes } = useStyles();
  const { currentUser } = useAuth();

  const { id } = useParams();
  const [expandedIndexes, setExpandedIndexes] = useState([]);
  const [storeReviews, setGetReviews] = useState([]);

  const toggleExpanded = (index) => {
    setExpandedIndexes((prevIndexes) =>
      prevIndexes.includes(index)
        ? prevIndexes.filter((i) => i !== index)
        : [...prevIndexes, index]
    );
  };

  const dateStringOptions = {
    hour: "numeric",
    minute: "numeric",
    year: "numeric",
    month: "short",
    day: "numeric",
  };

  useEffect(() => {
    async function getData() {
      // const data = await getListingsBySeller(currentUser.id);
      const reviews = await getReviews(id);
      //setListings(data);
      // setIsLoading(false);
      setGetReviews(reviews);
    }
    getData();
  }, []);

  const mockUserData = [
    {
      listingname: "Pants",
      datetime: "2023-10-15 15:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. test test test",
      rating: 3.5,
    },
    {
      listingname: "Shirt",
      datetime: "2023-10-14 14:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John Wick",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 124 ",
      rating: 4,
    },
    {
      listingname: "Jacket",
      datetime: "2023-10-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John Wick 2",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 2.5,
    },
    {
      listingname: "Jacket",
      datetime: "2023-10-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John Wick 3",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 3.5,
    },
    {
      listingname: "Blue Short",
      datetime: "2023-10-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John wick's Dog",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 4,
    },
    {
      listingname: "Blue dress",
      datetime: "2023-09-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John wick's Dog 2",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 3.5,
    },
    {
      listingname: "Red dress",
      datetime: "2023-09-13 13:30",
      listingimg:
        "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      dname: "John wick's Dog 3",
      message:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
      rating: 4,
    },
  ];

  return (
    <Card style={{ paddingBottom: "0", width: "100%" }}>
      <Container className={classes.headerContainer}>
        <Text fw={700} size="xl">
          Reviews
        </Text>
      </Container>{" "}
      <Container className={classes.centerContainer}>
        <ScrollArea className={classes.scrollable}>
          {storeReviews.length > 0 ? (
            storeReviews.map((review, index) => (
              <Group style={{ margin: "2px" }} key={review.id}>
                <hr
                  style={{
                    border: "0",
                    borderTop: "1px solid #e0e0e0",
                    width: "100%",
                  }}
                />
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "start",
                  }}
                >
                  <Avatar src={review.listingImage} radius="xl" />

                  <div style={{ flex: 1, marginLeft: "10px" }}>
                    <Text
                      size="sm"
                      weight={500}
                      className={classes.ellipsisText}
                    >
                      {review.dname}
                    </Text>
                    <Rating
                      value={review.rating}
                      fractions={2}
                      readOnly
                      size="xs"
                    />
                  </div>
                </div>
                <div style={{ marginBottom: "10px" }}>
                  <Text size="xs" className={classes.ellipsisText}>
                    {review.timestamp.toLocaleString(
                      "en-sg",
                      dateStringOptions
                    )}{" "}
                    | {review.listingName}
                  </Text>
                  <Text size="xs" className={classes.ellipsisText}>
                    {expandedIndexes.includes(index)
                      ? review.review
                      : `${review.review.substring(0, 124)}${
                          review.review.length > 124 ? "..." : ""
                        }`}
                  </Text>
                  {review.review.length > 124 && (
                    <Button
                      color="dark"
                      variant="outline"
                      compact
                      onClick={() => toggleExpanded(index)}
                      size="xs"
                      style={{ marginTop: "5px" }}
                    >
                      {expandedIndexes.includes(index)
                        ? "Read Less"
                        : "Read More"}
                    </Button>
                  )}
                </div>
              </Group>
            ))
          ) : (
            <Container
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                height: "300px",
              }}
            >
              <IconComet size={45} stroke={0.8} /* color="lightgrey" */ />
              <Text size="lg" align="center" weight={450}>
                No reviews yet
              </Text>
            </Container>
          )}
        </ScrollArea>
      </Container>{" "}
    </Card>
  );
}
