/* 
 Usecase:
 B24
*/
import {
  Card,
  Container,
  ScrollArea,
  Text,
  createStyles,
  Group,
  Avatar,
  Badge,
  LoadingOverlay,
} from "@mantine/core";
import { IconListSearch } from "@tabler/icons-react";
import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getOffersByBuyer } from "../../services/offerService";

const useStyles = createStyles((theme) => {
  return {
    grid: {
      maxWidth: "100%",
    },
    scrollable: {
      width: "100%",
      flexGrow: 1,
      flexShrink: 0,
      height: "calc(100%)",
    },
    headerContainer: {
      display: "flex",
      margin: "0px",
      padding: "0px",
      height: "2rem",
      justifyContent: "space-between",
    },
    searchFilterContainer: {
      display: "flex",
      gap: "10px",
      flexDirection: "row",
      justifyContent: "end",
    },
    centerContainer: {
      padding: "0px",
      display: "flex",
      height: "calc(100% - 2rem)",
      width: "100%",
      position: "relative",
    },
    root: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      height: "100%",
    },
  };
});

export default function OfferHistory() {
  const { classes } = useStyles();
  const { currentUser } = useAuth();
  const [offers, setOffers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedIndexes, setExpandedIndexes] = useState([]);

  const toggleExpanded = (index) => {
    setExpandedIndexes((prevIndexes) =>
      prevIndexes.includes(index)
        ? prevIndexes.filter((i) => i !== index)
        : [...prevIndexes, index]
    );
  };

  useEffect(() => {
    async function getData() {
      try {
        const data = await getOffersByBuyer(currentUser.id);
        setOffers(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    }
    getData();
  }, [currentUser.id]);

  return (
    <Card style={{ paddingBottom: "0", width: "100%" }}>
      <Container className={classes.headerContainer}>
        <Text fw={700} size="xl">
          Offer History
        </Text>
      </Container>
      <Container className={classes.centerContainer}>
        <ScrollArea className={classes.scrollable}>
          {isLoading ? (
            // Loading state
            // Show a loading indicator while data is being fetched
            <LoadingOverlay visible={isLoading} color="dark" />
          ) : offers.length > 0 ? (
            offers.map((offer) => (
              <Card
                key={offer.id}
                shadow="xs"
                withBorder
                radius="md"
                padding="md"
                sx={(theme) => ({
                  backgroundColor:
                    theme.colorScheme === "dark"
                      ? theme.colors.dark[7]
                      : theme.white,
                })}
                style={{
                  marginBottom: "10px",
                  marginTop: "10px",
                  marginRight: "12px",
                }}
              >
                <Group style={{ margin: "2px" }}>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      alignItems: "start",
                    }}
                  >
                    <Avatar
                      src={offer.listingImage}
                      size="lg"
                      style={{ height: "76px" }}
                    />
                    <div style={{ flex: 1, marginLeft: "10px" }}>
                      <Text
                        size="sm"
                        weight={500}
                        className={classes.ellipsisText}
                      >
                        {offer.sellerName}
                      </Text>
                      <Text size="xs" className={classes.ellipsisText}>
                        {offer.listingName}
                      </Text>

                      <Text size="xs" className={classes.ellipsisText}>
                        <Badge radius="md" style={{ marginRight: "5px" }}>
                          ${offer.amount}
                        </Badge>
                        | {offer.status}
                        <Text size="xs" className={classes.ellipsisText}>
                          {offer.timestamp.toLocaleString("en-sg", {
                            hour: "numeric",
                            minute: "numeric",
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </Text>
                      </Text>
                    </div>
                  </div>
                </Group>
              </Card>
            ))
          ) : (
            <Container
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                height: "300px",
              }}
            >
              <IconListSearch size={40} stroke={0.8} />
              <Text size="lg" align="center" weight={450} mt="5px">
                No offers found
              </Text>
            </Container>
          )}
        </ScrollArea>{" "}
      </Container>{" "}
    </Card>
  );
}
