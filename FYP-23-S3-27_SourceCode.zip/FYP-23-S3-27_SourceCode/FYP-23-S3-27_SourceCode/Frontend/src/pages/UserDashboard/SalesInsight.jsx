/* 
 Usecase:
 S17
*/
import {
  Button,
  Card,
  Container,
  ScrollArea,
  Select,
  SimpleGrid,
  Text,
  TextInput,
  createStyles,
  Group,
  Paper,
} from "@mantine/core";
import { DatePicker } from "@mantine/dates";
import { IconCalendarEvent, IconX } from "@tabler/icons-react";
import ListingCard from "../../components/ListingCard";
import { mockdata } from "../ListingPage/Listingmockdata";
import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import {
  getListingsBySeller,
  getDailySale,
} from "../../services/listingService";
import ApexChart from "./SalesChart";
const items = mockdata.map((product) => (
  <ListingCard key={product.id} product={product} />
));

const useStyles = createStyles((theme) => {
  return {
    grid: {
      maxWidth: "100%",
    },
    scrollable: {
      maxHeight: "100%",
    },
    headerContainer: {
      display: "flex",
      padding: "10px",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
    },
    searchFilterContainer: {
      display: "flex",
      gap: "10px",
      flexDirection: "row",
      justifyContent: "end",
    },
  };
});

const data = [
  {
    tdaysales: "120",
    subject: "Listing - Inappropriate Listing",
  },
];

export default function SalesInsight() {
  const { classes } = useStyles();
  const [searchCriteria, setSearchCriteria] = useState("");
  const [listings, setListings] = useState();
  const [storeDailySale, setDailySale] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { currentUser } = useAuth();
  useEffect(() => {
    async function getData() {
      const data = await getListingsBySeller(currentUser.id);
      setListings(data);
      setIsLoading(false);
      const dailySale = await getDailySale(currentUser.id);
      setDailySale(dailySale);
    }
    getData();
  }, []);
  // cx code
  const sales = data[0];
  // had to adjust to this instead cant take null like the examples in mantine
  const currentDate = new Date();
  const [showDatePicker, setShowDatePicker] = useState(false);
  // State for selected dates and range type
  const [startDate, setStartDate] = useState(currentDate);
  const [endDate, setEndDate] = useState(currentDate);
  const [rangeType, setRangeType] = useState(null);
  const handleCloseDatePicker = () => {
    setShowDatePicker(false);
  };
  const handleDateChange = (selectedDates) => {
    // Log the type and value of selectedDates for debugging

    const selectedDate = selectedDates[0] || new Date(); // Fall back to current date if selection is null or undefined

    if (rangeType === "daily") {
      setStartDate(selectedDate);
      setEndDate(selectedDate);
    } else if (rangeType === "weekly") {
      setStartDate(selectedDate);
      let endOfWeek = new Date(selectedDate);
      endOfWeek.setDate(endOfWeek.getDate() + 6);
      setEndDate(endOfWeek);
    } else if (rangeType === "monthly") {
      setStartDate(
        new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1)
      );
      setEndDate(
        new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0)
      );
    }
  };

  useEffect(() => {
    if (rangeType === "daily") {
      setStartDate(currentDate);
      setEndDate(currentDate);
    } else if (rangeType === "weekly") {
      setStartDate(currentDate); // Start of the range is the current date
      const endOfWeek = new Date(currentDate);
      endOfWeek.setDate(endOfWeek.getDate() + 6); // End of the range is 6 days after the current date
      setEndDate(endOfWeek);
    } else if (rangeType === "monthly") {
      setStartDate(
        new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
      );
      setEndDate(
        new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)
      );
    }
  }, [rangeType]);

  // Rendering
  return (
    <Card style={{ paddingBottom: "0", width: "100%" }}>
      <Container style={{ margin: "0px", padding: "0px" }}>
        <Text fw={700} size="xl">
          Sales Insight
        </Text>
        <Text
          fz="lg"
          size="xl"
          style={{
            marginTop: "16px",
            fontWeight: 500,
          }}
        >
          Today Sales: S$ {Number(storeDailySale).toFixed(2)}
        </Text>
      </Container>

      <Container
        style={{
          marginTop: "16px",
          display: "flex",
          flexDirection: "row",
          alignItems: "flex-end",
          padding: "0px",
          gap: "10px",
        }}
      >
        <Select
          style={{ minWidth: "200x" }}
          label="Sales Report "
          value={rangeType}
          onChange={setRangeType}
          placeholder="Select range"
          required
          data={[
            { value: "daily", label: "Daily" },
            { value: "weekly", label: "Weekly" },
            { value: "monthly", label: "Monthly" },
          ]}
        />
        <TextInput
          /* style={{ marginTop: "25px", marginLeft: "10px" }} */
          icon={<IconCalendarEvent size="1rem" />}
          label="Start"
          type="text"
          value={startDate.toDateString()}
          readOnly
          onClick={() => setShowDatePicker(true)} // Show DatePicker on click
        />
        <TextInput
          /* style={{ marginTop: "25px", marginLeft: "10px" }} */
          label="End"
          type="text"
          value={endDate.toDateString()}
          readOnly
          onClick={() => setShowDatePicker(true)} // Show DatePicker on click
        />
      </Container>
      <Container>
        {showDatePicker && (
          <div
            style={{
              position: "relative" /* height: "400px", width: "600px" */,
              zIndex: "2",
              width: "100%",
              justifyContent: "center",
              display: "flex",
            }}
          >
            <Paper
              style={{
                position: "absolute",
                /*      left: "116px", */
                marginBottom: "10px",
                display: "flex",
                flexDirection: "column",
                padding: "10px",
                backgroundColor: "#f8f8f8",
                justifyContent: "space-between",
                /* width: "490px", */
              }}
            >
              <IconX
                size="1.2rem"
                onClick={handleCloseDatePicker}
                style={{
                  cursor: "pointer",
                  alignSelf: "flex-end",
                }}
              />
              <DatePicker
                type="range"
                color="dark"
                size="xs"
                allowSingleDateInRange
                numberOfColumns={2}
                value={[startDate, endDate]}
                onChange={handleDateChange}
                onBlur={() => setShowDatePicker(false)}
                /* style={{
                  margin: "10px",
                }} */
              />
            </Paper>
          </div>
        )}
      </Container>
      <Container style={{ /* width: "1200px", */ marginTop: "20px" }}>
        <div
          style={{
            opacity: ["daily", "weekly", "monthly"].includes(rangeType)
              ? 1
              : 0.0,
          }}
        >
          <ApexChart startDate={startDate} view={rangeType} key={rangeType} />
        </div>{" "}
      </Container>
      {/* <ScrollArea.Autosize
        type="always"
        mah={600}
        className="scrollable"
      ></ScrollArea.Autosize> */}
    </Card>
  );
}
