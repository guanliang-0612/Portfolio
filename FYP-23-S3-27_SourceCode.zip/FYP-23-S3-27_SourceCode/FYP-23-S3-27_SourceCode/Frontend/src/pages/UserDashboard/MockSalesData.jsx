export const mockSalesData = [
  // October 2023
  { date: "2023-10-01", sales: 120 },
  { date: "2023-10-02", sales: 150 },
  { date: "2023-10-03", sales: 110 },
  { date: "2023-10-04", sales: 130 },
  { date: "2023-10-05", sales: 95 },
  { date: "2023-10-06", sales: 105 },
  { date: "2023-10-07", sales: 100 },
  { date: "2023-10-08", sales: 120 },
  { date: "2023-10-09", sales: 110 },
  { date: "2023-10-10", sales: 150 },
  { date: "2023-10-11", sales: 100 },
  { date: "2023-10-12", sales: 80 },
  { date: "2023-10-13", sales: 120 },
  { date: "2023-10-14", sales: 150 },
  { date: "2023-10-15", sales: 110 },
  { date: "2023-10-16", sales: 100 },
  { date: "2023-10-17", sales: 130 },
  { date: "2023-10-18", sales: 140 },
  { date: "2023-10-19", sales: 90 },
  { date: "2023-10-20", sales: 100 },
  { date: "2023-10-21", sales: 95 },
  { date: "2023-10-22", sales: 85 },
  { date: "2023-10-23", sales: 105 },
  { date: "2023-10-24", sales: 115 },
  { date: "2023-10-25", sales: 100 },
  { date: "2023-10-26", sales: 130 },
  { date: "2023-10-27", sales: 105 },
  { date: "2023-10-28", sales: 90 },
  { date: "2023-10-29", sales: 85 },
  { date: "2023-10-30", sales: 95 },
  { date: "2023-10-31", sales: 115 },

  // November 2023
  { date: "2023-11-01", sales: 140 },
  { date: "2023-11-02", sales: 120 },
  // ... continue for November

  // December 2023
  { date: "2023-12-01", sales: 110 },
  { date: "2023-12-02", sales: 100 },
  // ... continue for December

  // and so on for other months
];
