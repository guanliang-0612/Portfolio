import {
  Card,
  Grid,
  Paper,
  ScrollArea,
  SimpleGrid,
  Skeleton,
  Tabs,
  Text,
  createStyles,
  rem,
  Rating,
  Avatar,
  Button,
  Modal,
  Select,
  Textarea,
  Group,
  ActionIcon,
} from "@mantine/core";
import { useForm, isNotEmpty } from "@mantine/form";
import { IconFlag2, IconTrash } from "@tabler/icons-react";
import ContentContainer from "../../components/ContentContainer";
import { useNavigate, useParams } from "react-router-dom";
import CategoryGrid from "../LandingPage/CategoryCard";
import ProductGrid from "../LandingPage/ProductGrid";
import SavedListings from "./SavedListings";
import SalesInsight from "./SalesInsight";
import UserListings from "./UserListings";
import { useAuth } from "../../contexts/AuthContext";
import Reviews from "./Reviews";
import OfferHistory from "./OfferHistory";
import { getUserDetails } from "../../services/userService";
import { calculateUserRating } from "../../services/reviewService";
import { useEffect, useState } from "react";
import ContentContainerChat from "../../components/ContentContainerChat";
import { addReport } from "../../services/reportService";
import { deleteUserBasedOnId } from "../../services/authService";
const useStyles = createStyles((theme) => {
  return {
    tabs: {
      padding: "0rem 2rem",
      display: "flex",
      direction: "row",
      alignItems: "center",
      justifyContent: "left",
      height: "100%",
      font: "inherit",
      gap: "1rem",
    },
    tab: {
      backgroundColor: "transparent",
      color: "white",
      border: "none",
      online: "none",
      cursor: "pointer",
      fontFamily: "inherit",
    },
    active: {
      borderBottom: "3px solid white",
    },
    InfoWrapper: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      flexDirection: "column",
      gap: "1em",
    },
    UserInfo: {
      textAlign: "left",
    },
    /*     scrollable: {
      height: "100%",
    }, */
    tabPanel: {
      height: "100%",
      display: "flex",
    },
  };
});
const mockUserData = [
  {
    rating: 3.5,
    dname: "cx_Sim",
    displayimg:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&w=2070",
  },
];
const iconStyle = {
  opacity: 0.8, // Adjust as needed
};
export default function UserDashboard() {
  const { classes, cx } = useStyles();
  const { id, tabValue } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [userInfo, setUserInfo] = useState({});
  const [storeRating, setRating] = useState(0);
  const [infoAndRatingIsLoading, setInfoAndRatingIsLoading] = useState(true);
  const links =
    currentUser?.id === id
      ? [
          { value: "listings", label: "Listings" },
          { value: "reviews", label: "Reviews" },
          { value: "saved", label: "Saved Listing" },
          { value: "offer", label: "Offer History" },
          { value: "sales", label: "Sales Insight" },
        ]
      : [
          { value: "listings", label: "Listings" },
          { value: "reviews", label: "Reviews" },
        ];
  const [modalOpened, setModalOpened] = useState(false);
  const [deleteModalOpened, setDeleteModalOpened] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [reportIsSubmitting, setReportIsSubmitting] = useState(false);
  const reportForm = useForm({
    initialValues: {
      subject: "",
      email: currentUser?.email,
      dname: currentUser?.dname,
      details: "",
      listingId: "",
      reportedUserId: id,
    },

    validate: {
      subject: isNotEmpty("Select a reason."),
      details: isNotEmpty("The report description cannot be empty."),
    },
  });

  useEffect(() => {
    async function getData() {
      setInfoAndRatingIsLoading(true);
      // const data = await getListingsBySeller(currentUser.id);
      const getUser = await getUserDetails(id);
      const getRating = await calculateUserRating(id);
      //setListings(data);
      // setIsLoading(false);
      setUserInfo(getUser);
      setRating(getRating);
      setInfoAndRatingIsLoading(false);
    }
    getData();
  }, [id]);

  const handleReportSubmit = async ({
    email,
    dname: username,
    subject,
    details,
    listingId,
    reportedUserId,
  }) => {
    try {
      setReportIsSubmitting(true);
      await addReport({
        email,
        username,
        subject,
        details,
        listingId,
        reportedUserId,
      });
      window.setTimeout(function () {
        alert(
          "Thank you for submitting your report. Our team will investigate the issue."
        );
        // Move to a new location or you can do something else
      }, 500);
    } catch (error) {
      alert("Report submission failed");
    } finally {
      setReportIsSubmitting(false);
      setModalOpened(false);
    }
  };

  const tabLinks = links.map(({ value, label }, index) => (
    <Tabs.Tab
      key={index}
      value={value}
      className={cx(classes.tab, { [classes.active]: tabValue === value })}
    >
      <Text fw={500}>{label}</Text>
    </Tabs.Tab>
  ));

  return (
    <Grid columns={26}>
      <Grid.Col span={5}>
        <Card
          withBorder
          shadow="0px 4px 10px 0px rgba(0,0,0,0.1)"
          radius={8}
          className={classes.InfoWrapper}
        >
          <div>
            <Skeleton radius={"100%"} visible={infoAndRatingIsLoading}>
              <Avatar
                size="xl"
                src={userInfo.imageUrl}
                style={{ borderRadius: "100%" }}
              ></Avatar>
            </Skeleton>
          </div>

          {/*  <Skeleton height={100} circle /> */}
          <Paper className={classes.userInfo}>
            <Skeleton visible={infoAndRatingIsLoading}>
              <Text
                size="md"
                weight={500}
                style={{
                  wordBreak: "break-all",
                }}
              >
                {userInfo.dname}
              </Text>
              <div style={{ marginBottom: "10px" }}>
                {/* <Text
                  dimmed
                  size="sm"
                  style={{ marginBottom: "2px", wordBreak: "break-all" }}
                >{`${userInfo.fname} ${userInfo.lname}`}</Text> */}

                <div style={{ display: "flex", alignItems: "center" }}>
                  {/* <Text size="xs" style={{ marginRight: "2px" }}> */}

                  {storeRating === 0 ? (
                    <>
                      <Text size="xs" style={{ marginRight: "2px" }}>
                        No reviews yet |
                      </Text>{" "}
                      <Rating
                        count={1}
                        defaultValue={0}
                        value={storeRating}
                        fractions={2}
                        readOnly
                        size="xs"
                      />
                    </>
                  ) : (
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <Text size="xs" style={{ marginRight: "2px" }}>
                        {storeRating} |
                      </Text>
                      <Rating
                        defaultValue={0}
                        value={storeRating}
                        fractions={2}
                        readOnly
                        size="xs"
                      />
                    </div>
                  )}
                  {/* </Text> */}
                </div>
              </div>{" "}
            </Skeleton>
          </Paper>
        </Card>
      </Grid.Col>
      <Grid.Col span={21}>
        <Tabs
          unstyled
          className={classes.tabsRoot}
          value={tabValue || "listings"}
          onTabChange={(value) => navigate(`/UserDashboard/${id}/${value}`)}
        >
          <ContentContainer>
            <ContentContainer.Header>
              <div
                style={{
                  display: "flex",
                  width: "100%",
                  height: "100%",
                  justifyContent: "space-between",
                  alignItems: "center",
                  paddingRight: "1rem",
                }}
              >
                <Tabs.List className={classes.tabs}>{tabLinks}</Tabs.List>
                {currentUser?.id &&
                  currentUser?.id !== id &&
                  (currentUser?.role === "admin" ? (
                    <Button
                      leftIcon={<IconTrash style={iconStyle} />}
                      color="red"
                      variant="filled"
                      onClick={() => {
                        setDeleteModalOpened(true);
                      }}
                      compact
                      /* style={{ padding: "10px", height: "min-content" }} */
                    >
                      Delete User
                    </Button>
                  ) : (
                    <Button
                      leftIcon={<IconFlag2 style={iconStyle} />}
                      color="red"
                      variant="filled"
                      onClick={() => setModalOpened(true)}
                      compact
                      /* style={{ padding: "10px", height: "min-content" }} */
                    >
                      Report User
                    </Button>
                  ))}
              </div>
            </ContentContainer.Header>
            <ContentContainer.Body>
              <Tabs.Panel className={classes.tabPanel} value="listings">
                <UserListings />
              </Tabs.Panel>
              <Tabs.Panel
                /* className={classes.tabPanel} */ className={classes.tabPanel}
                value="reviews"
              >
                <Reviews />
              </Tabs.Panel>
              {currentUser?.id === id && (
                <>
                  <Tabs.Panel className={classes.tabPanel} value="saved">
                    <SavedListings />
                  </Tabs.Panel>
                  <Tabs.Panel
                    /* className={classes.tabPanel}  */ className={
                      classes.tabPanel
                    }
                    value="offer"
                  >
                    <OfferHistory />
                  </Tabs.Panel>
                  <Tabs.Panel className={classes.tabPanel} value="sales">
                    <SalesInsight />
                  </Tabs.Panel>
                </>
              )}
              <Modal
                opened={modalOpened}
                onClose={() => setModalOpened(false)}
                size="md"
                title="Why are you reporting this user?"
              >
                {/* You can also include forms, textareas, etc. */}
                <form onSubmit={reportForm.onSubmit(handleReportSubmit)}>
                  <Select
                    label="Please select a reason"
                    placeholder="Pick one"
                    data={[
                      {
                        value: "Inappropriate Behaviour",
                        label: "Inappropriate Behaviour",
                      },
                      {
                        value: "Fraudulent User",
                        label: "Fraudulent User",
                      },
                      {
                        value: "Offensive Language",
                        label: "Offensive Language",
                      },
                      { value: "Others", label: "Others" },
                    ]}
                    dropdownPosition="bottom"
                    styles={(theme) => ({
                      item: {
                        // applies styles to selected item
                        "&[data-selected]": {
                          "&, &:hover": {
                            backgroundColor:
                              theme.colorScheme === "dark"
                                ? theme.colors.dark[10]
                                : theme.colors.dark[5],
                            color:
                              theme.colorScheme === "dark"
                                ? theme.white
                                : theme.colors.dark[20],
                          },
                        },
                        // applies styles to hovered item (with mouse or keyboard)
                        "&[data-hovered]": {},
                      },
                    })}
                    {...reportForm.getInputProps("subject")}
                  />
                  <Textarea
                    label="Report Description"
                    autosize
                    minRows={2}
                    maxRows={2}
                    {...reportForm.getInputProps("details")}
                  />
                  <Button
                    type="submit"
                    style={{ marginTop: "10px" }}
                    color="dark"
                    loading={reportIsSubmitting}
                  >
                    Send
                  </Button>
                </form>
              </Modal>
              {/* Modal code ends here */}
              {/* Delete Modal code starts here */}
              <Modal
                opened={deleteModalOpened}
                onClose={() => setDeleteModalOpened(false)}
                title="Delete Account"
                size="sm"
              >
                <Text>Are you sure you want to delete the account?</Text>
                <Group position="apart" style={{ marginTop: "20px" }}>
                  <Button
                    onClick={async () => {
                      // Handle account deletion logic here
                      setIsDeleting(true);
                      await deleteUserBasedOnId(id);
                      navigate("/");
                    }}
                    loading={isDeleting}
                    color="red"
                  >
                    Yes, delete it
                  </Button>
                  <Button
                    onClick={() => setDeleteModalOpened(false)}
                    style={{ backgroundColor: "black", color: "white" }}
                  >
                    No, keep it
                  </Button>
                </Group>
                <ActionIcon
                  style={{ position: "absolute", right: 15, top: 20 }}
                  onClick={() => setDeleteModalOpened(false)}
                >
                  ×
                </ActionIcon>
              </Modal>
            </ContentContainer.Body>
          </ContentContainer>
        </Tabs>
      </Grid.Col>
    </Grid>
  );
}
