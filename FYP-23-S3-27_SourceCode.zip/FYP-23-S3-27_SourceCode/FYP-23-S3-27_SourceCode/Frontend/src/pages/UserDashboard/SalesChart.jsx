/* 
 Usecase:
 S17
*/
import { React, useEffect, useState } from "react";
import ApexCharts from "react-apexcharts";
import { mockSalesData } from "./MockSalesData";
import { getSalesHistory } from "../../services/listingService";
import { useAuth } from "../../contexts/AuthContext";

import {
  Button,
  Card,
  Container,
  ScrollArea,
  Select,
  SimpleGrid,
  Text,
  TextInput,
  createStyles,
  Group,
  Paper,
} from "@mantine/core";

const transformDailyData = (startDate, endDate, dataset) => {
  return dataset.filter((data) => {
    const date = new Date(data.date);
    return (
      date.setHours(0, 0, 0, 0) >= startDate.setHours(0, 0, 0, 0) &&
      date.setHours(0, 0, 0, 0) <= endDate.setHours(0, 0, 0, 0)
    );
  });
};

const transformDataForSpecificDay = (specificDate, dataset) => {
  return dataset.filter((data) => {
    const date = new Date(data.date);
    return date.toDateString() === specificDate.toDateString();
  });
};

// Utility function to get the start of the week
const getStartOfWeek = (date) => {
  const result = new Date(date);
  result.setDate(result.getDate() - result.getDay());
  return result;
};

// Utility function to get the end of the week
const getEndOfWeek = (date) => {
  const result = new Date(date);
  result.setDate(result.getDate() - result.getDay() + 6);
  return result;
};

function SalesChart({ startDate, view }) {
  let chartData;
  let categories;
  const [storeData, setStoreData] = useState([]);
  const [storeStartDate, setStartDate] = useState("");
  const [storeEndDate, setEndDate] = useState("");
  const { currentUser } = useAuth();

  useEffect(() => {
    async function getData() {
      // const data = await getListingsBySeller(currentUser.id);
      const getData = await getSalesHistory(currentUser.id);
      setStoreData(getData);
    }
    getData();
  }, []);

  const transformMonthlyData = (startDate) => {
    const endDate = new Date(startDate);
    endDate.setMonth(startDate.getMonth() + 1);
    endDate.setDate(0);

    const dailyData = transformDailyData(startDate, endDate, storeData);
    const weeklyData = Array(5).fill(0);

    dailyData.forEach((data) => {
      const weekIndex = Math.floor((new Date(data.date).getDate() - 1) / 7);
      weeklyData[weekIndex] += data.sales;
    });

    return weeklyData.map((sales, index) => ({
      date: `Week ${index + 1}`,
      sales,
    }));
  };
  console.log(storeData);
  switch (view) {
    case "daily":
      chartData = transformDataForSpecificDay(startDate, storeData);
      categories = chartData.map((data) => data.date);
      break;
    case "weekly":
      const startOfWeek = new Date(startDate);
      const endOfWeek = new Date(startDate);
      endOfWeek.setDate(startOfWeek.getDate() + 6);
      chartData = transformDailyData(startOfWeek, endOfWeek, storeData);
      categories = chartData.map((data) => data.date);
      break;
    case "monthly":
      chartData = transformMonthlyData(startDate);

      categories = chartData.map((data) => data.date);
      break;
    default:
      chartData = [];
      categories = [];
  }

  // If no sales data, return the message
  // if (chartData.length === 0 ) {
  //   return (
  //     <Container style={{ marginLeft: "60px" }}>
  //       <Text> You do not have any sales at the selected date range </Text>
  //     </Container>
  //   );
  // }

  let noSalesFlag = false;

  if (chartData.length === 0) {
    noSalesFlag = true;
  }

  for (let i = 0; i < chartData.length; i++) {
    noSalesFlag = true;
    if (chartData[i].sales > 0) {
      noSalesFlag = false;
      break;
    }
  }
  /* chartData.forEach((week) => {
    noSalesFlag = true
    if (week.sales > 0) {
      noSalesFlag = false;
    }
    break
  });

  if (chartData.length)*/

  if (noSalesFlag) {
    return (
      <Container style={{ marginLeft: "60px" }}>
        <Text> You do not have any sales at the selected date range </Text>
      </Container>
    );
  }

  const series = [
    {
      name: "Sales",
      data: chartData.map((data) => data.sales),
    },
  ];

  const options = {
    chart: {
      type: view === "daily" ? "bar" : "line",
      height: 350,
    },
    xaxis: {
      categories: categories,
    },
  };

  return (
    <ApexCharts
      options={options}
      series={series}
      type={view === "daily" ? "bar" : "line"}
    />
  );
}

export default SalesChart;
