/* 
 Usecase:
B09
*/
import {
  createStyles,
  Card,
  Text,
  SimpleGrid,
  UnstyledButton,
  Group,
  rem,
} from "@mantine/core";

import { IconShoe } from "@tabler/icons-react";

import { PiPantsDuotone, PiTShirt, PiDressDuotone } from "react-icons/pi";

import { GiSleevelessJacket } from "react-icons/gi";
import { Link } from "react-router-dom";

const categoryLinks = [
  {
    title: "Tops",
    icon: PiTShirt,
    color: "violet",
    link: "/SearchResults?category=topwear",
  },
  {
    title: "Bottoms",
    icon: PiPantsDuotone,
    color: "indigo",
    link: "/SearchResults?category=bottomwear",
  },
  {
    title: "Outerwear",
    icon: GiSleevelessJacket,
    color: "blue",
    link: "/SearchResults?category=outerwear",
  },
  {
    title: "Dresses",
    icon: PiDressDuotone,
    color: "red",
    link: "/SearchResults?category=dress",
  },
  {
    title: "Footwear",
    icon: IconShoe,
    color: "teal",
    link: "/SearchResults?category=footwear",
  },
];

const useStyles = createStyles((theme) => ({
  card: {
    backgroundColor:
      theme.colorScheme === "dark"
        ? theme.colors.dark[6]
        : theme.colors.gray[0],
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontWeight: 700,
  },

  item: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    borderRadius: theme.radius.md,
    height: rem(90),
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.white,
    transition: "box-shadow 150ms ease, transform 100ms ease",

    "&:hover": {
      boxShadow: theme.shadows.md,
      transform: "scale(1.05)",
    },
  },
}));

export function CategoryGrid() {
  const { classes, theme } = useStyles();

  const items = categoryLinks.map((item) => (
    <UnstyledButton
      component={Link}
      to={item.link}
      key={item.title}
      className={classes.item}
    >
      <item.icon color={theme.colors[item.color][6]} size="2rem" />
      <Text size="xs" mt={7}>
        {item.title}
      </Text>
    </UnstyledButton>
  ));

  return (
    <Card withBorder radius="md" className={classes.card}>
      <Group position="apart">
        <Text className={classes.title}>Shop By Category</Text>
        {/*<Anchor size="xs" color="dimmed" sx={{ lineHeight: 1 }}>
            + 21 other services
          </Anchor>
        */}
      </Group>
      <SimpleGrid cols={5} mt="md">
        {items}
      </SimpleGrid>
    </Card>
  );
}
export default CategoryGrid;
