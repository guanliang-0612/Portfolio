import CardsCarousel from "./Carousel";
import CategoryGrid from "./CategoryCard";
import ProductGrid from "./ProductGrid";
import { useEffect, useState } from "react";
import {
  getAllListings,
  getRecommendedListings,
} from "../../services/listingService";
import { Loader } from "@mantine/core";
import { useAuth } from "../../contexts/AuthContext";

const Landingpage = () => {
  const [listings, setListings] = useState([]);
  const [isLoading, setIsloading] = useState(true);
  const { currentUser } = useAuth();
  useEffect(() => {
    async function getData() {
      if (!currentUser) {
        const data = await getAllListings();
        setListings(data);
      } else {
        const data = await getRecommendedListings(currentUser.id);
        setListings(data);
      }

      setIsloading(false);
    }
    getData();
  }, []);

  return (
    <div className="Homepage">
      <CardsCarousel />
      <br></br>
      <CategoryGrid />
      {!isLoading /* ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Loader color="rgba(0, 0, 0, 1)" />
          </div>
        ) :  */ && <ProductGrid listings={listings} />}
    </div>
  );
};

export default Landingpage;
