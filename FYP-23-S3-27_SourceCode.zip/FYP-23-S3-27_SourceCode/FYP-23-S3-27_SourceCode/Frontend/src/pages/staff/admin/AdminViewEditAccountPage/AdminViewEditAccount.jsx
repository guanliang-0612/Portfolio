/* 
 Usecase:
 A08
 A09
 A10
 A11
*/
import React, { useState, useEffect } from "react";
import {
  TextInput,
  SimpleGrid,
  createStyles,
  Container,
  Text,
  Button,
  Group,
  rem,
  Paper,
  Modal,
  ActionIcon,
  Tabs,
  ScrollArea,
  Select,
} from "@mantine/core";
import { DatePickerInput } from "@mantine/dates";
import { useForm, hasLength, isNotEmpty, isEmail } from "@mantine/form";
import { useNavigate } from "react-router-dom";
import {
  IconEdit,
  IconTrashXFilled,
  IconArrowBackUp,
} from "@tabler/icons-react";
import {
  getUserDetails,
  adminUpdateUserDetails,
  deleteUserBasedOnId,
} from "../../../../services/authService";
import useAlerts from "../../../../hooks/useAlerts";

// Define the mock data directly in the file
const mockData = {
  accounttype: "Customer Support",
  accountstatus: "Active",
  dname: "tcf_sam",
  fname: "Sam",
  lname: "Smith",
  email: "samsmith@tcf.com",
};

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },
  paperStyle: {
    width: "100%", // or any specific width you want, e.g.
    padding: 0,
    // remove padding
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontSize: rem(62),
    fontWeight: 900,
    lineHeight: 1.1,
    margin: 0,
    padding: 0,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(42),
      lineHeight: 1.2,
    },
  },

  description: {
    marginTop: theme.spacing.xl,
    fontSize: rem(24),

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(18),
    },
  },

  flexContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  leftGrid: {
    flex: 1,
  },

  rightGrid: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },

  buttonGroup: {
    display: "flex",
    justifyContent: "space-between",
    width: "100%",
    marginTop: "10px",
  },
  hoverIcon: {
    "&:hover": {
      color: "rgb(250, 82, 82)", // Use the specified red color
    },
  },

  blackHover: {
    "&:hover": {
      color: "black", // Set hover color to black
    },
  },
}));

export function AdminViewEditAccount({ accountId }) {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const [modalOpened, setModalOpened] = useState(false);
  const [isEditing, setIsEditing] = useState(false); // New state variable to toggle between view and edit
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { AlertDisplay, displayError, displaySuccess, closeAlert } =
    useAlerts();
  // Use Effect to load data
  // Set data inside state
  async function getData() {
    try {
      const user = await getUserDetails(accountId);
      // Update state with the retrieved data
      // For example, if your reportData structure is similar to mockData
      form.setValues({
        id: user.id,
        dname: user.dname,
        fname: user.fname,
        lname: user.lname,
        email: user.email,
        status: user.status,
        role: user.role,
        birthday: user.birthday,
        gender: user.gender,
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }
  useEffect(() => {
    getData(accountId);
  }, [accountId]); // Add dependencies if needed

  const form = useForm({
    initialValues: {
      dname: "",
      fname: "",
      lname: "",
      email: "",
      status: "",
      role: "",
      birthday: "",
      gender: "",
    },
    validate: {
      fname: hasLength({ min: 2 }, "Invalid first name"),
      lname: hasLength({ min: 2 }, "Invalid last name"),
      dname: isNotEmpty("Enter your display name"),
      email: isEmail("Invalid email"),
    },
  });

  const handleTabClick = (value) => {
    if (value === "first") {
      navigate("/AdminManageAccountPage");
    } else if (value === "second") {
      navigate("/AdminCreateStaffAccountPage");
    }
  };

  const handleSubmit = async (values) => {
    setIsSubmitting(true);
    closeAlert();
    try {
      await adminUpdateUserDetails(values);
      displaySuccess("Changes saved");
    } catch (error) {
      switch (error.code) {
        case "auth/duplicate-display-name":
          form.setFieldError(
            "dname",
            "An account with this display name already exists"
          );
          break;
        case "auth/email-already-in-use":
          form.setFieldError(
            "email",
            "An account with this email already exists"
          );
          break;
        default:
          displayError("Account update failed.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={classes.wrapper}>
      <div className={classes["manage-account-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          Manage Account
        </Text>
      </div>
      <div className={classes["tabs-container"]}>
        <Tabs defaultValue="first" onTabChange={handleTabClick}>
          <Tabs.List>
            <Tabs.Tab value="first" color="dark">
              View All Account
            </Tabs.Tab>
            <Tabs.Tab value="second" color="dark">
              Create Staff Account
            </Tabs.Tab>
          </Tabs.List>
        </Tabs>
      </div>

      <Container size={900}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <Text
            fz="xl"
            ta="left"
            style={{
              color: "black",
              marginTop: "20px",
            }}
            weight={500}
          >
            {isEditing ? "Edit User Account" : "View User Account"}
          </Text>

          {isEditing ? (
            <>
              <ActionIcon
                style={{ marginTop: "20px", marginLeft: "8px" }}
                className={classes.hoverIcon}
                onClick={() => setModalOpened(true)}
              >
                <IconTrashXFilled size={22} />
              </ActionIcon>
              <ActionIcon
                style={{ marginTop: "20px", marginLeft: "475px" }}
                className={classes.blackHover}
                onClick={() => setIsEditing(false)}
              >
                <IconArrowBackUp size={22} />
              </ActionIcon>
            </>
          ) : (
            <ActionIcon
              style={{ marginTop: "20px", marginLeft: "8px" }}
              className={classes.blackHover}
              onClick={() => setIsEditing(true)}
            >
              <IconEdit size={22} />
            </ActionIcon>
          )}

          <Modal
            opened={modalOpened}
            onClose={() => setModalOpened(false)}
            title="Delete Account"
            size="sm"
          >
            <Text>Are you sure you want to delete the account?</Text>
            <Group position="apart" style={{ marginTop: "20px" }}>
              <Button
                onClick={async () => {
                  // Handle account deletion logic here
                  setIsDeleting(true);
                  await deleteUserBasedOnId(accountId);
                  window.location.reload();
                }}
                loading={isDeleting}
                color="red"
              >
                Yes, delete it
              </Button>
              <Button
                onClick={() => setModalOpened(false)}
                style={{ backgroundColor: "black", color: "white" }}
              >
                No, keep it
              </Button>
            </Group>
            <ActionIcon
              style={{ position: "absolute", right: 15, top: 20 }}
              onClick={() => setModalOpened(false)}
            >
              ×
            </ActionIcon>
          </Modal>
        </div>

        <Paper radius="md" withBorder={false}>
          <form onSubmit={form.onSubmit(handleSubmit)} style={{ width: "80%" }}>
            <AlertDisplay />
            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <Select
                label="Account Type"
                data={[
                  { value: "admin", label: "Admin" },
                  { value: "support", label: "Customer support" },
                  { value: "customer", label: "Customer" },
                ]}
                value={form.values.role}
                disabled // Always read-only
                variant="filled"
              />
              <Select
                label="Account Status"
                disabled={!isEditing} // Editable when isEditing is true
                data={[
                  { value: "active", label: "Active" },
                  { value: "inactive", label: "Inactive" },
                ]}
                variant="filled"
                {...form.getInputProps("status")}
              />
              <TextInput
                label="Display Name"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("dname")}
                required
              />
              <TextInput
                label="Email"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("email")}
                required
                error={form.errors.email}
              />
            </SimpleGrid>
            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <TextInput
                label="First Name"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("fname")}
                required
              />
              <TextInput
                label="Last Name"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("lname")}
                required
              />
            </SimpleGrid>
            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <DatePickerInput
                label="Birthday"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("birthday")}
                required
              />
              <Select
                label="Gender"
                disabled={!isEditing} // Editable when isEditing is true
                data={["male", "female"]}
                variant="filled"
                {...form.getInputProps("gender")}
                required
              />
            </SimpleGrid>
            {isEditing && (
              <Group position="left" mt="xl">
                <Button
                  type="submit"
                  size="md"
                  loading={isSubmitting}
                  style={{ backgroundColor: "black", color: "white" }}
                >
                  Update
                </Button>
              </Group>
            )}
          </form>
        </Paper>
      </Container>
    </div>
  );
}

export default AdminViewEditAccount;
