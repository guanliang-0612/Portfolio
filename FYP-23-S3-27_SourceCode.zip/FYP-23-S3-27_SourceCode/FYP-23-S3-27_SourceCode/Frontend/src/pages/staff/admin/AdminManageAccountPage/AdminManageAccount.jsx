/* 
 Usecase:
 A06
 A08
 A12
*/
import { useState, useEffect, useMemo } from "react";
import {
  createStyles,
  Table,
  ScrollArea,
  UnstyledButton,
  Group,
  Text,
  Center,
  TextInput,
  rem,
  px,
  Button,
  Tabs,
  LoadingOverlay,
} from "@mantine/core";

import {
  IconSelector,
  IconChevronDown,
  IconChevronUp,
  IconSearch,
} from "@tabler/icons-react";
/* import data from "./AdminAccountTableData"; */
import { useNavigate, Link } from "react-router-dom";
import { getAllUserDetails } from "../../../../services/userService";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex", // Add this
    justifyContent: "flex-end", // Add this to align items to the right
    width: "100%", // This ensures it takes the full width of the wrapper
    height: "10%", // Set the height to be 10% of the wrapper
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  th: {
    padding: "0 !important",
  },

  control: {
    width: "100%",
    padding: `${theme.spacing.xs} ${theme.spacing.md}`,

    "&:hover": {
      backgroundColor:
        theme.colorScheme === "dark"
          ? theme.colors.dark[6]
          : theme.colors.gray[0],
    },
  },

  icon: {
    width: rem(21),
    height: rem(21),
    borderRadius: rem(21),
  },
  textInputRight: {
    width: "20%", // Set width
    float: "right", // Align to right
  },
  scrollArea: {
    /* maxHeight: "526px", // Set a fixed max height */
    /* overflowY: "auto", */ // Enable vertical scrolling
    display: "flex",
    width: "100%",
    height: "100%",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black", // or any color you prefer
    color: "black",
    height: "4rem",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
    height: "3rem",
    // ... other styles
  },
  scrollWrapper: {
    position: "relative",
    height: `calc(100% - 7rem)})`,
  },
}));

function Th({ children, reversed, sorted, onSort }) {
  const { classes } = useStyles();
  const Icon = sorted
    ? reversed
      ? IconChevronUp
      : IconChevronDown
    : IconSelector;
  return (
    <th className={classes.th}>
      <UnstyledButton onClick={onSort} className={classes.control}>
        <Group position="apart">
          <Text fw={500} fz="sm">
            {children}
          </Text>
          <Center className={classes.icon}>
            <Icon size="0.9rem" stroke={1.5} />
          </Center>
        </Group>
      </UnstyledButton>
    </th>
  );
}

function filterData(data, search, searchFields = []) {
  const query = search.toLowerCase().trim();
  let fields = searchFields.length > 0 ? searchFields : Object.keys(data[0]);

  const filterResults = data.filter((item) => {
    return fields.some((key) => {
      if (typeof item[key] !== "string") return false;
      return item[key]?.toLowerCase().includes(query);
    });
  });
  return filterResults;
}

function sortData(data, payload) {
  const { sortBy, searchFields = [] } = payload;
  if (!sortBy) {
    return filterData(data, payload.search, searchFields);
  }

  return filterData(
    [...data].sort((a, b) => {
      if (payload.reversed) {
        return b[sortBy].localeCompare(a[sortBy]);
      }

      return a[sortBy].localeCompare(b[sortBy]);
    }),
    payload.search,
    searchFields
  );
}

export function AccountTable(props) {
  const [search, setSearch] = useState("");
  const [data, setData] = useState([]);
  const [sortedData, setSortedData] = useState([]);
  const [sortBy, setSortBy] = useState(null);
  const [reverseSortDirection, setReverseSortDirection] = useState(false);
  const { classes } = useStyles();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState();
  const searchFields = useMemo(() => ["dname", "email", "role", "status"], []);
  const handleTabClick = (value) => {
    if (value === "first") {
      navigate("/AdminManageAccountPage");
    } else if (value === "second") {
      navigate("/AdminCreateStaffAccountPage");
    }
  };

  useEffect(() => {
    setSortedData(
      sortData(data, {
        sortBy,
        reversed: reverseSortDirection,
        search,
        searchFields,
      })
    );
  }, [data, searchFields, reverseSortDirection, search, sortBy]);

  useEffect(() => {
    async function getData() {
      setIsLoading(true);
      const results = await getAllUserDetails();
      setData(results);
      setIsLoading(false);
    }
    getData();
  }, []);
  const setSorting = (field) => {
    // 1st click sorts by field without reverse
    // 2nd click sorts by field with reverse
    // 3rd click resets sorting
    if (field === sortBy && reverseSortDirection) {
      setSortBy();
      setReverseSortDirection(false);
      return;
    }
    const reversed = field === sortBy ? !reverseSortDirection : false;
    setSortBy(field);
    setReverseSortDirection(reversed);
  };

  const handleSearchChange = (event) => {
    const { value } = event.currentTarget;
    setSearch(value);
  };

  const rows = sortedData.map((row) => (
    <tr key={row.id}>
      <td>{row.dname}</td>
      <td>{row.email}</td>
      <td>{row.role}</td>
      <td>{row.status}</td>
      <td>
        <Button
          color="dark"
          variant="subtle"
          size="xs"
          radius="xl"
          component={Link}
          to={`/AdminViewEditAccountPage/${row.id}`}
        >
          View
        </Button>
      </td>
    </tr>
  ));

  return (
    <div className={classes.wrapper}>
      {/* Add a container for Manage Account and Search Bar */}
      <div className={classes["manage-account-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0, // Remove margin to align properly
          }}
          weight={500}
        >
          Manage Account
        </Text>

        <TextInput
          style={{ margin: 0 }} // Remove margin to align properly
          className={classes.textInputRight}
          placeholder="Search by any field"
          icon={<IconSearch size="0.9rem" stroke={1.5} />}
          value={search}
          onChange={handleSearchChange}
        />
      </div>
      {/* Add Tabs here */}
      <div className={classes["tabs-container"]}>
        <Tabs defaultValue="first" onTabChange={handleTabClick}>
          <Tabs.List>
            <Tabs.Tab value="first" color="dark">
              View All Account
            </Tabs.Tab>
            <Tabs.Tab value="second" color="dark">
              Create Staff Account
            </Tabs.Tab>
          </Tabs.List>
        </Tabs>
      </div>
      {/* End of Tabs */}

      <div className={classes.scrollWrapper}>
        <LoadingOverlay
          visible={isLoading}
          overlayOpacity={1}
          loaderProps={{ color: "dark" }}
        />
        <ScrollArea className={classes.scrollArea}>
          <Table
            striped
            highlightOnHover
            horizontalSpacing="md"
            verticalSpacing="xs"
            /* sx={{ tableLayout: "fixed" }} */
          >
            <thead>
              <tr>
                <Th
                  sorted={sortBy === "dname"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("dname")}
                >
                  Display Name
                </Th>
                <Th
                  sorted={sortBy === "email"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("email")}
                >
                  Email
                </Th>
                <Th
                  sorted={sortBy === "role"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("role")}
                >
                  Account Type
                </Th>
                <Th
                  sorted={sortBy === "status"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("status")}
                >
                  Status
                </Th>
                <th>
                  {/* <Button
                    onClick={() => {
                      setSortBy();
                      setReverseSortDirection(false);
                    }}
                    color="dark"
                    style={{ padding: "5px", height: "min-content" }}
                  >
                    Reset sort
                  </Button> */}
                </th>
                {/*  header for the "View" column */}
              </tr>
            </thead>
            <tbody>
              {rows.length > 0 ? (
                rows
              ) : (
                <tr>
                  <td colSpan={5}>
                    <Text weight={500} align="center">
                      Nothing found
                    </Text>
                  </td>
                </tr>
              )}
            </tbody>
          </Table>
        </ScrollArea>
      </div>
    </div>
  );
}
export default AccountTable;
