import ViewIndividualReport from "./ViewIndividualReport";
const ViewIndividualReportPage = () => {
  return (
    <div>
      <ViewIndividualReport />
      <br />
    </div>
  );
};

export default ViewIndividualReportPage;
