/* 
 Usecase:
 A07
*/
import { useState } from "react";
import {
  createStyles,
  ScrollArea,
  Text,
  Tabs,
  Container,
  Paper,
  TextInput,
  SimpleGrid,
  Button,
  Group,
  PasswordInput,
  rem,
  Select,
} from "@mantine/core";
import { useForm, hasLength, isNotEmpty, isEmail } from "@mantine/form";
import { useNavigate } from "react-router-dom";
import { createStaffAccount } from "../../../../services/authService";
import useAlerts from "../../../../hooks/useAlerts";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },
  paperStyle: {
    width: "100%", // or any specific width you want, e.g.
    padding: 0,
    // remove padding
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontSize: rem(62),
    fontWeight: 900,
    lineHeight: 1.1,
    margin: 0,
    padding: 0,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(42),
      lineHeight: 1.2,
    },
  },

  description: {
    marginTop: theme.spacing.xl,
    fontSize: rem(24),

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(18),
    },
  },

  flexContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  leftGrid: {
    flex: 1,
  },

  rightGrid: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },

  buttonGroup: {
    display: "flex",
    justifyContent: "space-between",
    width: "100%",
    marginTop: "10px",
  },
}));

export function CreateStaffAccount(props) {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const form = useForm({
    initialValues: {
      dname: "",
      fname: "",
      lname: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "support", // default value
      status: "Active", // default value
    },
    validate: {
      fname: hasLength({ min: 2 }, "Invalid first name"),
      lname: hasLength({ min: 2 }, "Invalid last name"),
      dname: isNotEmpty("Enter your display name"),
      email: isEmail("Invalid email"),
      password: (val) =>
        val.length > 0 && val.length <= 7
          ? "Password should include more then 8 characters."
          : null,
      confirmPassword: (value) =>
        form.values.password === value ? null : "Passwords do not match.",
    },
  });
  const { AlertDisplay, closeAlert, displayError, displaySuccess } =
    useAlerts();
  const handleTabClick = (value) => {
    if (value === "first") {
      navigate("/AdminManageAccountPage");
    } else if (value === "second") {
      navigate("/AdminCreateStaffAccountPage");
    }
  };

  const handleSubmit = async ({
    dname,
    fname,
    lname,
    email,
    password,
    role,
    status,
  }) => {
    try {
      closeAlert();
      setIsSubmitting(true);
      await createStaffAccount({
        dname,
        fname,
        lname,
        email,
        password,
        role,
        status,
      });
      displaySuccess("Staff account created");
    } catch (error) {
      switch (error.code) {
        case "auth/duplicate-display-name":
          form.setFieldError(
            "dname",
            "An account with this display name already exists"
          );
          form.setFieldValue("currentPassword", "");
          break;
        case "auth/email-already-in-use":
          form.setFieldError(
            "email",
            "An account with this email already exists"
          );
          form.setFieldValue("currentPassword", "");
          break;
        default:
          displayError("Create staff account failed");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={classes.wrapper}>
      {/* Add a container for Manage Account */}
      <div className={classes["manage-account-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          Manage Account
        </Text>
      </div>
      {/* Add Tabs here */}
      <div className={classes["tabs-container"]}>
        <Tabs defaultValue="second" onTabChange={handleTabClick}>
          <Tabs.List>
            <Tabs.Tab value="first" color="dark">
              View All Account
            </Tabs.Tab>
            <Tabs.Tab value="second" color="dark">
              Create Staff Account
            </Tabs.Tab>
          </Tabs.List>
        </Tabs>
      </div>
      {/* End of Tabs */}

      <ScrollArea>
        {/*  form content starts here */}
        <Container position="left" size={900}>
          <Text
            fz="xl"
            ta="left"
            style={{
              color: "black",
              marginTop: "20px",
            }}
            weight={500}
          >
            Create Staff Account
          </Text>
          <Paper radius="md" withBorder={false}>
            {/* ... form content */}
            <form
              onSubmit={form.onSubmit(handleSubmit)}
              style={{ width: "80%" }}
            >
              <AlertDisplay />
              <SimpleGrid
                cols={2}
                mt="xl"
                breakpoints={[{ maxWidth: "sm", cols: 1 }]}
              >
                <TextInput
                  label="Display Name"
                  variant="default"
                  withAsterisk
                  {...form.getInputProps("dname")}
                />
                <TextInput
                  label="Email"
                  variant="default"
                  withAsterisk
                  {...form.getInputProps("email")}
                  // Display the error message if validation fails
                />
              </SimpleGrid>

              <SimpleGrid
                cols={2}
                mt="xl"
                breakpoints={[{ maxWidth: "sm", cols: 1 }]}
              >
                <TextInput
                  label="First Name"
                  variant="default"
                  withAsterisk
                  {...form.getInputProps("fname")}
                />
                <TextInput
                  label="Last Name"
                  variant="default"
                  withAsterisk
                  {...form.getInputProps("lname")}
                />
              </SimpleGrid>

              <SimpleGrid
                cols={2}
                mt="xl"
                breakpoints={[{ maxWidth: "sm", cols: 1 }]}
              >
                <PasswordInput
                  label="Password"
                  variant="default"
                  withAsterisk
                  {...form.getInputProps("password")}
                />

                <PasswordInput
                  label="Confirm Password"
                  variant="default"
                  withAsterisk
                  {...form.getInputProps("confirmPassword")}
                  error={form.errors.confirmPassword} // Display the error message if validation fails
                />
              </SimpleGrid>
              <SimpleGrid
                cols={2}
                mt="xl"
                breakpoints={[{ maxWidth: "sm", cols: 1 }]}
              >
                <Select
                  label="Account Type"
                  data={[
                    { label: "Customer Service", value: "support" },
                    { label: "Admin", value: "admin" },
                  ]}
                  withAsterisk
                  {...form.getInputProps("role")}
                />
                <Select
                  label="Account Status"
                  data={[
                    { label: "Active", value: "active" },
                    { label: "Inactive", value: "inactive" },
                  ]}
                  withAsterisk
                  {...form.getInputProps("status")}
                />
              </SimpleGrid>

              <Group position="left" mt="xl">
                <Button
                  type="submit"
                  size="md"
                  style={{
                    backgroundColor: "black",
                    color: "white",
                    marginTop: "14px",
                  }}
                  loading={isSubmitting}
                >
                  Create Account
                </Button>
              </Group>
            </form>
          </Paper>
        </Container>
        {/* Your form content ends here */}
      </ScrollArea>
    </div>
  );
}

export default CreateStaffAccount;
