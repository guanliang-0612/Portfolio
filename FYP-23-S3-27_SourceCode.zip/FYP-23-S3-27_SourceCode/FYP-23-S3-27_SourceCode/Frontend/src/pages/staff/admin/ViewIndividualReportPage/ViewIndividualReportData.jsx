const data = [
  {
    id: "GkdFa7h4lGUNdf3XmCxX",
    subject: "Listing - Inappropriate Listing",
    name: "Athena Wong",
    email: "Athena_Wong@yahoo.com",
    receivedDate: "03/09/2023",
    status: "Open",
    //i put a placeholder to test, this can be removed if we decided to remove this functions, where
    //admin can stright away view the listing and customer page from view indiviual report
    listingurl: "https://fyp23s327.wixsite.com/top-care-fashion-1",
    customerurl: "https://fyp23s327.wixsite.com/top-care-fashion-1",
    emailcontent:
      " I hope this message finds you well. I'm currently trying to update my profile on your platform and am unsure of the steps involved. Could you please provide me with instructions or direct me to a guide on how to edit my profile? Thank you for your assistance.",
  },
];

export default data;
