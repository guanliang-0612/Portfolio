import ReportTable from "./AdminReportDashboard";
const AdminReportDashboardPage = () => {
  return (
    <div>
      <ReportTable />
      <br />
    </div>
  );
};

export default AdminReportDashboardPage;
