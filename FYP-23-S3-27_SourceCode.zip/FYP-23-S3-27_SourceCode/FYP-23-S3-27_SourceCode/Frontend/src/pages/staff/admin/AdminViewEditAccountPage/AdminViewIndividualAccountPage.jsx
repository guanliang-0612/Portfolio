import { useLocation, useParams } from "react-router-dom";
import AdminViewEditAccount from "./AdminViewEditAccount";
const AdminViewEditAccountPage = () => {
  const { id } = useParams();

  return (
    <div>
      <AdminViewEditAccount accountId={id} />
      <br />
    </div>
  );
};

export default AdminViewEditAccountPage;
