import AccountTable from "./AdminManageAccount";
const AdminManageAccountPage = () => {
  return (
    <div>
      <AccountTable />
      <br />
    </div>
  );
};

export default AdminManageAccountPage;
