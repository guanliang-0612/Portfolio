const data = [
  {
    accounttype: "Customer Support",
    dname: "tcf_sam",
    email: "samsmith@tcf.com",
    status: "Active",
  },
  {
    accounttype: "Admin",
    dname: "tcf_popo",
    email: "willsmithpopo@tcf.com",
    status: "Active",
  },

  {
    accounttype: "Customer Support",
    dname: "tcf_joe",
    email: "joesmith@tcf.com",
    status: "Active",
  },

  {
    accounttype: "Admin",
    dname: "tcf_john",
    email: "johnsm@tcf.com",
    status: "Active",
  },

  {
    accounttype: "Customer",
    dname: "Danny_C",
    email: "Marina3@hotmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Trace_F",
    email: "Antonina.Pouros@yahoo.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "De_rekK",
    email: "Abagail29@hotmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Viola_Bernhard",
    email: "Jamie23@hotmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Austin_J",
    email: "Genesis42@yahoo.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Hershel_MC",
    email: "Idella.Stehr28@yahoo.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Mylene_t",
    email: "Hildegard17@hotmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Lou_tw",
    email: "Hillard.Barrows1@hotmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Dariana_Kan",
    email: "Colleen80@gmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Christy_HM",
    email: "Lilyan98@gmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Katelin Schuster",
    email: "Erich_Brekke76@gmail.com",
    status: "Active",
  },
  {
    accounttype: "Customer",
    dname: "Melyna Macejkovic",
    email: "Kylee4@yahoo.com",
    status: "Active",
  },
];

export default data;
