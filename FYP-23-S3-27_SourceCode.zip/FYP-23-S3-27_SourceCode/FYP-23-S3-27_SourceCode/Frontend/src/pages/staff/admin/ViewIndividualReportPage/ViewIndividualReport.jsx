/* 
 Usecase:
 A14
 A15(done except getting userID)
 A16(done except getting details of a report from another page)
 A17
 A19
*/
import React, { useState, useEffect } from "react";
import {
  createStyles,
  Text,
  rem,
  Paper,
  Select,
  Textarea,
  Container,
  SimpleGrid,
  Button,
  Anchor,
} from "@mantine/core";
import { auth, db } from "../../../../libs/firebase";
import { useNavigate, useLocation } from "react-router-dom";
import data from "./ViewIndividualReportData";
import { IconArrowNarrowLeft } from "@tabler/icons-react";
import {
  updateReportStatus,
  updateReportLogHistory,
  getLogs,
} from "../../../../services/reportService";
import { getAuth } from "firebase/auth";
import { useAuth } from "../../../../contexts/AuthContext";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },

  textArea: {
    marginTop: "10px",
    minHeight: "200x",
    maxHeight: "300px ",
  },
  userLogDisplay: {
    minHeight: rem(400),
    border: `1px solid ${theme.colors.gray[4]}`,
    padding: rem(16),
    marginBottom: rem(16),

    flexContainer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      flexDirection: "row", // ensure horizontal layout
    },
  },
}));

export function ViewIndividualReport(props) {
  const auth = getAuth();
  const { currentUser } = useAuth();
  // The user object has basic properties such as display name, email, etc.

  // The user's ID, unique to the Firebase project. Do NOT use
  // this value to authenticate with your backend server, if
  // you have one. Use User.getToken() instead.
  const uid = currentUser.id;

  const { classes } = useStyles();
  const navigate = useNavigate();
  const ticket = data[0];
  const [userLog, setUserLog] = useState("");
  const [displayedLogs, setDisplayedLogs] = useState([]);
  const [dropDownValue, setDropDownValue] = useState("");
  const handleNavigateToDashboard = () => {
    navigate("/AdminReportDashboardPage");
  };
  const location = useLocation();
  const getID = location.state.id;

  const setLog = (logs) => {
    const logging = logs.map((log) => [
      `${log.timestamp.toDate().toLocaleString()}: ${log.action_taken}`,
    ]);
    setDisplayedLogs([...logging]);
  };

  useEffect(() => {
    async function getData() {
      const logs = await getLogs(getID);
      logs.sort((a, b) => {
        return b.timestamp - a.timestamp;
      });
      setLog(logs);
    }
    getData();
  }, []);

  const handleSaveLog = (event) => {
    if (event.key === "Enter" && userLog.trim() !== "") {
      const timestamp = new Date().toLocaleString();
      setDisplayedLogs((prevLogs) => [`${timestamp}: ${userLog}`, ...prevLogs]);
      setUserLog("");
      updateReportLogHistory(getID, userLog, uid);
      event.preventDefault(); // Prevents the default behavior of the Enter key
    }
  };

  const handleDropDown = (event) => {
    setDropDownValue(event);
    updateReportStatus(getID, event);
    window.setTimeout(function () {
      alert("Report Status Updated Successfully.");
    }, 500);
  };

  return (
    <div className={classes.wrapper}>
      {/* Manage Account Container */}
      <div className={classes["manage-account-container"]}>
        <Text fz="xl" style={{ color: "white", margin: 0 }} weight={500}>
          Report
        </Text>
        <div onClick={handleNavigateToDashboard} style={{ cursor: "pointer" }}>
          <IconArrowNarrowLeft color="white" size={24} />
        </div>
      </div>

      <Container size={1200}>
        <SimpleGrid cols={2} spacing={rem(24)} style={{ marginTop: "20px" }}>
          {/* Left Column */}
          <div>
            <Paper>
              <Text
                fz="lg"
                style={{
                  marginRight: "16px",
                  fontSize: "1rem",
                  fontWeight: 500,
                  color: "#212529",
                }}
              >
                ID: {location.state.id}
              </Text>
              <Text
                fz="lg"
                style={{
                  marginRight: "16px",
                  fontSize: "1rem",
                  fontWeight: 500,
                  color: "#212529",
                }}
              >
                Subject: {location.state.subject}
              </Text>
              <Text
                fz="lg"
                style={{
                  marginRight: "16px",
                  fontSize: "1rem",
                  fontWeight: 500,
                  color: "#212529",
                }}
              >
                Name: {location.state.username}
              </Text>
              <Text
                fz="lg"
                style={{
                  marginRight: "16px",
                  fontSize: "1rem",
                  fontWeight: 500,
                  color: "#212529",
                }}
              >
                Email: {location.state.email}
              </Text>
              <Text
                fz="lg"
                style={{
                  marginRight: "16px",
                  fontSize: "1rem",
                  fontWeight: 500,
                  color: "#212529",
                }}
              >
                Receive Date: {location.state.receivedDate}
              </Text>

              <Container
                style={{
                  display: "flex",
                  alignItems: "flex-end",
                  justifyContent: "space-between",
                  padding: "0px",
                }}
              >
                <Select
                  label="Status"
                  style={{ maxWidth: "7rem" }}
                  onChange={(event) => handleDropDown(event)}
                  data={[
                    { value: "Open", label: "Open" },
                    { value: "Pending", label: "Pending" },
                    { value: "Closed", label: "Closed" },
                  ]}
                  defaultValue={location.state.status}
                />
                <Container
                  style={{
                    display: "flex",
                    height: "100%",
                    width: "100%",
                    justifyContent: "right",
                  }}
                >
                  {location.state.listingId && (
                    <Anchor
                      color="dark"
                      href={`/listing/${location.state.listingId}`}
                      target="_blank"
                    >
                      Manage Listing
                    </Anchor>
                  )}
                  <Anchor
                    color="dark"
                    style={{ marginLeft: "10px" }}
                    href={`/UserDashboard/${location.state.reportedUserId}`}
                    target="_blank"
                  >
                    View Customer Page
                  </Anchor>
                </Container>
              </Container>

              <Textarea
                label="Enquiry"
                autosize
                value={location.state.details}
                className={classes.textArea}
                minRows={12}
                maxRows={12}
              />
            </Paper>
          </div>
          {/* Right Column */}
          <div>
            <Paper>
              <Text fz="md" style={{ marginBottom: rem(3), fontWeight: 500 }}>
                Log History
              </Text>
              <Textarea
                autosize
                value={displayedLogs.join("\n")}
                readOnly
                style={{
                  marginBottom: "20px",
                }}
                minRows={19}
                maxRows={18}
              />
              <Textarea
                /* label="User Log" */
                autosize
                value={userLog}
                onChange={(event) => setUserLog(event.target.value)}
                onKeyDown={handleSaveLog}
                minRows={1}
                maxRows={1}
              />
            </Paper>
          </div>
        </SimpleGrid>
      </Container>
    </div>
  );
}

export default ViewIndividualReport;
