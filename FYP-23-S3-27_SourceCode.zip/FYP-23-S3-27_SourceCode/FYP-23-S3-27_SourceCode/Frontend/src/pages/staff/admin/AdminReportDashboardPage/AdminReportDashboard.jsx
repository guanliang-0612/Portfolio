/* 
 Usecase:
 A13
*/
import { auth, db } from "../../../../libs/firebase";
import { useState, useEffect, useMemo } from "react";
import {
  createStyles,
  Table,
  ScrollArea,
  UnstyledButton,
  Group,
  Text,
  Center,
  TextInput,
  rem,
  LoadingOverlay,
} from "@mantine/core";

import {
  IconSelector,
  IconChevronDown,
  IconChevronUp,
  IconSearch,
} from "@tabler/icons-react";
import { useNavigate, Link } from "react-router-dom";
import { getAuth, onAuthStateChanged } from "firebase/auth";
//import data from "./AdminReportDashboardData";
import { getAllReport } from "../../../../services/reportService";
const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex", // Add this
    justifyContent: "space-between", // Add this to align items to the right
    width: "100%", // This ensures it takes the full width of the wrapper
    height: "4rem", // Set the height to be 10% of the wrapper
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  scrollWrapper: {
    position: "relative",
    maxWidth: "100%",
    height: "calc(100% - 4rem)",
    display: "flex",
  },
  th: {
    padding: "0 !important",
  },

  control: {
    width: "100%",
    padding: `${theme.spacing.xs} ${theme.spacing.md}`,

    "&:hover": {
      backgroundColor:
        theme.colorScheme === "dark"
          ? theme.colors.dark[6]
          : theme.colors.gray[0],
    },
  },

  icon: {
    width: rem(21),
    height: rem(21),
    borderRadius: rem(21),
  },
  textInputRight: {
    width: "20%", // Set width
    float: "right", // Align to right
  },
  scrollArea: {
    width: "100%",
    height: "100%",
    display: "flex",
    // Enable vertical scrolling
  },
}));

function Th({ children, reversed, sorted, onSort }) {
  const { classes } = useStyles();
  const Icon = sorted
    ? reversed
      ? IconChevronUp
      : IconChevronDown
    : IconSelector;
  return (
    <th className={classes.th}>
      <UnstyledButton onClick={onSort} className={classes.control}>
        <Group position="apart" style={{ flexWrap: "nowrap" }}>
          <Text fw={500} fz="sm">
            {children}
          </Text>
          <Center className={classes.icon}>
            <Icon size="0.9rem" stroke={1.5} />
          </Center>
        </Group>
      </UnstyledButton>
    </th>
  );
}

function filterData(data, search, searchFields = []) {
  const query = search.toLowerCase().trim();
  let fields = searchFields.length > 0 ? searchFields : Object.keys(data[0]);

  const filterResults = data.filter((item) => {
    return fields.some((key) => {
      if (typeof item[key] !== "string") return false;
      return item[key]?.toLowerCase().includes(query);
    });
  });
  return filterResults;
}

function sortData(data, payload) {
  const { sortBy, searchFields = [] } = payload;
  if (!sortBy) {
    return filterData(data, payload.search, searchFields);
  }

  return filterData(
    [...data].sort((a, b) => {
      if (payload.reversed) {
        return b[sortBy].localeCompare(a[sortBy]);
      }

      return a[sortBy].localeCompare(b[sortBy]);
    }),
    payload.search,
    searchFields
  );
}

export function ReportTable(props) {
  const [search, setSearch] = useState("");
  const [data, setData] = useState([]);
  const [sortedData, setSortedData] = useState([]);
  const [sortBy, setSortBy] = useState(null);
  const [reverseSortDirection, setReverseSortDirection] = useState(false);
  const [reportsLoading, setReportsLoading] = useState(true);
  const searchFields = useMemo(
    () => ["id", "subject", "username", "email", "receivedDate", "status"],
    []
  );
  const { classes } = useStyles();
  const navigate = useNavigate();

  const auth = getAuth();
  const user = auth.currentUser;
  const uid = user.uid;

  useEffect(() => {
    setSortedData(
      sortData(data, {
        sortBy,
        reversed: reverseSortDirection,
        search,
        searchFields,
      })
    );
  }, [data, reverseSortDirection, search, searchFields, sortBy]);

  useEffect(() => {
    async function getData() {
      setReportsLoading(true);
      let data = await getAllReport();

      setData(data);
      setReportsLoading(false);
    }

    getData();
  }, []);

  const setSorting = (field) => {
    // 1st click sorts by field without reverse
    // 2nd click sorts by field with reverse
    // 3rd click resets sorting
    if (field === sortBy && reverseSortDirection) {
      setSortBy();
      setReverseSortDirection(false);
      return;
    }
    const reversed = field === sortBy ? !reverseSortDirection : false;
    setSortBy(field);
    setReverseSortDirection(reversed);
  };

  const handleSearchChange = (event) => {
    const { value } = event.currentTarget;
    setSearch(value);
  };
  const rows = sortedData.map((row) => (
    <tr
      style={{ cursor: "pointer" }}
      onClick={(event) => {
        navigate("/ViewIndividualReportPage", {
          state: {
            id: row.id,
            details: row.details,
            email: row.email,
            listingId: row.listingId,
            reportedUserId: row.reportedUserId,
            status: row.status,
            subject: row.subject,
            username: row.username,
            receivedDate: row.receivedDate,
            uid: uid,
          },
        });
      }}
      key={row.id}
    >
      <td>{row.id}</td>
      <td>{row.subject}</td>
      <td>{row.username}</td>
      <td>{row.email}</td>
      <td>{row.receivedDate}</td>
      <td>{row.status}</td>
    </tr>
  ));

  return (
    <div className={classes.wrapper}>
      <div className={classes.innerContainer}>
        <Text
          ta="left"
          fz="xl"
          style={{
            marginTop: "0",
            padding: "20px",
            color: "white",
          }}
          weight={500}
          mt="lg"
        >
          Report Dashboard
        </Text>
        <TextInput
          style={{ paddingTop: "18px", paddingRight: "18px" }}
          className={classes.textInputRight} // Apply the class here
          placeholder="Search by any field"
          mb="md"
          icon={<IconSearch size="0.9rem" stroke={1.5} />}
          value={search}
          onChange={handleSearchChange}
        />
      </div>
      <div className={classes.scrollWrapper}>
        <ScrollArea className={classes.scrollArea}>
          <LoadingOverlay
            loaderProps={{ color: "dark" }}
            overlayOpacity={1}
            visible={reportsLoading}
          />
          <Table
            striped
            highlightOnHover
            horizontalSpacing="md"
            verticalSpacing="xs"

            /* sx={{ tableLayout: "fixed" }} */
          >
            <thead>
              <tr>
                <Th
                  sorted={sortBy === "id"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("id")}
                >
                  ID
                </Th>
                <Th
                  sorted={sortBy === "subject"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("subject")}
                >
                  Subject
                </Th>
                <Th
                  sorted={sortBy === "username"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("username")}
                >
                  Username
                </Th>
                <Th
                  sorted={sortBy === "email"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("email")}
                >
                  Email
                </Th>
                <Th
                  sorted={sortBy === "receivedDate"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("receivedDate")}
                >
                  Receive Date
                </Th>
                <Th
                  sorted={sortBy === "status"}
                  reversed={reverseSortDirection}
                  onSort={() => setSorting("status")}
                >
                  Status
                </Th>
              </tr>
            </thead>

            <tbody>
              {rows.length > 0 ? (
                rows
              ) : (
                <tr>
                  {/* Set "nothing found" to span 6 columns such that it matches the number of table columns*/}
                  <td colSpan={6}>
                    <Text weight={500} align="center">
                      Nothing found
                    </Text>
                  </td>
                </tr>
              )}
            </tbody>
          </Table>
        </ScrollArea>
      </div>
    </div>
  );
}
export default ReportTable;
