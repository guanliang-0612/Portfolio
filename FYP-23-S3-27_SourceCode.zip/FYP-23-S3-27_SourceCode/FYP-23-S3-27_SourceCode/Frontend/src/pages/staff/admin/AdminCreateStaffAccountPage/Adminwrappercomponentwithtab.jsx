import { useState } from "react";
import { createStyles, ScrollArea, Text, rem, Tabs } from "@mantine/core";
import { useNavigate } from "react-router-dom";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },
}));

export function AdminEditUserAccount(props) {
  const { classes } = useStyles();
  const navigate = useNavigate();

  const handleTabClick = (value) => {
    if (value === "first") {
      navigate("/AdminManageAccountPage");
    } else if (value === "second") {
      navigate("/AdminCreateStaffAccountPage");
    }
  };

  return (
    <div className={classes.wrapper}>
      {/* Add a container for Manage Account */}
      <div className={classes["manage-account-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          Manage Account
        </Text>
      </div>
      {/* Add Tabs here */}
      <div className={classes["tabs-container"]}>
        <Tabs defaultValue="first" onTabChange={handleTabClick}>
          <Tabs.List>
            <Tabs.Tab value="first" color="dark">
              View All Account
            </Tabs.Tab>
            <Tabs.Tab value="second" color="dark">
              Create Staff Account
            </Tabs.Tab>
          </Tabs.List>
        </Tabs>
      </div>
      {/* End of Tabs */}

      <ScrollArea>{/* Replace content here */}</ScrollArea>
    </div>
  );
}

export default AdminEditUserAccount;
