import CreateStaffAccount from "./AdminCreateStaffAccount";
const AdminCreateStaffAccountPage = () => {
  return (
    <div>
      <CreateStaffAccount />
      <br />
    </div>
  );
};

export default AdminCreateStaffAccountPage;
