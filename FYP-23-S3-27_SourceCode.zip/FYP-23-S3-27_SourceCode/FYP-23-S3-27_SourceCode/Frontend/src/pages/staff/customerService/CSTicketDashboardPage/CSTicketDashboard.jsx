/* 
 Usecase:
 CS06(done)
 CS08(done)
*/
import { useState, useEffect, useMemo } from "react";
import {
  createStyles,
  Table,
  ScrollArea,
  UnstyledButton,
  Group,
  Text,
  Center,
  TextInput,
  rem,
} from "@mantine/core";

import {
  IconSelector,
  IconChevronDown,
  IconChevronUp,
  IconSearch,
} from "@tabler/icons-react";
import { useNavigate } from "react-router-dom";
//import data from "./CSTicketDashboardData";
import { GiNailedHead } from "react-icons/gi";
import { getAllQueries } from "../../../../services/queryService";
const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(600),
  },

  innerContainer: {
    display: "flex", // Add this
    justifyContent: "space-between",
    // Add this to align items to the right
    width: "100%", // This ensures it takes the full width of the wrapper
    height: "12%", // Set the height to be 10% of the wrapper
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  th: {
    padding: "0 !important",
  },

  control: {
    width: "100%",
    padding: `${theme.spacing.xs} ${theme.spacing.md}`,

    "&:hover": {
      backgroundColor:
        theme.colorScheme === "dark"
          ? theme.colors.dark[6]
          : theme.colors.gray[0],
    },
  },

  icon: {
    width: rem(21),
    height: rem(21),
    borderRadius: rem(21),
  },
  textInputRight: {
    width: "20%", // Set width
    float: "right", // Align to right
  },
  scrollArea: {
    maxHeight: "526px", // Set a fixed max height
    overflowY: "auto", // Enable vertical scrolling
  },
}));

function Th({ children, reversed, sorted, onSort }) {
  const { classes } = useStyles();
  const Icon = sorted
    ? reversed
      ? IconChevronUp
      : IconChevronDown
    : IconSelector;
  return (
    <th className={classes.th}>
      <UnstyledButton onClick={onSort} className={classes.control}>
        <Group position="apart">
          <Text fw={500} fz="sm">
            {children}
          </Text>
          <Center className={classes.icon}>
            <Icon size="0.9rem" stroke={1.5} />
          </Center>
        </Group>
      </UnstyledButton>
    </th>
  );
}

function filterData(data, search, searchFields = []) {
  const query = search.toLowerCase().trim();
  let fields = searchFields.length > 0 ? searchFields : Object.keys(data[0]);

  const filterResults = data.filter((item) => {
    return fields.some((key) => {
      if (typeof item[key] !== "string") return false;
      return item[key]?.toLowerCase().includes(query);
    });
  });
  return filterResults;
}

function sortData(data, payload) {
  const { sortBy, searchFields = [] } = payload;
  if (!sortBy) {
    return filterData(data, payload.search, searchFields);
  }

  return filterData(
    [...data].sort((a, b) => {
      if (payload.reversed) {
        return b[sortBy].localeCompare(a[sortBy]);
      }

      return a[sortBy].localeCompare(b[sortBy]);
    }),
    payload.search,
    searchFields
  );
}
export function CSTicketDashboard(props) {
  const [search, setSearch] = useState("");
  const [data, setData] = useState([]);
  const [sortedData, setSortedData] = useState([]);
  const [sortBy, setSortBy] = useState(null);
  const [reverseSortDirection, setReverseSortDirection] = useState(false);
  const { classes } = useStyles();
  const navigate = useNavigate();
  const searchFields = useMemo(
    () => ["id", "subject", "email", "receivedDate", "status"],
    []
  );
  useEffect(() => {
    async function getData() {
      const queries = await getAllQueries();
      setData(queries);
    }

    getData();
  }, []);

  useEffect(() => {
    setSortedData(
      sortData(data, {
        sortBy,
        reversed: reverseSortDirection,
        search,
        searchFields,
      })
    );
  }, [data, reverseSortDirection, search, searchFields, sortBy]);

  const setSorting = (field) => {
    const reversed = field === sortBy ? !reverseSortDirection : false;
    setReverseSortDirection(reversed);
    setSortBy(field);
  };

  const handleSearchChange = (event) => {
    const { value } = event.currentTarget;
    setSearch(value);
  };

  const rows = sortedData.map((row) => (
    <tr
      style={{ cursor: "pointer" }}
      onClick={() =>
        navigate("/CSViewIndividualTicketPage", {
          state: {
            id: row.id,
            email: row.email,
            status: row.status,
            subject: row.subject,
            fname: row.fname,
            lname: row.lname,
            details: row.details,
            receivedDate: row.receivedDate,
          },
        })
      }
      key={row.id}
    >
      <td>{row.id}</td>
      <td>{row.subject}</td>
      <td>{row.email}</td>
      <td>{row.receivedDate}</td>
      <td>{row.status}</td>
    </tr>
  ));

  return (
    <div className={classes.wrapper}>
      <div className={classes.innerContainer}>
        <Text
          ta="left"
          fz="xl"
          style={{
            marginTop: "0",
            padding: "20px",
            color: "white",
          }}
          weight={500}
          mt="lg"
        >
          Ticket Dashboard
        </Text>
        <TextInput
          style={{ paddingTop: "18px", paddingRight: "18px", width: "25%" }}
          className={classes.textInputRight} // Apply the class here
          placeholder="Search by any field"
          mb="md"
          icon={<IconSearch size="0.9rem" stroke={1.5} />}
          value={search}
          onChange={handleSearchChange}
        />
      </div>
      <ScrollArea className={classes.scrollArea}>
        <Table
          striped
          highlightOnHover
          horizontalSpacing="md"
          verticalSpacing="xs"
          miw={700}
          /* sx={{ tableLayout: "fixed" }} */
        >
          <thead>
            <tr>
              <Th
                sorted={sortBy === "id"}
                reversed={reverseSortDirection}
                onSort={() => setSorting("id")}
              >
                ID
              </Th>
              <Th
                sorted={sortBy === "subject"}
                reversed={reverseSortDirection}
                onSort={() => setSorting("subject")}
              >
                Subject
              </Th>
              <Th
                sorted={sortBy === "email"}
                reversed={reverseSortDirection}
                onSort={() => setSorting("email")}
              >
                Email
              </Th>
              <Th
                sorted={sortBy === "receivedDate"}
                reversed={reverseSortDirection}
                onSort={() => setSorting("receivedDate")}
              >
                Receive Date
              </Th>
              <Th
                sorted={sortBy === "status"}
                reversed={reverseSortDirection}
                onSort={() => setSorting("status")}
              >
                Status
              </Th>
            </tr>
          </thead>
          <tbody>
            {rows.length > 0 ? (
              rows
            ) : (
              <tr
                style={{ cursor: "pointer" }}
                onClick={() => navigate("/CSViewIndividualTicketPage")}
              >
                <td colSpan={searchFields.length}>
                  <Text weight={500} align="center">
                    Nothing found
                  </Text>
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </ScrollArea>
    </div>
  );
  TableSort.defaultProps = {
    data: data,
  };
}
export default CSTicketDashboard;
