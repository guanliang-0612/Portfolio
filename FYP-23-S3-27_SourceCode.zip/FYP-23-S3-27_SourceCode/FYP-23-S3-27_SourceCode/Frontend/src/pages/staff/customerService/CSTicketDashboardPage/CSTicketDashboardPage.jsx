import CSTicketDashboard from "./CSTicketDashboard";
const CSTicketDashboardPage = () => {
  return (
    <div>
      <CSTicketDashboard />
      <br />
    </div>
  );
};

export default CSTicketDashboardPage;
