/* 
 Usecase:
 CS07(need to find out how to retrieve data)
 CS09(done)
 CS10(need to find out how to get customer support ID)
*/
import React, { useState, useEffect, useRef } from "react";
import {
  createStyles,
  ScrollArea,
  Text,
  rem,
  Tabs,
  Paper,
  Select,
  Textarea,
  Container,
  SimpleGrid,
  Button,
  Anchor,
} from "@mantine/core";
import { useNavigate, useLocation } from "react-router-dom";
//import data from './CSVIewIndividualTicketData'
import { IconArrowNarrowLeft, IconMail } from "@tabler/icons-react";
import {
  updateQueryStatus,
  updateQueryLogHistory,
  getLogs,
} from "../../../../services/queryService";
import { getAuth } from "firebase/auth";
//import { updateReportLogHistory } from "@/services/reportService";
const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },
  "tabs-container": {
    padding: "10px",
    backgroundColor: "#f5f5f5",
  },

  textArea: {
    minHeight: "200x",
    maxHeight: "300px ",
  },
  userLogDisplay: {
    minHeight: rem(400),
    border: `1px solid ${theme.colors.gray[4]}`,
    padding: rem(16),
    marginBottom: rem(16),

    flexContainer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      flexDirection: "row", // ensure horizontal layout
    },
  },
}));

export function CSViewIndividualTicket(props) {
  const { classes } = useStyles();
  const navigate = useNavigate();
  //const ticket = data[0]
  const [userLog, setUserLog] = useState("");
  const [displayedLogs, setDisplayedLogs] = useState([]);
  const [initialLogs, setInitialLogs] = useState([]);
  const [dropDownValue, setDropDownValue] = useState("");
  const location = useLocation();
  const getID = location.state.id;
  const dataFetch = useRef(false);
  const generateMailToLink = (email) => {
    return `mailto:${email}`;
  };
  const handleNavigateToDashboard = () => {
    navigate("/CSTicketDashboardPage");
  };

  const auth = getAuth();
  const user = auth.currentUser;
  if (user !== null) {
    // The user object has basic properties such as display name, email, etc.
    const displayName = user.displayName;
    const email = user.email;
    const photoURL = user.photoURL;
    const emailVerified = user.emailVerified;

    // The user's ID, unique to the Firebase project. Do NOT use
    // this value to authenticate with your backend server, if
    // you have one. Use User.getToken() instead.
    const uid = user.uid;

    const setLog = (logs) => {
      let message = [];
      const logging = logs.map((log) => [
        `${log.timestamp.toDate().toLocaleString()}: ${log.action_taken}`,
      ]);
      setDisplayedLogs([...logging]);
    };

    useEffect(() => {
      async function getData() {
        const logs = await getLogs(getID);
        logs.sort((a, b) => {
          return b.timestamp - a.timestamp;
        });
        setLog(logs);
      }
      getData();
    }, []);
    const handleSaveLog = (event) => {
      if (event.key === "Enter" && userLog.trim() !== "") {
        const timestamp = new Date().toLocaleString();
        setDisplayedLogs((prevLogs) => [
          `${timestamp}: ${userLog}`,
          ...prevLogs,
        ]);
        setUserLog("");
        updateQueryLogHistory(location.state.id, userLog, uid);
        event.preventDefault(); // Prevents the default behavior of the Enter key
      }
    };

    const handleDropDown = (event) => {
      setDropDownValue(event);
      updateQueryStatus(location.state.id, event);
      window.setTimeout(function () {
        alert("Query Status Updated Successfully.");
      }, 1500);
    };

    return (
      <div className={classes.wrapper}>
        {/* Manage Account Container */}
        <div className={classes["manage-account-container"]}>
          <Text fz="xl" style={{ color: "white", margin: 0 }} weight={500}>
            Ticket
          </Text>
          <div
            onClick={handleNavigateToDashboard}
            style={{ cursor: "pointer" }}
          >
            <IconArrowNarrowLeft color="white" size={24} />
          </div>
        </div>

        <Container size={1200}>
          <SimpleGrid cols={2} spacing={rem(24)} style={{ marginTop: "20px" }}>
            {/* Left Column */}
            <div>
              <Paper>
                <Text
                  fz="lg"
                  style={{
                    marginRight: "16px",
                    fontSize: "1rem",
                    fontWeight: 500,
                    color: "#212529",
                  }}
                >
                  ID: {location.state.id}
                </Text>
                <Text
                  fz="lg"
                  style={{
                    marginRight: "16px",
                    fontSize: "1rem",
                    fontWeight: 500,
                    color: "#212529",
                  }}
                >
                  Subject: {location.state.subject}
                </Text>
                <Text
                  fz="lg"
                  style={{
                    marginRight: "16px",
                    fontSize: "1rem",
                    fontWeight: 500,
                    color: "#212529",
                  }}
                >
                  Name: {`${location.state.fname} ${location.state.lname}`}
                </Text>
                <Text
                  fz="lg"
                  style={{
                    marginRight: "16px",
                    fontSize: "1rem",
                    fontWeight: 500,
                    color: "#212529",
                  }}
                >
                  Email: {location.state.email}
                </Text>
                <Text
                  fz="lg"
                  style={{
                    marginRight: "16px",
                    fontSize: "1rem",
                    fontWeight: 500,
                    color: "#212529",
                  }}
                >
                  Receive Date: {location.state.receivedDate}
                </Text>
                <Container
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "0px",
                  }}
                >
                  <Select
                    label="Status"
                    style={{ maxWidth: "105px" }}
                    data={[
                      { value: "Open", label: "Open" },
                      { value: "Pending", label: "Pending" },
                      { value: "Closed", label: "Closed" },
                    ]}
                    onChange={(event) => handleDropDown(event)}
                    defaultValue={location.state.status}
                  />

                  <Anchor
                    href={generateMailToLink(location.state.email)}
                    style={{
                      textDecoration: "none",
                      marginLeft: "10px",
                      marginTop: "10px",
                    }}
                  >
                    <Button
                      variant="default"
                      color="grey"
                      size="sm"
                      leftIcon={<IconMail size="1rem" />}
                      style={{ marginTop: "16px" }}
                    >
                      Send Email
                    </Button>
                  </Anchor>
                </Container>
                <Textarea
                  style={{ marginTop: "13px" }}
                  label="Enquiry"
                  autosize
                  value={location.state.details}
                  className={classes.textArea}
                  minRows={12}
                  maxRows={12}
                />
              </Paper>
            </div>
            {/* Right Column */}
            <div>
              <Paper>
                <Text fz="md" style={{ marginBottom: rem(3), fontWeight: 500 }}>
                  Log History
                </Text>
                <Textarea
                  autosize
                  value={displayedLogs.join("\n")}
                  readOnly
                  style={{
                    marginBottom: "20px",
                  }}
                  minRows={19}
                  maxRows={18}
                />
                <Textarea
                  /* label="User Log" */
                  autosize
                  value={userLog}
                  onChange={(event) => setUserLog(event.target.value)}
                  onKeyDown={(event) => handleSaveLog(event)}
                  minRows={1}
                  maxRows={1}
                />
              </Paper>
            </div>
          </SimpleGrid>
        </Container>
      </div>
    );
  }
}

export default CSViewIndividualTicket;
