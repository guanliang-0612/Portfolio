import CSViewIndividualTicket from "./CSViewIndividualTicket";
const CSViewIndividualTicketPage = () => {
  return (
    <div>
      <CSViewIndividualTicket />
      <br />
    </div>
  );
};

export default CSViewIndividualTicketPage;
