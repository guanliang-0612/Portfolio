// Import the CSAdminNavbar component
import CSAdminNavbarComponent from "./CSAdminNavbarComponent";
const CSAdminNavbar = () => {
  // Define your links data
  const linksData = [
    {
      link: "/AdminReportDashboardPage",
      label: "Report",
    },
    {
      link: "/AdminManageAccountPage",
      label: "Manage Account",
    },
    {
      label: "Hello, FirstName",
      links: [
        {
          link: "/CSAdminViewEditMyAccountPage",
          label: "My Account",
        },

        {
          link: "/Logout",
          label: "Logout",
        },
      ],
    },
  ];

  // Use the CSAdminNavbar component and pass the links data

  return <CSAdminNavbarComponent links={linksData} />;
};

export default CSAdminNavbar;
