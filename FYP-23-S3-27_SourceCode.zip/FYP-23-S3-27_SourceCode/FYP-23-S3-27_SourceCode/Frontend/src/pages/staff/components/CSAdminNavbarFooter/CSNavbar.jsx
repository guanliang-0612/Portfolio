// Import the CSAdminNavbar component
import CSAdminNavbarComponent from "./CSAdminNavbarComponent";
const CSNavbar = () => {
  // Define your links data
  const linksData = [
    {
      link: "/CSTicketDashboardPage",
      label: "Tickets",
    },
    {
      label: "Hello, FirstName",
      links: [
        {
          link: "/CSAdminViewEditMyAccountPage",
          label: "My Account",
        },

        {
          link: "/Logout",
          label: "Logout",
        },
      ],
    },
  ];

  // Use the CSAdminNavbar component and pass the links data

  return <CSAdminNavbarComponent links={linksData} />;
};

export default CSNavbar;
