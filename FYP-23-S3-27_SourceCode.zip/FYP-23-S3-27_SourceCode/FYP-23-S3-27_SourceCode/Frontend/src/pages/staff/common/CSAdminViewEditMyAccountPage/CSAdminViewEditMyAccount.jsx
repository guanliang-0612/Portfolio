/* 
 Usecase:
 A04
 A05
 CS04
 CS05
*/
import React, { useState } from "react";
import {
  TextInput,
  SimpleGrid,
  createStyles,
  Container,
  Text,
  Button,
  Group,
  rem,
  Paper,
  Modal,
  ActionIcon,
  ScrollArea,
  PasswordInput,
} from "@mantine/core";
import { useForm, isNotEmpty, hasLength, isEmail } from "@mantine/form";
import { IconEdit, IconArrowBackUp } from "@tabler/icons-react";
import { useAuth } from "../../../../contexts/AuthContext";
import { updateStaffDetails } from "../../../../services/authService";
import useAlerts from "../../../../hooks/useAlerts";

// Define the mock data directly in the file
// const mockData = {
//   accounttype: "Customer Service",
//   accountstatus: "Active",
//   dname: "John_Doe",
//   fname: "John",
//   lname: "Doe",
//   email: "John_Doe@gmail.com",
// };

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(660),
  },

  innerContainer: {
    display: "flex",
    justifyContent: "flex-end",
    width: "100%",
    height: "20%",
    backgroundColor: "rgba(0, 0, 0, 1)",
  },
  "manage-account-container": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "20px",
    backgroundColor: "black",
    color: "black",
    maxHeight: "50%",
  },

  paperStyle: {
    width: "100%", // or any specific width you want, e.g.
    padding: 0,
    // remove padding
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontSize: rem(62),
    fontWeight: 900,
    lineHeight: 1.1,
    margin: 0,
    padding: 0,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(42),
      lineHeight: 1.2,
    },
  },

  description: {
    marginTop: theme.spacing.xl,
    fontSize: rem(24),

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(18),
    },
  },

  flexContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  leftGrid: {
    flex: 1,
  },

  rightGrid: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },

  buttonGroup: {
    display: "flex",
    justifyContent: "space-between",
    width: "100%",
    marginTop: "10px",
  },

  blackHover: {
    "&:hover": {
      color: "black", // Set hover color to black
    },
  },
}));

export function CSAdminViewEditMyAccount(props) {
  const { classes } = useStyles();
  const [isEditing, setIsEditing] = useState(false); // New state variable to toggle between view and edit
  const [updateModalOpened, setUpdateModalOpened] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { currentUser } = useAuth();
  const { AlertDisplay, closeAlert, displayError, displaySuccess } =
    useAlerts();
  const form = useForm({
    initialValues: {
      id: currentUser.id,
      dname: currentUser.dname,
      fname: currentUser.fname,
      lname: currentUser.lname,
      email: currentUser.email,
      /*       imageUrl: currentUser.imageUrl ? currentUser.imageUrl : "", */
      newPassword: "",
      confirmPassword: "",
      currentPassword: "",
    },
    validate: {
      fname: hasLength({ min: 2 }, "Invalid first name"),
      lname: hasLength({ min: 2 }, "Invalid last name"),
      dname: isNotEmpty("Enter your display name"),
      email: isEmail("Invalid email"),
      newPassword: (val) =>
        val.length > 0 && val.length <= 7
          ? "Password should include more then 8 characters."
          : null,
      confirmPassword: (value) =>
        form.values.newPassword === value ? null : "Passwords do not match.",
    },
  });

  const handleSubmit = async (values) => {
    try {
      closeAlert();
      setIsSubmitting(true);
      const result = await updateStaffDetails(values);
      displaySuccess("Account updates saved.");
      setUpdateModalOpened(false);
    } catch (error) {
      switch (error.code) {
        case "auth/duplicate-display-name":
          form.setFieldError(
            "dname",
            "An account with this display name already exists"
          );
          form.setFieldValue("currentPassword", "");
          setUpdateModalOpened(false);
          break;
        case "auth/email-already-in-use":
          form.setFieldError(
            "email",
            "An account with this email already exists"
          );
          form.setFieldValue("currentPassword", "");
          break;
        case "auth/wrong-password":
          form.setFieldError(
            "currentPassword",
            "Your current password is incorrect."
          );
          break;
        default:
          displayError("Account update failed.");
          setUpdateModalOpened(false);
          form.setFieldValue("currentPassword", "");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={classes.wrapper}>
      <div className={classes["manage-account-container"]}>
        <Text
          fz="xl"
          style={{
            color: "white",
            margin: 0,
          }}
          weight={500}
        >
          Manage Account
        </Text>
      </div>

      <Container size={900}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <Text
            fz="xl"
            ta="left"
            style={{
              color: "black",
              marginTop: "20px",
            }}
            weight={500}
          >
            {isEditing ? "Edit My Account" : "My Account"}
          </Text>
          {isEditing ? (
            <>
              <ActionIcon
                style={{
                  marginTop: "20px",
                  marginLeft: "0",
                  marginRight: "auto",
                }}
                className={classes.blackHover}
                onClick={() => {
                  form.reset();
                  setIsEditing(false);
                }}
              >
                <IconArrowBackUp size={22} />
              </ActionIcon>
            </>
          ) : (
            <ActionIcon
              style={{ marginTop: "20px", marginLeft: "8px" }}
              className={classes.blackHover}
              onClick={() => setIsEditing(true)}
            >
              <IconEdit size={22} />
            </ActionIcon>
          )}
        </div>
        <Paper radius="md" withBorder={false}>
          <form
            onSubmit={form.onSubmit(() => {
              setUpdateModalOpened(true);
            })}
            style={{ width: "80%" }}
          >
            <AlertDisplay />
            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <TextInput
                label="Display Name"
                name="dname"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("dname")}
                required
              />
              <TextInput
                label="Email"
                name="email"
                disabled={!isEditing} // Editable when isEditing is true
                variant="filled"
                {...form.getInputProps("email")}
                required
                error={form.errors.email}
              />
            </SimpleGrid>
            <SimpleGrid
              cols={2}
              mt="xl"
              breakpoints={[{ maxWidth: "sm", cols: 1 }]}
            >
              <TextInput
                label="First Name"
                name="fname"
                disabled={!isEditing}
                variant="filled"
                {...form.getInputProps("fname")}
                required
              />
              <TextInput
                label="Last Name"
                name="lname"
                disabled={!isEditing}
                variant="filled"
                {...form.getInputProps("lname")}
                required
              />
            </SimpleGrid>
            {isEditing && (
              <>
                <SimpleGrid
                  cols={2}
                  mt="xl"
                  breakpoints={[{ maxWidth: "sm", cols: 1 }]}
                >
                  <PasswordInput
                    label="New Password"
                    name="password"
                    variant="filled"
                    {...form.getInputProps("newPassword")}
                  />
                  <PasswordInput
                    label="Confirm Password"
                    name="confirmPassword"
                    variant="filled"
                    {...form.getInputProps("confirmPassword")}
                    error={form.errors.confirmPassword} // Display the error message if validation fails
                  />
                </SimpleGrid>
                <Group position="left" mt="xl">
                  <Button
                    type="submit"
                    size="md"
                    style={{ backgroundColor: "black", color: "white" }}
                  >
                    Update
                  </Button>
                </Group>
              </>
            )}
            <Modal
              opened={updateModalOpened}
              onClose={() => {
                form.setFieldValue("currentPassword", "");
                setUpdateModalOpened(false);
              }}
              title="Save changes"
              size="md"
            >
              <form onSubmit={form.onSubmit(handleSubmit)}>
                {/*           <Space h="xl" /> */}
                <PasswordInput
                  label="Current Password"
                  description={
                    "Enter your current password to update your account."
                  }
                  {...form.getInputProps("currentPassword")}
                />
                <Group position="apart" style={{ marginTop: "20px" }}>
                  <Button
                    type="submit"
                    style={{ backgroundColor: "black", color: "white" }}
                    color="dark"
                    loading={isSubmitting}
                  >
                    Submit
                  </Button>
                  <Button
                    onClick={() => {
                      form.setFieldValue("currentPassword", "");
                      setUpdateModalOpened(false);
                    }}
                    /* style={{ backgroundColor: "black", color: "white" }} */
                    variant="default"
                    color="gray"
                  >
                    Cancel
                  </Button>
                </Group>
              </form>
            </Modal>
          </form>
        </Paper>
      </Container>
    </div>
  );
}

export default CSAdminViewEditMyAccount;
