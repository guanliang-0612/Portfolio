import CSAdminViewEditMyAccount from "./CSAdminViewEditMyAccount";
const CSAdminViewEditMyAccountPage = () => {
  return (
    <div>
      <CSAdminViewEditMyAccount />
      <br />
    </div>
  );
};

export default CSAdminViewEditMyAccountPage;
