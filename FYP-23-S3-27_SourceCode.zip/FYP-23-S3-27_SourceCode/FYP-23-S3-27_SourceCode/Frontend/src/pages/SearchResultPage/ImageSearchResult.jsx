/* 
 Usecase:
 B09
 B11
*/
import Banner from "./SearchResultBanner";
import ProductGrid from "./Listingcard";
import SortComponent from "./SortComponent";
import { ListingGrid } from "../../components/ListingGrid";
import {
  getClothingAttributes,
  searchListings,
  searchListingsByImage,
} from "../../services/listingService";
import { useSearchParams } from "react-router-dom";
import { useUploadedImage } from "../../contexts/UploadImageContext";
import { useEffect, useState, useCallback, useMemo } from "react";
import { Container, Text, Divider, LoadingOverlay, Flex } from "@mantine/core";

// Define a custom hook that takes an object of default values as an argument
const useDefaultParams = () => {
  // Get the current URL search params
  const [searchParams, setSearchParams] = useSearchParams();

  // Define a function that runs only once when the component mounts
  const setDefaultParams = () => {
    const defaultValues = {
      criteria: "",
      section: "All Section",
      category: "All Category",
      condition: "All Condition",
      colour: "All Colour",
      minPrice: 1,
      maxPrice: 600,
    };
    // Loop through the keys of the default values
    setSearchParams((prev) => {
      const prevParams = {};
      prev.forEach((value, key) => {
        prevParams[key] = value;
      });
      const defaultParams = {};
      for (const key of Object.keys(defaultValues)) {
        // If the current params do not have the key or the value associated with the key is invalid
        if (!prev.has(key) || !prevParams[key]) {
          // Set the params to include the key with the default value
          defaultParams[key] = defaultValues[key];
        }
      }
      return { ...prevParams, ...defaultParams };
    });
  };

  // Use an empty dependency array to run the function only once
  useEffect(setDefaultParams, [setSearchParams]);
};

const SearchResultPage = () => {
  const [listings, setListings] = useState([]);
  const [filteredlistings, setFilteredlistings] = useState([]); // Add a state for filtered listings
  const [isLoading, setIsLoading] = useState(true);
  // Use the custom hook to check and set the default values
  useDefaultParams();
  // Get the current URL search params
  const [searchParams, setSearchParams] = useSearchParams();
  const { uploadedImage } = useUploadedImage();
  // Get the values from the search params
  const criteria = searchParams.get("criteria");
  const selectedSection = searchParams.get("section");
  const selectedCategory = searchParams.get("category");
  const selectedCondition = searchParams.get("condition");
  const selectedColour = searchParams.get("colour");
  const minPrice = searchParams.get("minPrice");
  const maxPrice = searchParams.get("maxPrice");

  const setSearchParamsOnKeyValue = (key, value) => {
    setSearchParams((prev) => {
      const prevParams = {};
      prev.forEach((value, key) => {
        prevParams[key] = value;
      });
      return { ...prevParams, [key]: value };
    });
  };

  const setSelectedSection = (value) => {
    setSearchParamsOnKeyValue("section", value);
  };

  const setSelectedCategory = (value) => {
    setSearchParamsOnKeyValue("category", value);
  };

  const setSelectedCondition = (value) => {
    setSearchParamsOnKeyValue("condition", value);
  };

  const setSelectedColour = (value) => {
    setSearchParamsOnKeyValue("colour", value);
  };

  const setPriceRange = useCallback(
    (value) => {
      setSearchParams((prev) => {
        const prevParams = {};
        prev.forEach((value, key) => {
          prevParams[key] = value;
        });
        return { ...prevParams, minPrice: value[0], maxPrice: value[1] };
      });
    },
    [setSearchParams]
  );

  useEffect(() => {
    async function getData() {
      setIsLoading(true);
      if (!uploadedImage) {
        setListings([]);
        setIsLoading(false);
        return;
      }
      const [searchResults, attributes] = await Promise.all([
        searchListingsByImage(uploadedImage),
        getClothingAttributes(uploadedImage),
      ]);
      setSelectedCategory(attributes.category);
      setListings(searchResults);
      setIsLoading(false);
    }

    getData();
  }, [uploadedImage]);

  useEffect(() => {
    function filterListings(listings) {
      const filteredListings = listings.filter((listing) => {
        let matches = true;

        if (
          selectedSection !== "All Section" &&
          listing.section !== selectedSection
        ) {
          matches = false;
        }

        if (
          selectedCategory !== "All Category" &&
          listing.category !== selectedCategory
        ) {
          matches = false;
        }

        if (
          selectedCondition !== "All Condition" &&
          listing.condition !== selectedCondition
        ) {
          matches = false;
        }

        if (
          selectedColour !== "All Colour" &&
          listing.colour !== selectedColour
        ) {
          matches = false;
        }
        const price = listing.price || 0;
        if (price < minPrice || price > maxPrice) {
          matches = false;
        }
        return matches;
      });

      return filteredListings;
    }
    const filteredListings = filterListings(listings);
    setFilteredlistings(filteredListings);
  }, [
    listings,
    selectedSection,
    selectedCategory,
    selectedCondition,
    selectedColour,
    minPrice,
    maxPrice,
  ]);

  return (
    <div style={{ position: "relative" }}>
      <Banner section={selectedSection} />
      {criteria && (
        <Container>
          <Divider my="sm" style={{ marginTop: "16px" }} />
          <Text style={{ marginTop: "10px" }}>
            Your search result for: <strong>"{criteria}"</strong>
          </Text>
          <Divider style={{ marginTop: "10px" }} />
        </Container>
      )}
      {uploadedImage && (
        <Container style={{ textAlign: "left" }}>
          <Divider my="sm" style={{ marginTop: "16px" }} />
          <Text style={{ marginTop: "10px" }}>Your search result for:</Text>
          <img
            src={uploadedImage}
            alt="Uploaded"
            style={{ width: "100px", height: "150px", objectFit: "cover" }}
          />

          <Divider style={{ marginTop: "10px" }} />
        </Container>
      )}
      <div style={{ position: "relative" }}>
        <SortComponent
          section={selectedSection}
          colour={selectedColour}
          category={selectedCategory}
          condition={selectedCondition}
          onSectionChange={setSelectedSection}
          onCategoryChange={setSelectedCategory}
          onConditionChange={setSelectedCondition}
          onColourChange={setSelectedColour}
          onPriceChange={setPriceRange} // Passing a handler for price range changes
        />
        {
          <LoadingOverlay
            loaderProps={{ size: "xl", color: "dark", variant: "bars" }}
            overlayOpacity={1}
            visible={isLoading}
          />
        }
        {!isLoading &&
          (uploadedImage ? (
            <ListingGrid listings={filteredlistings} />
          ) : (
            <Flex justify="center">
              <Text size="lg" fw={500}>
                Upload an image to find a match!
              </Text>
            </Flex>
          ))}
      </div>
    </div>
  );
};

export default SearchResultPage;
