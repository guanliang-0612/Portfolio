import React, { useState, useEffect } from "react";
import {
  Select,
  createStyles,
  RangeSlider,
  rem,
  Text,
  Container,
  NumberInput,
} from "@mantine/core";
import { IconCircleFilled } from "@tabler/icons-react";
import { useSearchParams } from "react-router-dom";
import { IconCurrencyDollarSingapore } from "@tabler/icons-react";

const useStyles = createStyles((theme) => ({
  wrapper: {
    paddingTop: "16px",
  },
  mark: {
    display: "none",
  },
  markWrapper: {
    marginTop: rem(12),
  },
  thumb: {
    width: rem(16),
    height: rem(16),
    borderRadius: "50%",
    border: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },

  sliderContainer: {
    width: "200px",
    marginLeft: "16px",
    track: {
      backgroundColor: "black", // Change track color to black
    },
    filledTrack: {
      backgroundColor: "black", // Change active track color to black
    },
  },

  selectItem: {
    "&[data-selected]": {
      "&, &:hover": {
        backgroundColor:
          theme.colorScheme === "dark"
            ? theme.colors.dark[10]
            : theme.colors.dark[5],
        color:
          theme.colorScheme === "dark" ? theme.white : theme.colors.dark[20],
      },
    },
  },
  selectInput: {
    "&:focus-within": {
      borderColor: theme.colors.dark[7],
    },
  },
}));

const point = (
  <IconCircleFilled size={10} style={{ marginTop: rem(6) }} stroke={1.5} />
);

export function SliderMarks({
  onChange,
  value,
  setShowMaxError,
  setShowMinError,
}) {
  const { classes } = useStyles();
  const handleSliderChange = (newSliderValue) => {
    if (newSliderValue[0] < newSliderValue[1]) {
      setShowMaxError(false); // Clear the max error when slider value changes
      setShowMinError(false); // Clear the min error when slider value changes
    }
    onChange(newSliderValue); // Update the slider value
  };

  return (
    <RangeSlider
      color="dark"
      mt="xl"
      mb="xl"
      min={1}
      max={600}
      classNames={classes}
      value={value} // <-- Use the value prop
      onChange={handleSliderChange}
      thumbChildren={<IconCircleFilled size="1.2rem" stroke={1.5} />}
      marks={[
        { value: 1, label: "$1" },
        { value: 600, label: "$600" },
      ]}
    />
  );
}

function SortComponent({
  section,
  colour,
  category,
  condition,
  minPrice,
  maxPrice,
  onSectionChange,
  onCategoryChange,
  onConditionChange,
  onColourChange,
  onPriceChange,
}) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sliderValue, setSliderValue] = useState([1, 600]);
  /* const [category, setCategory] = useState("All Category"); // <-- Manage state for the category
  const [condition, setCondition] = useState("All Condition"); // <-- Manage state for the condition
  const [colour, setColour] = useState("All Colour"); // <-- Manage state for the colour
  const [selectedSection, setSelectedSection] = useState(section); */
  const { classes } = useStyles();
  const [showMaxError, setShowMaxError] = useState(false);
  const [showMinError, setShowMinError] = useState(false);

  /* useEffect(() => {
    setSelectedSection(section);
  }, [section]); */

  const handleMinPriceChange = (value) => {
    const minPrice = Number(value);
    if (minPrice <= sliderValue[1]) {
      setShowMinError(false);
      setSliderValue([minPrice, sliderValue[1]]);
    } else {
      setShowMinError(true);
    }
  };

  const handleMaxPriceChange = (value) => {
    const maxPrice = Number(value);
    if (maxPrice >= sliderValue[0]) {
      setShowMaxError(false);
      setSliderValue([sliderValue[0], maxPrice]);
    } else {
      setShowMaxError(true);
    }
  };

  const handleSectionChange = (value) => {
    /* setSelectedSection(value); // update local state */
    onSectionChange(value); // Notify parent component
  };

  const handleCategoryChange = (value) => {
    /* setCategory(value); // Update the category state */
    onCategoryChange(value); // Notify parent component
  };

  const handleConditionChange = (value) => {
    /* setCondition(value); // Update the condition state */
    onConditionChange(value); // Notify parent component
  };
  const handleColourChange = (value) => {
    /* setColour(value); // Update the colour state */
    onColourChange(value); // Notify parent component
  };

  useEffect(() => {
    onPriceChange(sliderValue); // Notify parent component whenever slider value changes
  }, [sliderValue, onPriceChange]);

  return (
    <div className={classes.wrapper}>
      <div
        style={{
          display: "flex",
          flexDirection: "column", // Change flex direction to column
          alignItems: "flex-start", // Align items to the start
          gap: "16px", // Add a gap between items
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "10px",
            alignItems: "center",
            width: "100%", // Take full width
          }}
        >
          <Select
            classNames={{
              item: classes.selectItem,
              input: classes.selectInput,
            }}
            style={{ flex: "1 0 auto" }}
            data={["All Section", "Women", "Men"]}
            label="Section"
            value={section} // Controlled by local state
            onChange={onSectionChange} // Handling section change
          />
          <Select
            classNames={{
              item: classes.selectItem,
              input: classes.selectInput,
            }}
            style={{ flex: "1 0 auto" }}
            data={[
              "All Category",
              { value: "topwear", label: "Tops" },
              { value: "bottomwear", label: "Bottoms" },
              { value: "footwear", label: "Footwear" },
              { value: "outerwear", label: "Outerwear" },
              { value: "dress", label: "Dresses" },
            ]}
            label="Category"
            value={category} // Controlled component
            onChange={onCategoryChange} // Handling change
          />
          <Select
            classNames={{
              item: classes.selectItem,
              input: classes.selectInput,
            }}
            style={{ flex: "1 0 auto" }}
            data={[
              "All Colour",
              { value: "beige", label: "Beige" },
              { value: "black", label: "Black" },
              { value: "blue", label: "Blue" },
              { value: "brown", label: "Brown" },
              { value: "gold", label: "Gold" },
              { value: "green", label: "Green" },
              { value: "grey", label: "Grey" },
              { value: "multicoloured", label: "Multi-coloured" },
              { value: "orange", label: "Orange" },
              { value: "pink", label: "Pink" },
              { value: "purple", label: "Purple" },
              { value: "red", label: "Red" },
              { value: "silver", label: "Silver" },
              { value: "turquoise", label: "Turquoise" },
              { value: "white", label: "White" },
              { value: "yellow", label: "Yellow" },
            ]}
            label="Colour"
            value={colour} // Controlled component
            onChange={onColourChange} // Handling change
          />
          <Select
            classNames={{
              item: classes.selectItem,
              input: classes.selectInput,
            }}
            style={{ flex: "1 0 auto" }}
            data={["All Condition", "Brand New", "Preloved", "Well Used"]}
            label="Condition"
            value={condition} // Controlled component
            onChange={onConditionChange} // Handling change
          />
        </div>

        <Container style={{ padding: "0px", margin: "0px" }}>
          <Text
            size="sm"
            weight={500}
            style={{
              marginBottom: "2px",
            }}
          >
            Price Range Selected
          </Text>

          <Container
            style={{
              display: "flex",
              alignItems: "center",
              padding: "0px",
              margin: "0px",
            }}
          >
            <NumberInput
              icon={<IconCurrencyDollarSingapore size="1rem" />}
              hideControls
              size="xs"
              type="number"
              min="1"
              max="600"
              value={sliderValue[0]}
              onChange={(value) => handleMinPriceChange(value)}
              style={{ width: "auto" }}
            />

            <NumberInput
              icon={<IconCurrencyDollarSingapore size="1rem" />}
              hideControls
              size="xs"
              type="number"
              min="1"
              max="600"
              value={sliderValue[1]}
              onChange={(value) => handleMaxPriceChange(value)}
              style={{ marginLeft: "10px", width: "auto" }}
            />

            {showMaxError && (
              <Text size="xs" style={{ marginLeft: "10px", color: "black" }}>
                Maximum range value must be higher
              </Text>
            )}

            {showMinError && (
              <Text size="xs" style={{ marginLeft: "10px", color: "black" }}>
                Minimum range value must be lower
              </Text>
            )}
          </Container>
          <Container style={{ width: "200px", padding: "0px", margin: "0px" }}>
            <SliderMarks
              setShowMaxError={setShowMaxError}
              setShowMinError={setShowMinError}
              onChange={setSliderValue}
              value={sliderValue}
            />
          </Container>
        </Container>
      </div>
    </div>
  );
}

export default SortComponent;
