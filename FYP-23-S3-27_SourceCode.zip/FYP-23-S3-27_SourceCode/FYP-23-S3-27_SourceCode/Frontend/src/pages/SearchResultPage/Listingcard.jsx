import { mockdata } from "../ListingPage/Listingmockdata";
import {
  createStyles,
  Card,
  Text,
  SimpleGrid,
  UnstyledButton,
  Group,
  rem,
  Image,
  Button,
} from "@mantine/core";
import { Link } from "react-router-dom";
import { Anchor } from "@mantine/core";
import { AiOutlineHeart } from "react-icons/ai";
/*
  const mockdata = [
    { title: 'Office Pants', image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80.jpg', price: 'S$25', condition: 'New' },
    { title: 'Green Dress', image: 'https://images.unsplash.com/flagged/photo-1585052201332-b8c0ce30972f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1935&q=80.jpg', price: 'S$35', condition: 'Used' },
    { title: 'Leather Jacket', image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1935&q=80', price: 'S$50', condition: 'New' },
    { title: 'Elegant Dress', image: 'https://images.unsplash.com/photo-1601653233006-5c9fd30eab12?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80.jpg', price: 'S$45', condition: 'New' },
    { title: 'Cool T-Shirt', image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80', price: 'S$25', condition: 'New' },
    { title: 'Stylish Pants', image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1994&q=80', price: 'S$35', condition: 'Used' },
    { title: 'Warm Jacket', image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1936&q=80', price: 'S$50', condition: 'New' },
    { title: 'Flower Dress', image: 'https://images.unsplash.com/photo-1542295669297-4d352b042bca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80', price: 'S$45', condition: 'New' },
];
  */
const useStyles = createStyles((theme) => ({
  link: {
    display: "block",
    textDecoration: "none",
    color: "inherit",
    "&:hover,": {
      textDecoration: "none",
      color: "inherit",
    },
  },

  imageContainer: {
    width: rem(230),
    height: rem(280), // Set a fixed height
    overflow: "hidden", // Ensure images don't spill out
    flexShrink: 0, // Prevents the container from shrinking
  },

  detailsContainer: {
    flexGrow: 0, // Prevent the container from growing
    flexShrink: 1, // Allow the container to shrink if necessary
    overflow: "hidden", // Prevent text or any other content from spilling out
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontWeight: 700,
  },

  item: {
    position: "relative",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start", // Align children to the top
    textAlign: "center",
    borderRadius: 0, // Adjusted for a more rectangular appearance
    overflow: "hidden", // Ensure images don't spill out
    border: "black", // Remove border
    height: rem(380), // Extended height
    padding: rem(10),
    width: rem(220), // Adjusted width
    margin: "0 0.010%", // Adjusted margin to reduce space between cards
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.white,
    transition: "box-shadow 150ms ease",
    "&:hover": {
      boxShadow: theme.shadows.md,
    },
  },

  likeButton: {
    position: "absolute",
    bottom: rem(10),
    right: rem(10),
    color: "black", // Set the color of the heart icon to black
    borderColor: "black", // Set the border color of the button to black
  },

  productImage: {
    width: rem(150), // Set a fixed width
    height: rem(300), // Set a fixed height for 1:2 proportion
    objectFit: "cover", // Cover the container without spilling out
    marginBottom: rem(10), // Add some margin at the bottom for spacing
    border: "black",
  },

  productDetails: {
    textAlign: "left", // Align details to the left
    width: rem(210), // Ensure the details take up the full width of the card
    paddingLeft: "10px",
    overflow: "hidden", // Hide any overflow
    whiteSpace: "nowrap", // Prevent wrapping to the next line
    textOverflow: "ellipsis", // Add ellipsis for overflow text
  },

  card: {
    backgroundColor: "transparent", // Remove gray background
    border: "none", // Remove border
  },
}));

export function ProductGrid() {
  const { classes, theme } = useStyles();

  const items = mockdata.map((product) => (
    <div key={product.id} className={classes.item}>
      <Anchor
        component={Link}
        to={`/listing/${product.id}`}
        className={classes.link} // Apply the link class
      >
        <div className={classes.imageContainer}>
          <Image
            src={product.image}
            alt={product.title}
            className={classes.productImage}
          />
        </div>
        <div className={classes.detailsContainer}>
          <div className={classes.productDetails}>
            <Text size="sm" mt={7}>
              {product.title}
            </Text>
            <Text size="sm" mt={7}>
              {product.price}
            </Text>
            <Text size="xs" mt={7}>
              {product.condition}
            </Text>
          </div>
          <Button
            className={classes.likeButton}
            variant="outline"
            size="xs"
            color="black" // Set the color of the button text to black
          >
            <AiOutlineHeart />
          </Button>
        </div>
      </Anchor>
    </div>
  ));

  return (
    <Card className={classes.card}>
      {" "}
      {/* Removed withBorder property */}
      <Group position="apart"></Group>
      <SimpleGrid
        breakpoints={[
          { minWidth: "sm", cols: 2 },
          { minWidth: "md", cols: 3 },
          { minWidth: 1200, cols: 4 },
        ]}
      >
        {items}
      </SimpleGrid>
    </Card>
  );
}

export default ProductGrid;
