import LoginSignUp from "./LoginSignUp";
const LoginSignUpPage = () => {
  return (
    <div>
      <LoginSignUp />
      <br />
    </div>
  );
};

export default LoginSignUpPage;
