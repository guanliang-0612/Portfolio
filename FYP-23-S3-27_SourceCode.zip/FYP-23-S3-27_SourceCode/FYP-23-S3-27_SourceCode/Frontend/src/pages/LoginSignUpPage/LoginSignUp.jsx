/* 
 Usecase:
 S01 
 S02
 S04
 B01 
 B02 
 B04
 A01 
 A03
 CS01 
 CS03
*/
import React, { useEffect, useState } from "react";
import {
  Paper,
  createStyles,
  TextInput,
  PasswordInput,
  Checkbox,
  Button,
  Title,
  Text,
  Anchor,
  rem,
  Card,
  Select,
  Alert,
} from "@mantine/core";
import { DatePickerInput } from "@mantine/dates";
import { useAuth } from "../../contexts/AuthContext";
import { Form, useForm, isEmail, isNotEmpty } from "@mantine/form";
import { useLocation, useNavigate } from "react-router-dom";
import { login, signup, sendPwResetEmail } from "../../services/authService";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import {
  IconExclamationCircle,
  IconAlertCircle,
  IconCalendar,
} from "@tabler/icons-react";

const useStyles = createStyles((theme) => ({
  wrapper: {
    display: "flex",
    minHeight: rem(900),

    [theme.fn.smallerThan("md")]: {
      // Assuming "md" is 768px
      flexDirection: "column",
    },
  },

  formContainer: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start", // Change this line
  },

  formBase: {
    width: rem(450),
    margin: "0 auto",
    paddingTop: rem(80),
    paddingBottom: rem(80),

    [theme.fn.smallerThan("sm")]: {
      width: "100%",
    },
  },

  form: {
    borderRight: `${rem(1)} solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.colors.gray[3]
    }`,
  },

  signupForm: {
    borderRight: `${rem(1)} solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.colors.gray[3]
    }`,
    maxWidth: rem(450),
    margin: "0 auto",
    paddingTop: rem(80),

    [theme.fn.smallerThan("sm")]: {
      maxWidth: "100%",
    },
  },

  imageContainer: {
    flex: 1,
    backgroundImage:
      "url(https://images.unsplash.com/photo-1529139574466-a303027c1d8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80)",
    backgroundSize: "cover",
    backgroundPosition: "center",

    [theme.fn.smallerThan("md")]: {
      display: "none",
    },
  },

  title: {
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
  },

  blackButton: {
    backgroundColor: "black",
    color: "white",
    "&:hover": {
      backgroundColor: "#333", // Slightly lighter black for hover effect
    },
  },

  errorMessage: {
    color: "red",
    margin: "0px",
  },
  errorCard: {
    borderColor: "red",
    borderWidth: "1px",
    borderStyle: "solid",
    backgroundColor: "rgba(255, 0, 0, 0.1)", // red background with low opacity
    display: "flex",
    marginBottom: "10px",
  },
}));

export function LoginSignUp() {
  const { classes } = useStyles();
  const [showSignUpFirst, setShowSignUpFirst] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  function SignUpForm() {
    const navigate = useNavigate();
    const [signUpError, setSignUpError] = useState("");
    const [formIsLoading, setFormIsLoading] = useState(false);
    const form = useForm({
      initialValues: {
        fname: "",
        lname: "",
        dname: "",
        gender: "",
        birthday: null,
        email: "",
        password: "",
        confirmPassword: "",
        role: "customer",
      },
      validate: {
        fname: isNotEmpty("First name is empty."),
        lname: isNotEmpty("Last name is empty."),
        dname: isNotEmpty("Display name is empty."),
        birthday: isNotEmpty("Birthday is empty."),
        gender: isNotEmpty("Gender is empty."),
        email: isEmail("Invalid email"),
        password: (val) =>
          val.length <= 7
            ? "Password should include more then 8 characters."
            : null,
        confirmPassword: (value) =>
          form.values.password === value ? null : "Passwords do not match.",
      },
    });

    async function handleSubmit({
      fname = "",
      lname = "",
      dname = "",
      gender = "",
      birthday = new Date(),
      email = "",
      password = "",
    }) {
      try {
        setFormIsLoading(true);
        setSignUpError("");
        const signupResult = await signup({
          fname,
          lname,
          dname,
          birthday,
          gender,
          email,
          password,
        });
        navigate("/");
      } catch (error) {
        let customErrorMessage;
        switch (error.code) {
          case "auth/email-already-in-use":
            customErrorMessage = "An account with this email already exists.";
            break;
          default:
            customErrorMessage = error.message;
            break;
        }
        setSignUpError(customErrorMessage); // Set the custom error message if login fails
      } finally {
        setFormIsLoading(false);
      }
    }

    return (
      <Paper
        className={`${classes.formBase} ${classes.form}`}
        radius={0}
        p={30}
      >
        <Title order={2} className={classes.title} ta="center" mt="md" mb={20}>
          Your Journey Starts Here
        </Title>
        {signUpError && (
          <Alert
            icon={<IconAlertCircle size="1rem" />}
            title={"Bummer!"}
            color={"red"}
            style={{ marginBottom: "20px" }}
            withCloseButton
            closeButtonLabel="Close alert"
            onClose={() => {
              setSignUpError("");
            }}
          >
            {signUpError}
          </Alert>
        )}
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <TextInput
            label="First Name"
            placeholder="John"
            size="md"
            withAsterisk
            {...form.getInputProps("fname")}
          />
          <TextInput
            label="Last Name"
            placeholder="Doe"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("lname")}
          />
          <TextInput
            label="Display Name"
            placeholder="JohnD"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("dname")}
          />{" "}
          <Select
            label="Gender"
            placeholder="Gender"
            mt="md"
            size="md"
            data={[
              { value: "male", label: "Male" },
              { value: "female", label: "Female" },
            ]}
            withAsterisk
            {...form.getInputProps("gender")}
          />
          <DatePickerInput
            label="Birthday"
            placeholder="Pick a date"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("birthday")}
          />
          <TextInput
            label="Email address"
            placeholder="hello@gmail.com"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("email")}
          />
          <PasswordInput
            label="Password"
            placeholder="Your password"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("password")}
          />
          <PasswordInput
            label="Confirm Password"
            placeholder="Confirm your password"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("confirmPassword")}
          />
          <Button
            fullWidth
            mt="xl"
            size="md"
            type="submit"
            className={classes.blackButton}
            loading={formIsLoading}
          >
            Sign Up
          </Button>
        </form>
        <Text ta="center" mt="md">
          Have an account?{" "}
          <Anchor
            href="#"
            weight={700}
            onClick={(event) => {
              event.preventDefault();
              setShowSignUpFirst(false);
            }}
          >
            Login
          </Anchor>
        </Text>
      </Paper>
    );
  }

  function LoginForm() {
    const navigate = useNavigate();
    const location = useLocation();
    const [loginError, setLoginError] = useState(""); // State to manage login error
    const [formIsLoading, setFormIsLoading] = useState(false);
    async function handleSubmit(values) {
      try {
        setFormIsLoading(true);
        setLoginError("");
        await login(values.email, values.password);
        // Navigate to the landing page if login is successful
        navigate("/");
      } catch (error) {
        let customErrorMessage;
        switch (error.code) {
          case "auth/user-not-found":
          case "auth/wrong-password":
            customErrorMessage = "Invalid Email or Password!";
            break;
          default:
            customErrorMessage = error.message;
            break;
        }
        setLoginError(customErrorMessage); // Set the custom error message if login fails
      } finally {
        setFormIsLoading(false);
      }
    }
    const form = useForm({
      initialValues: {
        email: "",
        password: "",
      },
      validate: {
        email: isEmail("Invalid email"),
        password: isNotEmpty("Password must not be empty"),
      },
    });

    return (
      <Paper
        className={`${classes.formBase} ${classes.form}`}
        radius={0}
        p={30}
      >
        {" "}
        <Title order={2} className={classes.title} ta="center" mt="md" mb={20}>
          Welcome Back To TC FASHION!
        </Title>
        <form onSubmit={form.onSubmit(handleSubmit)}>
          {/* Displaying error message when login fails */}

          {loginError && (
            <Alert
              icon={<IconAlertCircle size="1rem" />}
              title={"Bummer!"}
              color={"red"}
              style={{ marginBottom: "20px" }}
              withCloseButton
              closeButtonLabel="Close alert"
              onClose={() => {
                setLoginError("");
              }}
            >
              {loginError}
            </Alert>
          )}
          <TextInput
            label="Email address"
            placeholder="hello@gmail.com"
            size="md"
            withAsterisk
            {...form.getInputProps("email")}
          />
          <PasswordInput
            label="Password"
            placeholder="Your password"
            mt="md"
            size="md"
            withAsterisk
            {...form.getInputProps("password")}
          />
          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
            }}
          >
            {/* <Checkbox label="Keep me logged in" mt="xl" size="md" /> */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginTop: rem(25),
              }}
            >
              <Anchor
                href="#"
                weight={500}
                onClick={(event) => {
                  event.preventDefault();
                  setShowForgotPassword(true);
                }}
              >
                Forgot password?
              </Anchor>
            </div>
          </div>
          <Button
            fullWidth
            mt="xl"
            size="md"
            type="submit"
            className={classes.blackButton}
            loading={formIsLoading}
          >
            Login
          </Button>
          <Text ta="center" mt="md">
            Don&apos;t have an account?{" "}
            <Anchor
              href="#"
              weight={700}
              onClick={(event) => {
                event.preventDefault();
                setShowSignUpFirst(true);
              }}
            >
              Register
            </Anchor>
          </Text>
        </form>
      </Paper>
    );
  }

  const ForgotPasswordForm = () => {
    const form = useForm({
      initialValues: {
        email: "",
      },
      validate: {
        email: isEmail("Invalid email"),
      },
    });
    const [alert, setAlert] = useState({ type: "", message: "" });
    const [formIsLoading, setFormIsLoading] = useState(false);
    async function handleSubmit(values) {
      try {
        setFormIsLoading(true);
        setAlert({ type: "", message: "" });
        await sendPwResetEmail(values.email);
        setAlert({
          message: "The password reset link has been sent. Check your inbox.",
          type: "success",
        });
      } catch (error) {
        setAlert({
          message: "User does not exist at the requested email.",
          type: "failure",
        });
      } finally {
        setFormIsLoading(false);
      }
    }
    return (
      <Paper
        className={`${classes.formBase} ${classes.form}`}
        radius={0}
        p={30}
      >
        <Title order={2} className={classes.title} ta="center" mt="md" mb={20}>
          Forgot Your Password?
        </Title>{" "}
        {alert.type !== "" && (
          <Alert
            icon={<IconAlertCircle size="1rem" />}
            title={alert.type === "success" ? "Success!" : "Bummer!"}
            color={alert.type === "success" ? "green" : "red"}
            style={{ marginBottom: "20px" }}
            withCloseButton
            closeButtonLabel="Close alert"
            onClose={() => {
              setAlert({ type: "", message: "" });
            }}
          >
            {alert.message}
          </Alert>
        )}
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <TextInput
            label="Email"
            placeholder="hello@gmail.com"
            size="md"
            withAsterisk
            {...form.getInputProps("email")}
          />

          <Button
            fullWidth
            mt="xl"
            size="md"
            className={classes.blackButton}
            type="submit"
            loading={formIsLoading}
          >
            Send Reset Instructions
          </Button>
        </form>
        <Text ta="center" mt="md">
          Have an account?{" "}
          <Anchor
            weight={700}
            onClick={(event) => {
              event.preventDefault();
              setShowForgotPassword(false);
            }}
          >
            Sign in
          </Anchor>
        </Text>
      </Paper>
    );
  };

  return (
    <div className={classes.wrapper}>
      <div className={classes.formContainer}>
        {showForgotPassword ? (
          <ForgotPasswordForm />
        ) : showSignUpFirst ? (
          <SignUpForm />
        ) : (
          <LoginForm />
        )}
      </div>
      <div className={classes.imageContainer}></div>
    </div>
  );
}
export default LoginSignUp;
