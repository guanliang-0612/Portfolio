import ViewIndividualAcc from "./ViewIndividualAcc";
const ViewIndividualAccPage = () => {
  return (
    <div>
      <ViewIndividualAcc />
      <br />
    </div>
  );
};

export default ViewIndividualAccPage;
