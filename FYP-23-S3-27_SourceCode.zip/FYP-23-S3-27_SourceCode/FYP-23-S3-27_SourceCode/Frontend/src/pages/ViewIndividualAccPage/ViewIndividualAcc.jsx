/* 
 Usecase:
 S05
 B05
*/
import React from "react";
import { Link } from "react-router-dom";
import {
  createStyles,
  Container,
  Text,
  Button,
  Group,
  rem,
  Avatar,
  Paper,
} from "@mantine/core";

// Define the mock data directly in the file
const mockData = {
  avatar:
    "https://images.unsplash.com/photo-1487309078313-fad80c3ec1e5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1935&q=80",
  email: "John_Doe@gmail.com",
  username: "John_Doe",
  fname: "John",
  lname: "Doe",
};

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,
    overflow: "hidden",
    height: rem(600),
  },

  bottomRightImage: {
    position: "absolute",
    bottom: 0,
    right: 0,
    //  set a width or height if you want to resize the image
    width: "300px",
    height: "300px",
    opacity: 0.2, // opacity
  },

  innerContainer: {
    width: "100%", // This ensures it takes the full width of the wrapper
    height: "8%", // Set the height to be 10% of the wrapper
    backgroundColor: "rgba(0, 0, 0, 1)",
  },

  inner: {
    position: "relative",
    paddingTop: rem(10),
    marginLeft: rem(-8),
    paddingBottom: rem(120),

    [theme.fn.smallerThan("sm")]: {
      paddingBottom: rem(80),
      paddingTop: rem(80),
    },
  },

  paperStyle: {
    width: "60%", // or any specific width you want, e.g., '500px'
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontSize: rem(62),
    fontWeight: 900,
    lineHeight: 1.1,
    margin: 0,
    padding: 0,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(42),
      lineHeight: 1.2,
    },
  },

  description: {
    marginTop: theme.spacing.xl,
    fontSize: rem(24),

    [theme.fn.smallerThan("sm")]: {
      fontSize: rem(18),
    },
  },

  controls: {
    marginTop: `calc(${theme.spacing.xl} * 2)`,

    [theme.fn.smallerThan("sm")]: {
      marginTop: theme.spacing.xl,
    },
  },

  control: {
    height: rem(54),
    paddingLeft: rem(38),
    paddingRight: rem(38),

    [theme.fn.smallerThan("sm")]: {
      height: rem(54),
      paddingLeft: rem(18),
      paddingRight: rem(18),
      flex: 1,
    },
  },

  flexContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  leftGrid: {
    flex: 1,
  },

  rightGrid: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
}));

export function ViewIndividualAcc() {
  const { classes } = useStyles();

  return (
    <div className={classes.wrapper}>
      <div className={classes.innerContainer}>
        <Text
          ta="left"
          fz="xl"
          style={{
            marginTop: "0",
            padding: "10px",
            paddingLeft: "30px",
            color: "white",
          }}
          weight={500}
          mt="lg"
        >
          View Account
        </Text>
      </div>
      <Container size={700} className={classes.inner}>
        <Paper
          radius="md"
          withBorder={false}
          p="lg"
          style={{ maxWidth: "25rem" }}
          sx={(theme) => ({
            backgroundColor:
              theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
          })}
        >
          <div className={classes.flexContainer}>
            <div className={classes.leftGrid}>
              <Text ta="left" fz="lg" weight={500} mb="lg">
                <Text weight={700} component="span">
                  Username:
                </Text>{" "}
                {mockData.username}
              </Text>
              <Text ta="left" c="dimmed" fz="md" mb="lg">
                <Text weight={700} component="span">
                  First Name:
                </Text>{" "}
                {mockData.fname}
              </Text>
              <Text ta="left" c="dimmed" fz="md" mb="lg">
                <Text weight={700} component="span">
                  Last Name:
                </Text>{" "}
                {mockData.lname}
              </Text>
              <Text ta="left" c="dimmed" fz="md">
                <Text weight={700} component="span">
                  Email:
                </Text>{" "}
                {mockData.email}
              </Text>
            </div>

            <div className={classes.rightGrid}>
              <Avatar src={mockData.avatar} size={110} radius={120} />
              <Link to="/AccountPage">
                <Button
                  variant="default"
                  style={{ width: "120px", marginTop: "12px" }}
                >
                  My Account
                </Button>
              </Link>
            </div>
          </div>
        </Paper>
      </Container>
      <img
        src="https://img.freepik.com/free-vector/hand-drawn-monstera-leaf-outline-illustration_23-2150437552.jpg?w=826&t=st=1695134308~exp=1695134908~hmac=74776a4fa2441cb17caf364964cd5e1bcab268c056043d0886f7d00c514ddab9"
        alt="Description of Image"
        className={classes.bottomRightImage}
      />
    </div>
  );
}

export default ViewIndividualAcc;
