import Banner from "./AboutUsBanner";
import AboutUsSection from "./AboutUsSection";
const AboutUsPage = () => {
  return (
    <div>
      <Banner />
      <AboutUsSection />
    </div>
  );
};

export default AboutUsPage;
