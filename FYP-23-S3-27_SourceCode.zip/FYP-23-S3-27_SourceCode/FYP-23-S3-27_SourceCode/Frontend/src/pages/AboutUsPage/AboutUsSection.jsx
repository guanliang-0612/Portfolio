import {
    createStyles,
    Text,
    Title,
    SimpleGrid,
    Button,
    Image,
    Collapse,
    Paper,
} from '@mantine/core';
import { useState } from 'react';
import { IconChevronUp,IconChevronDown } from '@tabler/icons-react';
const useStyles = createStyles((theme) => ({
    wrapper: {
      minHeight: 400,
      boxSizing: 'border-box',
      borderRadius: theme.radius.md,
      padding: '50px',
    },

    title: {
      fontFamily: `Greycliff CF, ${theme.fontFamily}`,
      color: theme.black,
      lineHeight: 1,
      fontSize: "25px",
      marginBottom: theme.spacing.md,
    },

    description: {
      color: theme.black,
      marginBottom: theme.spacing.lg,

      [theme.fn.smallerThan('sm')]: {
        maxWidth: '100%',
      },
    },

    image: {
        borderRadius: theme.radius.sm,
        boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
        maxWidth: '100%',
        marginBottom: theme.spacing.md,
      },

}));

export function AboutUsSection() {
    const { classes } = useStyles();
    const [isPurposeOpen, setPurposeOpen] = useState(false);
    const [isObjectiveOpen, setObjectiveOpen] = useState(false);

    return (
      <div className={classes.wrapper}>
        <SimpleGrid cols={2} gutter={40} breakpoints={[{ maxWidth: 'sm', cols: 1 }]}>
          <div>
            <Paper padding="sm" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }} onClick={() => setPurposeOpen(!isPurposeOpen)}>
              <Title className={classes.title}>Purpose</Title>
              {isPurposeOpen ? <IconChevronUp /> : <IconChevronDown />}
            </Paper>
            <Text className={classes.description}>
              At TC Fashion, our passion extends beyond mere commerce.
              We envision a future where fashion is not just about the new but also about valuing the old, where every item gets a second chance.
              {/* Short summary of the purpose */}
            </Text>
            <Collapse in={isPurposeOpen}>
            Our commitment is to reduce waste and make sustainable fashion a norm, ensuring it's accessible to all. Each pre-owned item that finds a new home through our platform is not just a sale; it's a testament to a more sustainable and responsible future.
              {/* Rest of the purpose content */}
            </Collapse>
          </div>
          <div>
            <Image src="https://images.unsplash.com/photo-1483058712412-4245e9b90334?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" alt="Purpose Image" className={classes.image} />
          </div>
          <div>
            <Paper padding="sm" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }} onClick={() => setObjectiveOpen(!isObjectiveOpen)}>
              <Title className={classes.title}>Objective</Title>
              {isObjectiveOpen ? <IconChevronUp /> : <IconChevronDown />}
            </Paper>
            <Text className={classes.description}>
              To bring our purpose to life, our objective is clear:
              Craft a seamless and sustainable eCommerce marketplace. We're not just relying on traditional methods; we're harnessing the power of machine learning and computer vision. 
              {/* Short summary of the objective */}
            </Text>
            <Collapse in={isObjectiveOpen}>
              This allows us to revolutionize the user experience. By simply uploading an image, our users can list items for sale, with the added advantage of automated product tagging and prefilled descriptions, be it "Top," "Bottom," or "Footwear." But we don't stop there. Our platform also offers personalized style recommendations, all powered by advanced machine learning algorithms.
              {/* Rest of the objective content */}
            </Collapse>
          </div>
          <div>
            <Image src="https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80" alt="Objective Image" className={classes.image} />
          </div>
        </SimpleGrid>
        <a href="https://fyp23s327.wixsite.com/top-care-fashion" target="_blank" rel="noopener noreferrer">
          <Button variant="default" style={{ marginTop: '20px' }}>Visit Project Site</Button>
        </a>
      </div>
    );
}

export default AboutUsSection;