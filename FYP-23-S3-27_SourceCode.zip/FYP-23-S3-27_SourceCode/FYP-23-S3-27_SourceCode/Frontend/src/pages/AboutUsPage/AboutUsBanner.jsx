import { createStyles, Text, Title, rem } from '@mantine/core';

const useStyles = createStyles((theme) => ({
  wrapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'start',
    padding: `calc(${theme.spacing.xl} * 2)`,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colorScheme === 'dark' ? theme.colors.dark[8] : theme.white,
    border: `${rem(1)} solid ${
      theme.colorScheme === 'dark' ? theme.colors.dark[8] : theme.colors.gray[3]
    }`,
    backgroundImage: `
      linear-gradient(rgba(255, 255, 255, 0.7), rgba(255, 255, 255, 0.9)),
      url(https://images.unsplash.com/photo-1490481651871-ab68de25d43d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80)
    `,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',

    [theme.fn.smallerThan('sm')]: {
      flexDirection: 'column-reverse',
      padding: theme.spacing.xl,
    },
  },

  body: {
    paddingRight: `calc(${theme.spacing.xl} * 4)`,

    [theme.fn.smallerThan('sm')]: {
      paddingRight: 0,
      marginTop: theme.spacing.xl,
    },
  },

  title: {
    textAlign: 'Left',
    color: theme.colorScheme === 'dark' ? theme.white : theme.black,
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    lineHeight: 1,
    marginBottom: theme.spacing.md,
  },

  quote: {
    fontStyle: 'italic',
    color: theme.colors.gray[9],  // Darker color for better contrast
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.lg,
    borderLeft: `${rem(4)} solid ${theme.colors.green[6]}`,
    paddingLeft: theme.spacing.md,
    textShadow: '1px 1px 2px rgba(0, 0, 0, 0.1)',  // Subtle shadow for depth
    fontWeight: 500,  // Slightly bolder font
},

}));

export function Banner() {
  const { classes } = useStyles();
  return (
    <div className={classes.wrapper}>
      <div className={classes.body}>
        <Title className={classes.title}>About Us</Title>
        <Text fw={480} fz="lg" mb={5}>
          Get To Know Us.
          <br />
        </Text>
        <Text className={classes.quote}>
          "Sustainability is not just a choice; it's our responsibility to future generations."
        </Text>
      </div>
    </div>
  );
}

export default Banner;
