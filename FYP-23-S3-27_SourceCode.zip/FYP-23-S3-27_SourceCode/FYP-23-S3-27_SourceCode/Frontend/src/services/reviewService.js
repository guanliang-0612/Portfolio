import httpClient from "../utils/httpClient";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  query,
  getDoc,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../libs/firebase";
import { updateDoc, setDoc, addDoc } from "firebase/firestore";

const reviewsRef = collection(db, "reviews");

// UC:S16
export async function getReviews(userID) {
  try {
    const q = query(reviewsRef, where("userId", "==", userID));
    const userRef = collection(db, "accountDetails");
    const querySnapshot = await getDocs(q);
    const results = [];
    const finalReviews = [];
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...

      results.push({
        id: doc.id,
        ...doc.data(),
        timestamp: doc.data().timestamp.toDate(),
      });
    });

    return results;
  } catch (error) {
    return null;
  }
}

// UC:S28 //UC:B25
export async function addReview(
  review = {
    listingId: "",
    listingName: "",
    rating: "",
    review: "",
    reviewerImage: "",
    reviewerName: "",
    dname: "",
    reviewerType: "",
    listingImage: "",
    userId: "",
  }
) {
  try {
    const dateTimeNow = new Date();
    const data = {
      listingId: review.listingId,
      listingName: review.listingName,
      rating: review.rating,
      review: review.review,
      reviewerImage: review.reviewerImage ? review.reviewerImage : "",
      reviewerName: review.reviewerName,
      dname: review.dname,
      reviewerType: review.reviewerType,
      listingImage: review.listingImage,
      userId: review.userId,
      timestamp: new Date(),
    };
    await addDoc(reviewsRef, data);
    return true;
  } catch (error) {
    return null;
  }
}

// UC:S29 //UC:B26
export async function getAllBuyerReviews(sellerID) {
  try {
    const q = query(
      reviewsRef,
      where("userId", "==", sellerID),
      where("reviewerType", "==", "buyer")
    );
    const querySnapshot = await getDocs(q);
    const results = [];
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      results.push({ id: doc.id, ...doc.data() });
    });
    return results;
  } catch (error) {
    return null;
  }
}
export async function calculateUserRating(user_id) {
  try {
    const q = query(reviewsRef, where("userId", "==", user_id));
    const querySnapshot = await getDocs(q);
    const results = [];
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      results.push({ id: doc.id, ...doc.data() });
    });
    let average = 2;
    if (results.length == 1) {
      average = results[0].rating;
    } else if (results.length == 0) {
      average = 0;
    } else {
      average = results.reduce((a, b) => a + b.rating, 0) / results.length;
    }
    return average;
  } catch (error) {
    return 6;
  }
}
