import httpClient from "../utils/httpClient";
import { auth, db, storage, functions } from "../libs/firebase";
import {
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  createUserWithEmailAndPassword,
  updateEmail,
  updateProfile,
  updatePassword,
  EmailAuthProvider,
  reauthenticateWithCredential,
  deleteUser,
} from "firebase/auth";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  query,
  getDoc,
  addDoc,
  setDoc,
  updateDoc,
  documentId,
} from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

export async function login(email, password) {
  try {
    const response = await signInWithEmailAndPassword(auth, email, password);
    return response;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

async function checkForDuplicateDisplayNames(displayName = "", id = "") {
  try {
    const accountsRef = collection(db, "accountDetails");
    let q;
    // Query Firestore to check if any document has the same display name
    if (id)
      q = query(
        accountsRef,
        where("dname", "==", displayName),
        where(documentId(), "!=", id)
      );
    else q = query(accountsRef, where("dname", "==", displayName));
    const querySnapshot = await getDocs(q);

    // If there are any documents with the same display name, return true (duplicate found)
    return !querySnapshot.empty;
  } catch (error) {
    console.error("Error checking for duplicate display names:", error);
    throw error;
  }
}
// TODO
export async function signup({
  fname,
  lname,
  dname,
  birthday,
  gender,
  email,
  password,
}) {
  const duplicateExists = await checkForDuplicateDisplayNames(dname);
  if (duplicateExists) {
    const error = new Error(
      "An account with this display name already exists."
    );
    error.code = "auth/duplicate-display-name";
    throw error;
  }
  const result = await createUserWithEmailAndPassword(auth, email, password);
  /* et signupFormData = new FormData();
    signupFormData.append("email", email);
    signupFormData.append("password", password);
    signupFormData.append("fname", fname);
    signupFormData.append("lname", lname);
    signupFormData.append("display_name", dname);
    signupFormData.append("role", "customer");
    const response = await httpClient.post("/user/new", signupFormData); */

  const docRef = await setDoc(doc(db, "accountDetails", result.user.uid), {
    fname,
    lname,
    dname,
    email,
    birthday,
    gender,
    role: "customer",
    status: "active",
  });

  return result.user.uid;
}

export async function getUserDetails(uid) {
  const docRef = doc(db, "accountDetails", uid);
  const docSnap = await getDoc(docRef);

  const docData = docSnap.data();

  const { birthday, ...userDetails } = docData;

  return {
    id: docSnap.id,
    ...userDetails,
    birthday: birthday?.toDate(),
  };
}

// Returns void
export async function signout() {
  await signOut(auth);
}

/*  const login = (email, password) => {
    return auth.signInWithEmailAndPassword(email, password);
  };

  const logout = () => {
    return auth.signOut();
  }; */

export async function deleteAccount(userProvidedPassword) {
  try {
    const credential = EmailAuthProvider.credential(
      auth.currentUser.email,
      userProvidedPassword
    );
    const result = await reauthenticateWithCredential(
      auth.currentUser,
      credential
    );
    await deleteUser(auth.currentUser);
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function sendPwResetEmail(email) {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:A
export async function updateUserDetails({
  id,
  fname,
  lname,
  dname,
  email,
  birthday,
  gender,
  newPassword,
  currentPassword,
  imageUrl,
  newImage = null,
}) {
  try {
    const duplicateExists = await checkForDuplicateDisplayNames(dname, id);
    if (duplicateExists) {
      const error = new Error(
        "An account with this display name already exists."
      );
      error.code = "auth/duplicate-display-name";
      throw error;
    }
    const credential = EmailAuthProvider.credential(
      auth.currentUser.email,
      currentPassword
    );

    const result = await reauthenticateWithCredential(
      auth.currentUser,
      credential
    );
    if (email !== auth.currentUser.email)
      await updateEmail(auth.currentUser, email);
    if (newPassword) await updatePassword(auth.currentUser, newPassword);
    let newImageUrl = "";
    if (newImage?.name) {
      const randomId = doc(collection(db, "temp")).id;
      // Solution to get file ext from name https://stackoverflow.com/questions/680929/how-to-extract-extension-from-filename-string-in-javascript
      let regex = /(?:\.([^.]+))?$/;
      const fileExt = regex.exec(newImage.name)[1];
      const storageRef = ref(storage, `images/${randomId}.${fileExt}`);

      const fileSnapshot = await uploadBytes(storageRef, newImage);

      newImageUrl = await getDownloadURL(fileSnapshot.ref);
    }
    const docRef = await updateDoc(doc(db, "accountDetails", id), {
      fname,
      lname,
      dname,
      imageUrl: newImageUrl || imageUrl,
      birthday,
      gender,
      email,
    });
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function updateStaffDetails({
  id,
  fname,
  lname,
  dname,
  email,
  newPassword,
  currentPassword,
}) {
  try {
    const duplicateExists = await checkForDuplicateDisplayNames(dname, id);
    if (duplicateExists) {
      const error = new Error(
        "An account with this display name already exists."
      );
      error.code = "auth/duplicate-display-name";
      throw error;
    }
    const credential = EmailAuthProvider.credential(
      auth.currentUser.email,
      currentPassword
    );

    const result = await reauthenticateWithCredential(
      auth.currentUser,
      credential
    );
    if (email !== auth.currentUser.email)
      await updateEmail(auth.currentUser, email);
    if (newPassword) await updatePassword(auth.currentUser, newPassword);

    const docRef = await updateDoc(doc(db, "accountDetails", id), {
      fname,
      lname,
      dname,
      email,
    });
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function adminUpdateUserDetails({
  id,
  fname,
  lname,
  dname,
  email,
  birthday,
  gender,
  role,
  status,
  newImage = null,
}) {
  try {
    const duplicateExists = await checkForDuplicateDisplayNames(dname, id);
    if (duplicateExists) {
      const error = new Error(
        "An account with this display name already exists."
      );
      error.code = "auth/duplicate-display-name";
      throw error;
    }
    let newImageUrl = "";
    if (newImage?.name) {
      const storageRef = ref(storage, `images/${newImage.name}`);
      const fileSnapshot = await uploadBytes(storageRef, newImage);

      newImageUrl = await getDownloadURL(fileSnapshot.ref);
    }
    const updateUserDetails = httpsCallable(functions, "adminEditUser");
    const results = await updateUserDetails({
      userId: id,
      detailsToUpdate: {
        fname,
        lname,
        dname,
        role,
        email,
        birthday,
        gender,
        status,
      },
    });
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function createStaffAccount({
  fname,
  lname,
  dname,
  email,
  password,
  role,
  status,
}) {
  try {
    const duplicateExists = await checkForDuplicateDisplayNames(dname);
    if (duplicateExists) {
      const error = new Error(
        "An account with this display name already exists."
      );
      error.code = "auth/duplicate-display-name";
      throw error;
    }
    const createStaff = httpsCallable(functions, "createStaff");
    await createStaff({ fname, lname, dname, email, password, role, status });
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function deleteUserBasedOnId(id) {
  try {
    const adminDeleteUser = httpsCallable(functions, "adminDeleteUser");
    await adminDeleteUser({ id });
  } catch (error) {
    console.error(error);
    throw error;
  }
}
