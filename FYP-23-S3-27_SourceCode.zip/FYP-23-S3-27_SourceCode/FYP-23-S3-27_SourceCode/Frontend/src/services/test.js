import { getAllListings } from "./listingService";
import { updateListingStatus } from "./listingService";
import { searchListings } from "./listingService";
import { updateListing } from "./listingService";
import { filterListings } from "./listingService";
import { searchListingsByCategory } from "./listingService";
import { addQuery, updateQueryLogHistory, getAllQueries } from "./queryService";
import { getQuery } from "./queryService";
import { searchQuery } from "./queryService";
import { updateQueryStatus } from "./queryService";
import { getReviews } from "./reviewService";
import { addReview } from "./reviewService";
import { getAllBuyerReviews } from "./reviewService";
import { filterSearch } from "./listingService";
import { saveIndividualListing } from "./listingService";
import { getSavedListings } from "./listingService";
import { addReportedListings } from "./listingService";
import { addReportedUsers } from "./userService";
import { addOfferListings } from "./offerService";
import { deleteOffer } from "./offerService";
import { getOffersByBuyer } from "./offerService";
import { respondToBuyerOffer } from "./offerService";
import { addAutoReply } from "./userService";
import { getAutoReply } from "./userService";
import { updateAutoReply } from "./userService";
import { getSalesHistory } from "./listingService";
import { getDailySale } from "./listingService";

/* async function test () {
  // Test functions here
  
  ));
} */
//async function test() {
// Test functions here
/* 
    getDailySale("qhkmiki7KJWlvXdHukTHhIPd5k63")
    addReview({
      listingId: '',
      rating: '',
      review: '',
      reviewerName: '',
      userId: '',
      reviewerType: ''
    })
  ); */
// }

// export default test;
