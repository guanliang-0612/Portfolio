import httpClient from "../utils/httpClient";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  query,
  getDoc,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../libs/firebase";
import { updateDoc, setDoc, addDoc } from "firebase/firestore";

const queriesRef = collection(db, "queries");

// UC:CS06
export async function getAllQueries() {
  const querySnapshot = await getDocs(queriesRef);
  let results = [];
  querySnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    // Pass all properties using ...
    results.push({ id: doc.id, ...doc.data() });
  });
  return results;
}

// UC:S30 //UC:B35
export async function addQuery(
  query = {
    fname: "",
    lname: "",
    email: "",
    subject: "",
    details: "",
  }
) {
  try {
    const dateTimeNow = new Date().toLocaleDateString("en-GB");
    const data = {
      fname: query.fname,
      lname: query.lname,
      email: query.email,
      subject: query.subject,
      details: query.details,
      receivedDate: dateTimeNow,
      status: "Pending",
    };
    await addDoc(queriesRef, data);
    return true;
  } catch (error) {
    return null;
  }
}

// UC:CS07
export async function getQuery(queryID) {
  try {
    const docRef = doc(db, "queries", queryID);
    const docSnap = await getDoc(docRef);
    return { id: docSnap.id, ...docSnap.data() };
  } catch (error) {
    return null;
  }
}
// UC:CS08
export async function searchQuery(query = { subject: "" }) {
  const querySnapshot = await getDocs(queriesRef);
  let results = [];
  querySnapshot.forEach((doc) => {
    const uppSubject = query.subject.toUpperCase();
    const uppCaseSubject = doc.data().subject.toUpperCase();
    if (uppSubject == uppCaseSubject) {
      results.push({ id: doc.id, ...doc.data() });
    }
  });
  return results;
}

// UC:CS10
export async function updateQueryLogHistory(id, action_taken, agent_uid) {
  try {
    const docRef = doc(db, "queries", id);
    const logRef = collection(docRef, "logHistory");
    await addDoc(logRef, {
      action_taken: action_taken,
      agent_uid: agent_uid,
      timestamp: new Date(),
    });
    return true;
  } catch (err) {
    alert(err);
  }
}

// UC:CS09
export async function updateQueryStatus(id, status) {
  try {
    const docRef = doc(db, "queries", id);
    await updateDoc(docRef, {
      status: status,
    });
    return true;
  } catch (err) {
    alert(err);
  }
}

export async function getLogs(id) {
  const docRef = doc(db, "queries", id);
  const logRef = collection(docRef, "logHistory");
  //logRef.orderBy("timestamp")
  const querySnapshot = await getDocs(logRef);
  let results = [];
  querySnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    // Pass all properties using ...
    results.push({ id: doc.id, ...doc.data() });
  });
  return results;
}
