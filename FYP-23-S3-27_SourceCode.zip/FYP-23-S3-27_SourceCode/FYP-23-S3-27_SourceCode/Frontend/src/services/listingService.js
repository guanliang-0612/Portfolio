import httpClient from "../utils/httpClient";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  orderBy,
  query,
  getDoc,
  onSnapshot,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "../libs/firebase";
import { updateDoc, arrayUnion, addDoc } from "firebase/firestore";

const listingsRef = collection(db, "listings");

export async function getRecommendedListings(userId) {
  const response = await httpClient.get(`/listing/recommended/${userId}`);
  const recommendedListings = response.data;
  return recommendedListings;
}

// UC:S08
export async function saveListing(
  listing = {
    files: [],
    name: "",
    price: "",
    condition: "",
    status: "",
    category: "",
    colour: "",
    details: "",
    savedBy: "",
  }
) {
  try {
    listing.imageUrls = await Promise.all(
      // This line uploads each image file to firebase file storage
      listing.files.map(async (file) => {
        if (file.name === "") return "No selected file";
        const randomId = doc(collection(db, "temp")).id;
        // Solution to get file ext from name https://stackoverflow.com/questions/680929/how-to-extract-extension-from-filename-string-in-javascript
        let regex = /(?:\.([^.]+))?$/;
        const fileExt = regex.exec(file.name)[1];
        const storageRef = ref(storage, `images/${randomId}.${fileExt}`);
        const fileSnapshot = await uploadBytes(storageRef, file);

        return getDownloadURL(fileSnapshot.ref);
      })
    );
    // Exclude "files" from being saved in the database
    const { files, ...listingDetails } = listing;
    const docRef = await addDoc(collection(db, "listings"), {
      savedBy: [],
      ...listingDetails,
    });

    return docRef.id;
  } catch (error) {
    return null;
  }
}

// UC:S10 //UC:B13
export async function getListing(listingId) {
  try {
    const docRef = doc(db, "listings", listingId);
    const docSnap = await getDoc(docRef);
    if (!docSnap.exists()) return null;
    return { id: docSnap.id, ...docSnap.data() };
  } catch (error) {
    return null;
  }
}

// UC:S09
export async function getListingsBySeller(sellerUid) {
  try {
    const q = query(listingsRef, where("sellerId", "==", sellerUid));
    const querySnapshot = await getDocs(q);
    const results = [];
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      results.push({ id: doc.id, ...doc.data() });
    });
    return results;
  } catch (error) {
    return null;
  }
}

export async function getAllListings() {
  try {
    const querySnapshot = await getDocs(
      query(listingsRef, where("status", "==", "Available"))
    );
    let results = [];
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      results.push({ id: doc.id, ...doc.data() });
    });
    return results;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:S13
export async function updateListingStatus(listing = { id: "", status: "" }) {
  try {
    const docRef = doc(db, "listings", listing.id);
    await updateDoc(docRef, {
      status: listing.status,
    });
    return true;
  } catch (error) {
    return false;
  }
}

// UC:S14 //UC:B10
export async function searchListings(criteria = "") {
  try {
    const querySnapshot = await getDocs(listingsRef);
    let results = [];
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      if (doc.data().name.toUpperCase().includes(criteria?.toUpperCase())) {
        results.push({ id: doc.id, ...doc.data() });
      }
    });
    return results;
  } catch (error) {
    return error;
  }
}
// UC:B09
export async function searchListingsByCategory(listing = { category: "" }) {
  try {
    const querySnapshot = await getDocs(listingsRef);
    let results = [];
    querySnapshot.forEach((doc) => {
      const uppCategory = listing.category.toUpperCase();
      const uppCaseCategory = doc.data().category.toUpperCase();
      if (uppCategory == uppCaseCategory) {
        results.push({ id: doc.id, ...doc.data() });
      }
    });
    return results;
  } catch (error) {
    return error;
  }
}

// UC:S15
export async function filterListings(condition, price, category) {
  try {
    let querySnapshot = await getDocs(listingsRef);
    let results = [];
    let q = collection(db, "listings");
    if (condition != "") {
      querySnapshot = await getDocs(q);
      q = query(q, where("condition", "==", condition));
    }
    if (category != "") {
      querySnapshot = await getDocs(q);
      q = query(q, where("category", "==", category));
    }

    if (price.length > 0) {
      querySnapshot = await getDocs(q);
      const firstInputPrice = price[1];
      const firstInputPriceOperator = price[0];
      q = query(q, where("price", firstInputPriceOperator, firstInputPrice));

      if (price.length > 2) {
        querySnapshot = await getDocs(q);
        const secondInputPrice = price[3];
        const secondInputPriceOperator = price[2];
        q = query(
          q,
          where("price", secondInputPriceOperator, secondInputPrice)
        );
      }
    }
    querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      results.push({ id: doc.id, ...doc.data() });
    });

    return results;
  } catch (error) {
    return error;
  }
}

// UC:S11
export async function updateListing(
  listing = {
    id: "",
    name: "",
    price: "",
    condition: "",
    status: "",
    section: "",
    category: "",
    colour: "",
    details: "",
    files: [],
  }
) {
  try {
    const docRef = doc(db, "listings", listing.id);
    const imageUrls = await Promise.all(
      listing.files.map(async (file) => {
        if (typeof file === "string") return file;
        if (file.filename === "") return "No selected file";
        const randomId = doc(collection(db, "temp")).id;
        // Solution to get file ext from name https://stackoverflow.com/questions/680929/how-to-extract-extension-from-filename-string-in-javascript
        let regex = /(?:\.([^.]+))?$/;
        const fileExt = regex.exec(file.name)[1];
        const storageRef = ref(storage, `images/${randomId}.${fileExt}`);

        const fileSnapshot = await uploadBytes(storageRef, file);

        return getDownloadURL(fileSnapshot.ref);
      })
    );
    await updateDoc(docRef, {
      name: listing.name,
      price: listing.price,
      condition: listing.condition,
      status: listing.status,
      category: listing.category,
      section: listing.section,
      colour: listing.colour,
      details: listing.details,
      style: listing.style,
      imageUrls,
    });
    return true;
  } catch (error) {
    return error;
  }
}

// UC:S12
export async function deleteListing(id) {
  try {
    /* const response = await deleteDoc(doc(db, "listings", id)); */
    const response = await updateDoc(doc(db, "listings", id), {
      status: "Deleted",
    });
    return true;
  } catch (error) {
    return false;
  }
}

// UC:B12
export async function filterSearch(
  listing = { criteria: "" },
  condition,
  price,
  category
) {
  try {
    const snapshot = await getDocs(listingsRef);
    let searchResult = [];
    let q = collection(db, "listings");
    q = query(q, where("name", "==", listing.criteria.toLowerCase()));
    let results = [];
    if (condition != "") {
      q = query(q, where("condition", "==", condition));
    }
    if (category != "") {
      q = query(q, where("category", "==", category));
    }

    if (price.length > 0) {
      const firstInputPrice = price[1];
      const firstInputPriceOperator = price[0];
      q = query(q, where("price", firstInputPriceOperator, firstInputPrice));

      if (price.length > 2) {
        const secondInputPrice = price[3];
        const secondInputPriceOperator = price[2];
        q = query(
          q,
          where("price", secondInputPriceOperator, secondInputPrice)
        );
      }
    }
    let querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      results.push({ id: doc.id, ...doc.data() });
    });

    return results;
  } catch (error) {
    return error;
  }
}

// UC:B14
export async function saveIndividualListing(listingID, userID) {
  try {
    const docRef = doc(db, "listings", listingID);
    await updateDoc(docRef, {
      savedBy: arrayUnion(userID),
    });
    return true;
  } catch (error) {
    return error;
  }
}

// UC:B15
// export async function getSavedListings(buyerID) {
//   try {
//     const q = query(listingsRef, where("savedBy", "array-contains", buyerID));
//     const querySnapshot = await getDocs(q);
//     const results = [];
//     querySnapshot.forEach((doc) => {
//       // doc.data() is never undefined for query doc snapshots
//       // Pass all properties using ...
//       results.push({ id: doc.id, ...doc.data() });
//     });
//     return results;
//   } catch (error) {
//
//     return error;
//   }
// }

// UC:B15
export function getSavedListings(buyerID, storeSavedListings) {
  const q = query(listingsRef, where("savedBy", "array-contains", buyerID));
  const unsubscribe = onSnapshot(q, (snapshot) => {
    const savedListings = [];
    snapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      savedListings.push({ id: doc.id, ...doc.data() });
    });
    storeSavedListings(savedListings);
  });
  return unsubscribe; // Return an unsubscribe function to stop listening.
}

export async function removeSavedListing(listingID, userID) {
  try {
    const docRef = doc(db, "listings", listingID);
    const docSnapshot = await getDoc(docRef);
    if (docSnapshot.exists()) {
      const savedByArray = docSnapshot.data().savedBy;
      if (savedByArray.includes(userID)) {
        // Remove the user's ID from the savedBy array
        const updatedSavedByArray = savedByArray.filter((id) => id !== userID);

        // Update the document with the modified savedBy array
        await updateDoc(docRef, { savedBy: updatedSavedByArray });

        return true;
      } else {
        console.error("User is not saved for this listing.");
        return false;
      }
    } else {
      console.error("Listing not found.");
      return false;
    }
  } catch (error) {
    console.error("Error removing saved listing:", error);
    return false;
  }
}

export async function isListingSaved(listingID, userID) {
  try {
    const docRef = doc(db, "listings", listingID);
    const docSnapshot = await getDoc(docRef);

    if (docSnapshot.exists()) {
      const savedByArray = docSnapshot.data().savedBy;
      return savedByArray.includes(userID);
    } else {
      console.error("Listing not found.");
      return false;
    }
  } catch (error) {
    console.error("Error checking if the listing is saved:", error);
    return false;
  }
}

/* export async function updateListing(listingId, updatedData) {
  try {
    const docRef = doc(db, "listings", listingId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      // Merge the updated data with the existing data
      const updatedListing = { ...docSnap.data(), ...updatedData };

      // Update the document in the Firestore database
      await docRef.set(updatedListing);

      return true;
    } else {
      // Listing with the given ID does not exist
      return false;
    }
  } catch (error) {
    
    return false;
  }
} */

// UC:B18
export async function addReportedListings(
  report = {
    listingId: "",
    reason: "",
    description: "",
    userId: "",
  }
) {
  try {
    const docRef = doc(db, "listings", report.listingId);
    const logRef = collection(docRef, "reported_listings");
    const data = {
      listingId: report.listingId,
      reason: report.reason,
      description: report.description,
      userId: report.userId,
      timestamp: new Date(),
    };
    await addDoc(logRef, data);
    return true;
  } catch (error) {
    return error;
  }
}

export async function searchListingsByImage(imageUrl = "") {
  try {
    const imageResponse = await fetch(imageUrl);
    const imageBlob = await imageResponse.blob();
    let imageFormData = new FormData();
    imageFormData.append("query", imageBlob);

    const arrayOfSimilarListings = (
      await httpClient.post("/listing/imagesearch", imageFormData)
    ).data;
    return arrayOfSimilarListings;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function getClothingAttributes(imageUrl) {
  try {
    const imageResponse = await fetch(imageUrl);
    const imageBlob = await imageResponse.blob();
    let imageFormData = new FormData();
    imageFormData.append("query", imageBlob);

    const response = await httpClient.post(
      "/listing/clothingattributes",
      imageFormData
    );

    return response.data;
  } catch (error) {
    return error;
  }
}

export async function getSalesHistory(sellerId) {
  try {
    const offersRef = collection(db, "offers");
    const q = query(
      offersRef,
      where("sellerId", "==", sellerId),
      where("status", "==", "accepted"),
      orderBy("timestamp", "asc")
    );
    const querySnapshot = await getDocs(q);
    let results = [];
    let storeDate = "";
    let storeAmount = 0;
    let finalAmount = 0;
    const size = querySnapshot.size;
    let filteredResult = [];
    querySnapshot.forEach((firstDoc) => {
      /* if (
        (firstDoc.data().timestamp.toDate() > start_date &&
          firstDoc.data().timestamp.toDate() < end_date) ||
        firstDoc.data().timestamp.toDate().toISOString().split('T')[0] ==
          end_date.toISOString().split('T')[0]
      ) {*/
      storeDate = firstDoc
        .data()
        .timestamp.toDate()
        .toISOString()
        .split("T")[0];
      querySnapshot.forEach((secondDoc) => {
        if (
          firstDoc.data().timestamp.toDate().toISOString().split("T")[0] ==
          secondDoc.data().timestamp.toDate().toISOString().split("T")[0]
        ) {
          // doc.data() is never undefined for query doc snapshots
          // Pass all properties using ...
          storeAmount = storeAmount + secondDoc.data().amount;
        }
      });
      results.push({ date: storeDate, sales: storeAmount });
      const key = "date";
      filteredResult = [
        ...new Map(results.map((value) => [value[key], value])).values(),
      ];
      //}

      storeAmount = 0;
    });
    return filteredResult;
  } catch (error) {
    return error;
  }
}

export async function getDailySale(sellerId) {
  try {
    const offersRef = collection(db, "offers");
    const q = query(
      offersRef,
      where("sellerId", "==", sellerId),
      where("status", "==", "accepted")
    );
    const querySnapshot = await getDocs(q);
    const results = [];
    let total = 0;
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...

      if (
        doc.data().timestamp.toDate().toISOString().split("T")[0] ==
        new Date().toISOString().split("T")[0]
      ) {
        total = total + doc.data().amount;
      }
    });
    return total;
  } catch (error) {
    return error;
  }
}
