import httpClient from "../utils/httpClient";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  query,
  getDoc,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../libs/firebase";
import { updateDoc, arrayUnion, addDoc, documentId } from "firebase/firestore";
import { getListing } from "./listingService";
import { getUserDetails } from "./authService";

const offersRef = collection(db, "offers");

// UC:B22
export async function addOfferListings(
  offer = {
    amount: "",
    buyerId: "",
    listingId: "",
    listingImage: "",
    listingName: "",
    sellerName: "",
    sellerId: "",
    status: "",
  }
) {
  try {
    // const logRef = collection(docRef, 'offers')
    const data = {
      buyerId: offer.buyerId,
      amount: offer.amount,
      listingId: offer.listingId,
      sellerId: offer.sellerId,
      status: "pending",
      timestamp: new Date(),
    };
    await addDoc(offersRef, data);
    return true;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:B23
export async function cancelOffer(offerId) {
  try {
    const result = await updateDoc(doc(db, "offers", offerId), {
      status: "cancelled",
    });
    return result;
  } catch (error) {
    console.error(error);
    throw error;
  }
}
// UC:B24
export async function getOffersByBuyer(buyerID) {
  try {
    // Get all the offers by the buyerId
    const q = query(offersRef, where("buyerId", "==", buyerID));
    const querySnapshot = await getDocs(q);

    // Get the listing for each offer
    const results = await Promise.all(
      querySnapshot.docs.map(async (offerDoc) => {
        const data = offerDoc.data();
        const [listingInfo, sellerInfo] = await Promise.all([
          getListing(data.listingId),
          getUserDetails(data.sellerId),
        ]);

        return {
          id: offerDoc.id,
          ...data,
          listingImage: listingInfo.imageUrls[0],
          sellerName: sellerInfo.dname,
          listingName: listingInfo.name,
          timestamp: data.timestamp.toDate(),
        };
      })
    );
    return results;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function getLatestOffer(data = { buyerId: "" }) {
  try {
    const docRef = query(
      offersRef,
      where("buyerId", "==", data.buyerId),
      where("listingId", "==", data.listingId)
    );
    const querySnapshot = await getDocs(docRef);
    querySnapshot.forEach((doc) => {
      updateDoc(doc.ref, {
        //
        status: data.response,
      });
    });
    return true;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:S20
export async function respondToBuyerOffer(offerId = "", response = "") {
  try {
    const result = await updateDoc(doc(db, "offers", offerId), {
      status: response,
    });
    return result;
  } catch (error) {
    console.error(error);
    throw error;
  }
}
