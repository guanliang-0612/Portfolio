import httpClient from "../utils/httpClient";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  query,
  getDoc,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../libs/firebase";
import { updateDoc, arrayUnion, addDoc } from "firebase/firestore";

const reportsRef = collection(db, "reports");

export async function getAllReport() {
  const reportSnapshot = await getDocs(reportsRef);
  let results = [];
  reportSnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    // Pass all properties using ...
    results.push({ id: doc.id, ...doc.data() });
  });
  return results;
}

export async function addReport(
  report = {
    email: "",
    username: "",
    subject: "",
    details: "",
    listingId: "",
    reportedUserId: "",
  }
) {
  try {
    const dateTimeNow = new Date().toLocaleDateString("en-GB");
    const data = {
      email: report.email,
      username: report.username,
      status: "Open",
      subject: report.subject,
      details: report.details,
      listingId: report.listingId,
      reportedUserId: report.reportedUserId,
      receivedDate: dateTimeNow,
    };
    await addDoc(reportsRef, data);
    return true;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function getReport(reportID) {
  try {
    const docRef = doc(db, "reports", reportID);
    const docSnap = await getDoc(docRef);
    return { id: docSnap.id, ...docSnap.data() };
  } catch (error) {
    return null;
  }
}

export async function updateReportLogHistory(id, action_taken, agent_uid) {
  try {
    const docRef = doc(db, "reports", id);
    const logRef = collection(docRef, "logHistory");
    await addDoc(logRef, {
      action_taken: action_taken,
      agent_uid: agent_uid,
      timestamp: new Date(),
    });
    return true;
  } catch (err) {
    alert(err);
  }
}

export async function updateReportStatus(id, status) {
  try {
    const docRef = doc(db, "reports", id);
    await updateDoc(docRef, {
      status: status,
    });
    return true;
  } catch (err) {
    alert(err);
  }
}

export async function getLogs(id) {
  const docRef = doc(db, "reports", id);
  const logRef = collection(docRef, "logHistory");
  //logRef.orderBy("timestamp")
  const querySnapshot = await getDocs(logRef);
  let results = [];
  querySnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    // Pass all properties using ...
    results.push({ id: doc.id, ...doc.data() });
  });
  return results;
}
