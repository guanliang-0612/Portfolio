import httpClient from "../utils/httpClient";
import {
  collection,
  getDocs,
  doc,
  deleteDoc,
  where,
  query,
  getDoc,
  setDoc,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../libs/firebase";
import { updateDoc, arrayUnion, addDoc } from "firebase/firestore";
import { useAuth } from "../contexts/AuthContext";

const accountDetailsRef = collection(db, "accountDetails");

// UC:B21
export async function addReportedUsers(
  report = {
    reportedUserId: "",
    reason: "",
    description: "",
    userId: "",
  }
) {
  try {
    const docRef = doc(db, "accountDetails", report.reportedUserId);
    const logRef = collection(docRef, "reported_users");
    const data = {
      reportedUserId: report.reportedUserId,
      reason: report.reason,
      description: report.description,
      userId: report.userId,
      timestamp: new Date(),
    };
    await addDoc(logRef, data);
    return true;
  } catch (err) {
    alert(err);
  }
}

// UC:S24
export async function addAutoReply(
  autoReply = {
    message: "",
    isActive: "",
    id: "",
  }
) {
  try {
    const autoRepliesRef = doc(db, "autoReplies", autoReply.id);
    const data = {
      message: autoReply.message,
      isActive: autoReply.isActive,
    };
    await addDoc(autoRepliesRef, data);
    return "success";
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:S25
export async function getAutoReply(user_id) {
  const autoReplyDocRef = doc(collection(db, "autoReplies"), user_id);
  const autoReplyDoc = await getDoc(autoReplyDocRef);
  if (!autoReplyDoc.exists) return null;
  return { id: autoReplyDoc.id, ...autoReplyDoc.data() };
}

// UC:S26 // UC:S27
export async function updateAutoReply(
  autoReply = {
    message: "",
    isActive: "",
    id: "",
  }
) {
  try {
    const docRef = doc(collection(db, "autoReplies"), autoReply.id);
    await setDoc(
      docRef,
      {
        message: autoReply.message,
        isActive: autoReply.isActive,
      },
      { merge: true }
    );
  } catch (error) {
    console.error(error);
    throw error;
  }
}

export async function changeAutoReplyStatus({ isActive = false, id = "" }) {
  try {
    const autoReplyDocRef = doc(collection(db, "autoReplies"), id);
    if (!isActive) {
      await setDoc(
        autoReplyDocRef,
        {
          isActive,
        },
        { merge: true }
      );
      return;
    } else {
      const autoReplyDoc = await getDoc(autoReplyDocRef);
      if (!autoReplyDoc.exists) {
        throw new Error(
          "Unable to turn on auto-reply. Your current auto-reply message is empty. Please ensure you have an auto-reply message saved before toggling the status."
        );
      }
      const autoReplyData = autoReplyDoc.data();
      if (!autoReplyData?.message) {
        throw new Error(
          "Unable to turn on auto-reply. Your current auto-reply message is empty. Please ensure you have an auto-reply message saved before toggling the status."
        );
      }
      await setDoc(
        autoReplyDocRef,
        {
          isActive,
        },
        { merge: true }
      );
    }
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:S25
export async function getUserDetails(user_id) {
  try {
    const docRef = doc(db, "accountDetails", user_id);
    const docSnap = await getDoc(docRef);
    const results = { id: docSnap.id, ...docSnap.data() };

    return results;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// UC:A08
export async function getAllUserDetails() {
  try {
    const accountDetailsRef = query(
      collection(db, "accountDetails"),
      where("status", "!=", "deleted")
    );
    const docsSnap = await getDocs(accountDetailsRef);
    let allUserDetails = [];
    docsSnap.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      // Pass all properties using ...
      allUserDetails.push({ id: doc.id, ...doc.data() });
    });
    return allUserDetails;
  } catch (error) {
    console.error(error);
    return [];
  }
}

export async function addViewHistory() {
  const userRef = db.collection("users").doc(userId);

  // Start a transaction
  db.runTransaction((transaction) => {
    // Get the current user document
    return transaction.get(userRef).then((userDoc) => {
      if (!userDoc.exists) {
        throw "Document does not exist!";
      }

      // Get the current view history
      let viewHistory = userDoc.data().viewHistory || [];

      // Add the new view to the start of the array
      viewHistory.unshift(listingId);

      // If the view history is too long, remove views from the end
      if (viewHistory.length > 30) {
        viewHistory = viewHistory.slice(0, 30);
      }

      // Update the view history
      transaction.update(userRef, { viewHistory: viewHistory });
    });
  });
  return;
}
