import httpClient from "./utils/httpClient";
import Landingpage from "./pages/LandingPage/Landingpage";
import Navbar from "./components/Navbar/Navbar";
import Footer from "./components/Footer/Footer";
import "./components/Footer/Footer.css";
import "./App.css";
import ViewIndividualListingPage from "./pages/ListingPage/ViewIndividualListingPage";
import PageRoutes from "./routes/PageRoutes.jsx";
import FAQPage from "./pages/FAQPage/FAQPage";
import CSAdminNavbar from "./pages/staff/components/CSAdminNavbarFooter/CSAdminNavbar";
import CSAdminFooter from "./pages/staff/components/CSAdminNavbarFooter/CSAdminFooter";
import { useAuth } from "./contexts/AuthContext";
import CSNavbar from "./pages/staff/components/CSAdminNavbarFooter/CSNavbar";
/* import test from "./services/test"; */
import { useDisclosure } from "@mantine/hooks";
import { LoadingOverlay, Button, Group, Box } from "@mantine/core";

function App() {
  const { currentUser, userIsLoading } = useAuth();
  return (
    <div>
      {userIsLoading ? (
        <LoadingOverlay
          loaderProps={{ color: "dark" }}
          visible={true}
          overlayBlur={2}
        />
      ) : (
        <>
          <div className="Navbar">
            {currentUser?.role === "admin" ? (
              <CSAdminNavbar />
            ) : currentUser?.role === "support" ? (
              <CSNavbar />
            ) : (
              <Navbar />
            )}
          </div>
          <div className="app-container">
            <PageRoutes />
          </div>
          <div className="Footer">
            {/*  <Footer /> */}
            {currentUser?.role === "admin" ? <CSAdminFooter /> : <Footer />}
          </div>
        </>
      )}
    </div>
  );
}

export default App;
