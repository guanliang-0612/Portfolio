import axios from "axios";
const API_ENDPOINT = import.meta.env.VITE_API_ENDPOINT;

const httpClient = axios.create({
  baseURL: `${API_ENDPOINT}`,
  origin: true,
  withCredentials: true,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, GET, PUT, OPTIONS, DELETE",
    "Access-Control-Allow-Headers":
      "Access-Control-Allow-Methods, Access-Control-Allow-Origin, Origin, Accept, Content-Type",
  },
});

export default httpClient;
