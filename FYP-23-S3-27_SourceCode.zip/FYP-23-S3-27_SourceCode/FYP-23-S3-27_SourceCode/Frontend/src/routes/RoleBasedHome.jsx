import { Route, redirect } from "react-router-dom";
import { useLocation, Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const RoleBasedHome = ({ roleHome }) => {
  const location = useLocation();
  const { currentUser } = useAuth();
  if (currentUser) {
    const { role } = currentUser;
    return <Navigate to={roleHome[role]} state={{ from: location }} replace />;
  }

  return (
    <Navigate to={roleHome["unauthenticated"]} state={{ from: location }} />
  );
};

export default RoleBasedHome;
