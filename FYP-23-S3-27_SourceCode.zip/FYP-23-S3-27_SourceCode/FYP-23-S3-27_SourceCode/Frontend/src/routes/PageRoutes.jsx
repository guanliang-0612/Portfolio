import { Routes, Route } from "react-router-dom";
import Landingpage from "../pages/LandingPage/Landingpage";
import ViewIndividualListingPage from "../pages/ListingPage/ViewIndividualListingPage";
import FAQPage from "../pages/FAQPage/FAQPage";
import AboutUsPage from "../pages/AboutUsPage/AboutUsPage";
import ContactUsPage from "../pages/ContactUsPage/ContactUsPage";
import CreateListing from "../pages/customer/CreateListing";
import LoginSignUpPage from "../pages/LoginSignUpPage/LoginSignUpPage";
import ViewIndividualAccPage from "../pages/ViewIndividualAccPage/ViewIndividualAccPage";
import EditIndividualAcc from "../pages/customer/EditIndividualAccPage/EditIndividualAcc";
import ProtectedRoute from "./ProtectedRoute";
import RoleBasedHome from "./RoleBasedHome";
import SearchResultPage from "../pages/SearchResultPage/SearchResultPage";
import UserDashboard from "../pages/UserDashboard/UserDashboard";
import AdminReportDashboardPage from "../pages/staff/admin/AdminReportDashboardPage/AdminReportDashboardPage";
import AdminManageAccountPage from "../pages/staff/admin/AdminManageAccountPage/AdminManageAccountPage";
import AdminCreateStaffAccountPage from "../pages/staff/admin/AdminCreateStaffAccountPage/AdminCreateStaffAccountPage";
import AdminViewEditAccountPage from "../pages/staff/admin/AdminViewEditAccountPage/AdminViewIndividualAccountPage";
import CSAdminViewEditMyAccountPage from "../pages/staff/common/CSAdminViewEditMyAccountPage/CSAdminViewEditMyAccountPage";
import CSTicketDashboardPage from "../pages/staff/customerService/CSTicketDashboardPage/CSTicketDashboardPage";
import CSViewIndividualTicketPage from "../pages/staff/customerService/CSViewIndividualTicketPage/CSViewIndividualTicketPage";
import ViewIndividualReportPage from "../pages/staff/admin/ViewIndividualReportPage/ViewIndividualReportPage";
import ImageSearchResultPage from "../pages/SearchResultPage/ImageSearchResult";
import ViewAllChat from "../pages/customer/ViewAllChat/ViewAllChat";
import EditListing from "../pages/ListingPage/EditListing";
import AutoReplyPage from "../pages/customer/AutoReply/AutoReplyPage";
import ErrorPage from "../pages/ErrorPage";

function PageRoutes() {
  return (
    <Routes>
      <Route
        path="/"
        exact
        element={
          <RoleBasedHome
            roleHome={{
              admin: "/admin",
              customer: "/landing",
              support: "/CSTicketDashboardPage",
              unauthenticated: "/landing",
            }}
          />
        }
      />

      {/* UNPROTECTED ROUTES */}
      <Route path="/landing" exact element={<Landingpage />} />
      <Route path="/listing/:id" element={<ViewIndividualListingPage />} />
      <Route path="/FAQ" exact element={<FAQPage />} />
      <Route path="/AboutUs" exact element={<AboutUsPage />} />
      <Route path="/SearchResults" exact element={<SearchResultPage />} />
      <Route path="/ContactUs" exact element={<ContactUsPage />} />
      <Route element={<ProtectedRoute allowedRoles={["unauthenticated"]} />}>
        <Route path="/LoginSignUp" exact element={<LoginSignUpPage />} />
      </Route>

      <Route
        path="/ImageSearchResult"
        exact
        element={<ImageSearchResultPage />}
      />
      <Route
        path="/ViewIndividualAccount"
        exact
        element={<ViewIndividualAccPage />}
      />
      <Route path="/men" exact element={<CreateListing />} />

      <Route
        path="/UserDashboard/:id/:tabValue?"
        exact
        element={<UserDashboard />}
      />
      <Route path="*" exact element={<ErrorPage />} />
      {/* CUSTOMER PROTECTED ROUTES */}
      <Route element={<ProtectedRoute allowedRoles={["customer"]} />}>
        <Route path="/CreateListing" exact element={<CreateListing />} />
        <Route path="/EditListing/:listingId" exact element={<EditListing />} />
        {/* Optional route segment to handle view all chats without clicking into a room
        room https://reactrouter.com/en/main/route/route#optional-segments */}
        <Route path="/chats/:chatRoomId?" exact element={<ViewAllChat />} />
        <Route path="/AutoReply" exact element={<AutoReplyPage />} />
        <Route path="/AccountPage" exact element={<EditIndividualAcc />} />
      </Route>

      {/* ADMIN PROTECTED ROUTES */}
      <Route element={<ProtectedRoute allowedRoles={["admin"]} />}>
        <Route path="/admin" exact element={<AdminReportDashboardPage />} />
        <Route
          path="/AdminReportDashboardPage"
          exact
          element={<AdminReportDashboardPage />}
        />
        <Route
          path="/AdminManageAccountPage"
          exact
          element={<AdminManageAccountPage />}
        />
        <Route
          path="/AdminCreateStaffAccountPage"
          exact
          element={<AdminCreateStaffAccountPage />}
        />
        <Route
          path="/AdminViewEditAccountPage/:id"
          exact
          element={<AdminViewEditAccountPage />}
        />
        <Route
          path="/ViewIndividualReportPage"
          exact
          element={<ViewIndividualReportPage />}
        />
      </Route>

      {/* CUSTOMER SUPPORT PROTECTED ROUTES */}
      <Route element={<ProtectedRoute allowedRoles={["support"]} />}>
        <Route
          path="/CSTicketDashboardPage"
          exact
          element={<CSTicketDashboardPage />}
        />
        <Route
          path="/CSViewIndividualTicketPage"
          exact
          element={<CSViewIndividualTicketPage />}
        />
        <Route path="/SearchResult" exact element={<SearchResultPage />} />
      </Route>

      {/* CS & ADMIN SHARED PROTECTED ROUTES */}
      <Route element={<ProtectedRoute allowedRoles={["support", "admin"]} />}>
        <Route
          path="/CSAdminViewEditMyAccountPage"
          exact
          element={<CSAdminViewEditMyAccountPage />}
        />
      </Route>
    </Routes>
  );
}

export default PageRoutes;
