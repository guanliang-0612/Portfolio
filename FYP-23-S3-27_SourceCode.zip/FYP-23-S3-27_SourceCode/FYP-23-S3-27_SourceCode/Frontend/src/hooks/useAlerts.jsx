import { Alert } from "@mantine/core";
import { IconAlertCircle } from "@tabler/icons-react";
import { useState } from "react";

export default function useAlerts() {
  const [alert, setAlert] = useState({ type: "", message: "" });

  function displayError(message) {
    setAlert({ type: "error", message });
  }

  function displaySuccess(message) {
    setAlert({ type: "success", message });
  }

  function closeAlert() {
    setAlert({ type: "", message: "" });
  }

  function AlertDisplay({ alertStyle = {} }) {
    return (
      alert.type !== "" && (
        <Alert
          icon={<IconAlertCircle size="1rem" />}
          /* visible={alert.type !== ""} */
          title={alert.type === "success" ? "Success!" : "Bummer!"}
          color={alert.type === "success" ? "green" : "red"}
          style={alertStyle}
          withCloseButton
          closeButtonLabel="Close alert"
          onClose={closeAlert}
        >
          {alert.message}
        </Alert>
      )
    );
  }

  return {
    AlertDisplay,
    closeAlert,
    displayError,
    displaySuccess,
  };
}
