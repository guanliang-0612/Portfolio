import { useEffect, useMemo, useState } from "react";
import { db } from "../libs/firebase";
import {
  doc,
  orderBy,
  collection,
  onSnapshot,
  addDoc,
  setDoc,
  query,
  serverTimestamp,
} from "firebase/firestore";
import { useAuth } from "../contexts/AuthContext";

export default function useChat(roomId = "") {
  const messagesRef = useMemo(() => {
    if (!roomId) return null;
    return collection(doc(db, "chatRooms", roomId), "messages");
  }, [roomId]);
  const [messages, setMessages] = useState([]);
  const { currentUser } = useAuth();
  useEffect(() => {
    try {
      if (!messagesRef) return;
      const unsubscribe = onSnapshot(
        query(messagesRef, orderBy("timestamp", "asc")),
        (snapshot) => {
          if (snapshot.empty) {
            setMessages([]);
            return;
          }
          const newMessages = snapshot.docs.map((doc) => {
            return {
              id: doc.id,
              ...doc.data(),
              timestamp: doc.data().timestamp.toDate(),
            };
          });
          setMessages(newMessages);
        }
      );

      return () => unsubscribe();
    } catch (err) {}
  }, [messagesRef]);

  async function sendMessage(message) {
    try {
      const newMessageRef = doc(messagesRef);
      // Optimistically render message before it is saved to firestore to improve responsiveness
      setMessages([
        ...messages,
        {
          id: newMessageRef.id,
          timestamp: new Date(),
          senderId: currentUser.id,
          text: message,
        },
      ]);
      await setDoc(newMessageRef, {
        timestamp: serverTimestamp(),
        senderId: currentUser.id,
        text: message,
      });

      return newMessageRef;
    } catch (err) {
      console.error("Error sending message: ", err);
    }
  }

  return { messages, sendMessage };
}
