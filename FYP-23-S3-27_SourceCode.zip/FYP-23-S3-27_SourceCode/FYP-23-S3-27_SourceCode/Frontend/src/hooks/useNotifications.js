import { useEffect, useState } from "react";
import { db } from "../libs/firebase";
import { doc, collection, onSnapshot } from "firebase/firestore";

export default function useNotifications(userId) {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    try {
      const query = collection(
        doc(db, "accountDetails", userId),
        "notifications"
      );

      const unsubscribe = onSnapshot(query, (snapshot) => {
        if (snapshot.empty) return;
        const newNotifications = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        setNotifications(newNotifications);
      });

      return () => unsubscribe();
    } catch (err) {}
  }, [userId]);

  return notifications;
}
