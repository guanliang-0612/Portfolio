import { useEffect, useMemo, useState } from "react";
import { db } from "../libs/firebase";
import {
  doc,
  orderBy,
  collection,
  onSnapshot,
  addDoc,
  setDoc,
  query,
  where,
  serverTimestamp,
} from "firebase/firestore";
import { useAuth } from "../contexts/AuthContext";

export default function useOffers(buyerId, listingId) {
  const offersRef = useMemo(
    () =>
      query(
        collection(db, "offers"),
        where("buyerId", "==", buyerId),
        where("listingId", "==", listingId),
        orderBy("timestamp", "desc")
      ),
    [buyerId, listingId]
  );
  const [offers, setOffers] = useState([]);
  const { currentUser } = useAuth();
  const [offersLoading, setOffersLoading] = useState(true);
  useEffect(() => {
    try {
      const unsubscribe = onSnapshot(query(offersRef), (snapshot) => {
        setOffersLoading(true);
        if (snapshot.empty) {
          setOffers([]);
          setOffersLoading(false);
          return;
        }
        const newOffers = snapshot.docs.map((doc) => {
          return {
            id: doc.id,
            ...doc.data(),
            timestamp: doc.data().timestamp.toDate(),
          };
        });
        setOffers(newOffers);
        setOffersLoading(false);
      });

      return () => unsubscribe();
    } catch (err) {}
  }, [offersRef]);

  /* async function sendMessage(message) {
    try {
      const newMessageRef = doc(messagesRef);
      // Optimistically render message before it is saved to firestore to improve responsiveness
      setOffers([
        ...offers,
        {
          id: newMessageRef.id,
          timestamp: new Date(),
          senderId: currentUser.id,
          text: message,
        },
      ]);
      await setDoc(newMessageRef, {
        timestamp: serverTimestamp(),
        senderId: currentUser.id,
        text: message,
      });

      return newMessageRef;
    } catch (err) {
      console.error("Error sending message: ", err);
    }
  }
 */
  return { offers, offersLoading };
}
