import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { getSavedListings } from "../services/listingService";

export function useSavedListings() {
  const { currentUser } = useAuth();
  const [savedListings, setSavedListings] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  function storeSavedListings(updatedListings) {
    setSavedListings(updatedListings);
    setIsLoading(false);
  }

  useEffect(() => {
    if (currentUser) {
      // Start listening for real-time updates on saved listings
      const unsubscribe = getSavedListings(currentUser.id, storeSavedListings);

      return () => {
        // Unsubscribe from real-time updates when the component unmounts
        unsubscribe();
      };
    }
  }, [currentUser]);

  return { savedListings, isLoading };
}
