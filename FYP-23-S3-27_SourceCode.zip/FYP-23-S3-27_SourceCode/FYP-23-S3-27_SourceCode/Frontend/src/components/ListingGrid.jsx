import { SimpleGrid } from "@mantine/core";
import ListingCard from "./ListingCard";

export function ListingGrid({ listings }) {
  return (
    <SimpleGrid
      breakpoints={[
        { maxWidth: "sm", cols: 2 },
        { minWidth: "md", cols: 3 },
        { minWidth: 1200, cols: 4 },
      ]}
    >
      {listings?.map((product) => (
        <ListingCard
          key={product.id}
          product={{ ...product, image: product.imageUrls[0] }}
        />
      ))}
    </SimpleGrid>
  );
}
