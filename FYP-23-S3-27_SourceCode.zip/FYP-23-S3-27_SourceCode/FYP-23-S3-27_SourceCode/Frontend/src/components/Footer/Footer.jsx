import React from "react";
import {
  createStyles,
  Text,
  Container,
  ActionIcon,
  Group,
  rem,
} from "@mantine/core";
import { Link } from "react-router-dom";

const useStyles = createStyles((theme) => ({
  footer: {
    whiteSpace: "nowrap",
    marginTop: rem(120),
    paddingTop: `calc(${theme.spacing.xl} * 2)`,
    paddingBottom: `calc(${theme.spacing.xl} * 2)`,
    backgroundColor:
      theme.colorScheme === "dark"
        ? theme.colors.dark[6]
        : theme.colors.gray[0],
    borderTop: `${rem(1)} solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[5] : theme.colors.gray[2]
    }`,
  },
  logoText: {
    fontSize: rem(30), // Adjusted font size for emphasis
    fontWeight: 700,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    textDecoration: "none",
    display: "flex",
    alignItems: "center",
    whiteSpace: "nowrap",
  },
  logo: {
    maxWidth: rem(200),

    [theme.fn.smallerThan("sm")]: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
    },
  },

  description: {
    whiteSpace: "nowrap",
    marginTop: rem(5),

    [theme.fn.smallerThan("sm")]: {
      marginTop: theme.spacing.xs,
      textAlign: "center",
    },
  },

  inner: {
    display: "flex",
    justifyContent: "space-between",

    [theme.fn.smallerThan("sm")]: {
      flexDirection: "column",
      alignItems: "center",
    },
  },

  groups: {
    whiteSpace: "nowrap",
    display: "flex",
    flexWrap: "wrap",

    [theme.fn.smallerThan("sm")]: {
      display: "none",
    },
  },

  wrapper: {
    width: rem(160),
  },

  link: {
    display: "block",
    color:
      theme.colorScheme === "dark"
        ? theme.colors.dark[1]
        : theme.colors.gray[6],
    fontSize: theme.fontSizes.sm,
    paddingTop: rem(3),
    paddingBottom: rem(3),
    textDecoration: "none", // Add this line to remove the underline
    "&:hover": {
      textDecoration: "underline",
    },
  },

  title: {
    fontSize: theme.fontSizes.lg,
    fontWeight: 700,
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    marginBottom: `calc(${theme.spacing.xs} / 2)`,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    textAlign: "left", // This line aligns the text to the left
  },

  afterFooter: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: theme.spacing.xl,
    paddingTop: theme.spacing.xl,
    paddingBottom: theme.spacing.xl,
    borderTop: `${rem(1)} solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,

    [theme.fn.smallerThan("sm")]: {
      flexDirection: "column",
    },
  },

  social: {
    [theme.fn.smallerThan("sm")]: {
      marginTop: theme.spacing.xs,
    },
  },
}));

export function FooterLinks({ data }) {
  const { classes } = useStyles();

  const groups = data.map((group) => {
    // This is the correct placement for the links constant
    const links = group.links.map((link, index) =>
      link.link.startsWith("/") ? (
        <Link key={index} to={link.link} className={classes.link}>
          {link.label}
        </Link>
      ) : (
        <Text
          key={index}
          className={classes.link}
          component="a"
          href={link.link}
          onClick={(event) => event.preventDefault()}
        >
          {link.label}
        </Text>
      )
    );

    return (
      <div className={classes.wrapper} key={group.title}>
        <Text className={classes.title}>{group.title}</Text>
        {links}
      </div>
    );
  });

  return (
    <footer className={classes.footer}>
      <Container className={classes.inner}>
        <div className={classes.logo}>
          <Text size="xl" className={classes.logoText}>
            TC FASHION
          </Text>
          <Text size="xs" color="dimmed" className={classes.description}>
            Journey together towards a sustainable community.
          </Text>
        </div>
        <div className={classes.groups}>{groups}</div>
      </Container>
      <Container className={classes.afterFooter}>
        <Group spacing={10} position="left" noWrap>
          <Text color="dimmed" size="sm">
            © 2023 Top Care Fashion All rights reserved.
          </Text>
          <a href="/terms" style={{ color: "dimgray", fontSize: "0.875rem" }}>
            Terms
          </a>
          <a href="/privacy" style={{ color: "dimgray", fontSize: "0.875rem" }}>
            Privacy
          </a>
          <a
            href="https://fyp23s327.wixsite.com/top-care-fashion"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "dimgray", fontSize: "0.875rem" }}
          >
            Project Site
          </a>
        </Group>
        {/*
        <Group spacing={0} className={classes.social} position="right" noWrap>
          <ActionIcon size="lg">
            <IconBrandTwitter size="1.05rem" stroke={1.5} />
          </ActionIcon>
          <ActionIcon size="lg">
            <IconBrandYoutube size="1.05rem" stroke={1.5} />
          </ActionIcon>
          <ActionIcon size="lg">
            <IconBrandInstagram size="1.05rem" stroke={1.5} />
          </ActionIcon>
        </Group>
        */}
      </Container>
    </footer>
  );
}

const footerData = [
  {
    title: "About TCF",
    links: [{ label: "About Us", link: "/AboutUs" }],
  },
  {
    title: "Help",
    links: [
      { label: "Contact Us", link: "/ContactUs" },
      { label: "FAQ", link: "/FAQ" },
    ],
  },
];

function Footer() {
  return <FooterLinks data={footerData} />;
}

export default Footer;
