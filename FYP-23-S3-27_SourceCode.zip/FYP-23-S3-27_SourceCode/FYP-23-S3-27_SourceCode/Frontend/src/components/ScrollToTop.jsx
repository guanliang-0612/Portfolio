import { useEffect } from "react";
import { useLocation } from "react-router-dom";

// Hook to scroll to top on page change
// Reference: https://stackoverflow.com/a/61602724
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return <></>;
}

export default ScrollToTop;
