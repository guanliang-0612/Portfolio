import {
  Skeleton,
  Button,
  Avatar,
  Text,
  Rating,
  createStyles,
} from "@mantine/core";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";

const useStyles = createStyles((theme) => ({
  ellipsisText: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: "150px", // Adjust this value based on your requirements
  },
  cursorOverride: {
    "& *": {
      cursor: "pointer!important",
    },
  },
}));

const UserProfileButton = ({
  userInfo = {
    id: "",
    imageUrl: "",
    dname: "",
    rating: 0,
  },
  isLoading = true,
}) => {
  const { classes } = useStyles();
  const [imgIsLoading, setImgIsLoading] = useState(true);
  useEffect(() => {
    if (!userInfo.imageUrl) setImgIsLoading(false);
  }, [userInfo]);
  return (
    <Skeleton visible={isLoading} style={{ width: "min-content" }}>
      <Button
        component={Link}
        to={`/UserDashboard/${userInfo.id}/listings`}
        color="gray"
        style={{
          width: "min-content",
          height: "max-content",
          color: "black",
          padding: "10px",
          cursor: "pointer",
        }}
        variant="subtle"
      >
        <div
          style={{
            display: "flex",
            gap: "15px",
            alignItems: "center",
          }}
        >
          <Skeleton radius="xl" size="lg" visible={imgIsLoading}>
            <Avatar
              size="lg"
              src={userInfo.imageUrl || null}
              imageProps={{
                onLoad: () => setImgIsLoading(false),
              }}
              radius="xl"
            />
          </Skeleton>
          <div
            style={{
              margin: "0px",
            }}
          >
            <Text weight={500} className={classes.ellipsisText}>
              {userInfo.dname}
            </Text>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                cursor: "pointer",
              }}
            >
              <Text
                size="xs"
                style={{
                  marginRight: "2px",
                  whiteSpace: "nowrap",
                  cursor: "pointer",
                }}
                span
              >
                {userInfo.rating > 0 ? userInfo.rating : "No reviews yet"} |
              </Text>
              <Rating
                value={userInfo.rating}
                fractions={2}
                readOnly
                size="xs"
                count={userInfo.rating ? 5 : 1}
                className={classes.cursorOverride}
              />
            </div>
          </div>{" "}
        </div>
      </Button>
    </Skeleton>
  );
};

export default UserProfileButton;
