/* 
 Usecase:
 S03
 B03
 B09
 B10
 B11
*/

import { useState } from "react";
import {
  createStyles,
  Header,
  Autocomplete,
  Container,
  Anchor,
  Group,
  Divider,
  rem,
  Text,
  TextInput,
  Button,
  Menu,
  Center,
  ActionIcon,
  UnstyledButton,
} from "@mantine/core";
import { useDisclosure } from "@mantine/hooks";
import {
  IconChevronDown,
  IconHeart,
  IconMessages,
  IconSearch,
} from "@tabler/icons-react";
import { IconCamera } from "@tabler/icons-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useForm } from "@mantine/form";
import { signout } from "../../services/authService";

import NotificationBell from "./NotificationBell";
import ImageSearch from "./ImageSearch";
const HEADER_HEIGHT = rem(110);

const useStyles = createStyles((theme) => ({
  inner: {
    display: "flex",
    flexDirection: "column",
    alignItems: "stretch",
    justifyContent: "space-between",
  },

  logoText: {
    fontSize: rem(30), // Adjusted font size for emphasis
    fontWeight: 700,
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    textDecoration: "none",
    display: "flex",
    alignItems: "center",
    margin: `0 ${theme.spacing.md}`, // Added horizontal margin for spacing
    whiteSpace: "nowrap",
  },

  links: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },

  userMenu: {
    "&:hover": {
      backgroundColor: "rgba(193, 194, 197, 1)",
    },
  },

  bottomLinks: {
    display: "flex",
    alignItems: "center", // Vertically center all items
    justifyContent: "space-between", // Spread out the items
    marginTop: theme.spacing.md, // Adjust this value as needed
  },

  mainLinks: {
    marginRight: `calc(${theme.spacing.sm} * -1)`,
  },

  mainLink: {
    textTransform: "uppercase",
    fontSize: rem(13),
    color:
      theme.colorScheme === "dark"
        ? theme.colors.dark[1]
        : theme.colors.gray[6],
    padding: `${rem(7)} ${theme.spacing.sm}`,
    fontWeight: 700,
    borderBottom: `${rem(2)} solid transparent`,
    transition: "border-color 100ms ease, color 100ms ease",

    "&:hover": {
      color: theme.colorScheme === "dark" ? theme.white : theme.black,
      textDecoration: "none",
    },
  },

  secondaryLink: {
    color:
      theme.colorScheme === "dark"
        ? theme.colors.dark[2]
        : theme.colors.gray[6],
    fontSize: theme.fontSizes.xs,
    textTransform: "uppercase",
    transition: "color 100ms ease",

    "&:hover": {
      color: theme.colorScheme === "dark" ? theme.white : theme.black,
      textDecoration: "none",
    },
  },

  secondaryLink2: {
    whiteSpace: "nowrap",
    color:
      theme.colorScheme === "dark"
        ? theme.colors.dark[3]
        : theme.colors.gray[5],
    fontSize: theme.fontSizes.xs,
    textTransform: "uppercase",
    transition: "color 100ms ease",

    "&:hover": {
      color: theme.colorScheme === "dark" ? theme.white : theme.black,
      textDecoration: "none",
    },
  },

  mainLinkActive: {
    color: theme.colorScheme === "dark" ? theme.white : theme.black,
    borderBottomColor: theme.colorScheme === "dark" ? theme.white : theme.black,
  },

  imageSearchIcon: {
    marginLeft: "-2px", // Adjust as needed
    cursor: "pointer", // Makes the icon appear clickable
    [theme.fn.smallerThan("xs")]: {
      display: "none",
    },
  },

  searchContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center", // To vertically align the items
  },

  userLinkContainer: {
    display: "flex",
    justifyContent: "end",
    alignItems: "center",
    gap: "15px",
  },
}));

// TODO fix navbar going out of alignment when category links disappear
export function DoubleHeader({ genders, userLinks, categories }) {
  const [opened, { toggle }] = useDisclosure(false);
  const { classes, cx } = useStyles();
  const [active, setActive] = useState(null);
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const form = useForm({
    initialValues: {
      criteria: "",
    },
  });
  const genderLinks = genders.map((item, index) => (
    <Anchor
      component={Link}
      to={item.link}
      key={item.label}
      className={cx(classes.mainLink, {
        [classes.mainLinkActive]: item.link === active,
      })}
      onClick={(event) => {
        /*  event.preventDefault(); */
        setActive(item.link);
      }}
    >
      {item.label}
    </Anchor>
  ));

  const categoryLinks = categories.map((item) => (
    <Anchor
      component={Link}
      to={`${active}${item.link}`}
      key={item.label}
      style={{
        display:
          !active?.toLowerCase().includes("women".toLowerCase()) &&
          item.label.toLowerCase() === "dress"
            ? "none"
            : "block",
      }}
      /* onClick={(event) => event.preventDefault()} */
      className={classes.secondaryLink2}
    >
      {item.label}
    </Anchor>
  ));

  const secondaryItems = currentUser ? (
    <div className={classes.userLinkContainer}>
      <Menu
        key={"hi"}
        trigger="hover"
        transitionProps={{ exitDuration: 0 }}
        withinPortal
      >
        <Menu.Target>
          <Button
            /* href={link.link} */ className={cx(
              classes.link,
              classes.userMenu
            )}
            compact
            color="dark"
            variant="white"
          >
            <Center>
              <span
                style={{ whiteSpace: "nowrap" }}
                className={classes.linkLabel}
              >{`Hi, ${currentUser.dname}`}</span>
              <IconChevronDown size="0.9rem" stroke={1.5} />
            </Center>
          </Button>
        </Menu.Target>
        <Menu.Dropdown>
          {[
            {
              label: "My Profile",
              link: `/UserDashboard/${currentUser.id}/listings`,
            },
            { label: "My Account", link: `/AccountPage` },
          ].map((item) => (
            <Menu.Item
              component={Link}
              to={item.link}
              key={item.label}
              /* onClick={(event) => event.preventDefault()} */
              className={classes.secondaryLink}
            >
              {item.label}
            </Menu.Item>
          ))}
          <Menu.Item
            key={"logout"}
            onClick={async () => {
              // Navigate to the respective page
              await signout();
              navigate("/");
            }}
            className={classes.secondaryLink}
          >
            Logout
          </Menu.Item>
        </Menu.Dropdown>
      </Menu>
      <ActionIcon
        component={Link}
        color="dark"
        to={`/UserDashboard/${currentUser.id}/saved`}
      >
        <IconHeart />
      </ActionIcon>
      <NotificationBell classes={classes} />
      <ActionIcon component={Link} color="dark" to={"/chats"}>
        <IconMessages />
      </ActionIcon>
      <Button component={Link} color="dark" to={"/CreateListing"}>
        Sell
      </Button>
    </div>
  ) : (
    <Anchor
      component={Link}
      to={"/LoginSignup"}
      /* onClick={(event) => event.preventDefault()} */
      className={classes.secondaryLink}
    >
      Login/Sign Up
    </Anchor>
  );

  return (
    <Header height={HEADER_HEIGHT} mb={20}>
      <Container className={classes.inner}>
        <div className={classes.links}>
          <div
            style={{ display: "flex", flex: 1, justifyContent: "flex-start" }}
          >
            {genderLinks}
          </div>

          <div style={{ display: "flex", justifyContent: "center", flex: 1 }}>
            <Link
              className={classes.logoText}
              to={"/"}
              onClick={(event) => {
                setActive(null);
              }}
            >
              <Text>TC FASHION</Text>
            </Link>
          </div>

          <div style={{ display: "flex", flex: 1, justifyContent: "flex-end" }}>
            <Group position="right" spacing="xs">
              {secondaryItems}
            </Group>
          </div>
        </div>

        <Container
          style={{
            display: "flex",
            justifyContent: "space-between", // This ensures there's space between the two main containers
            padding: "0px",
            marginTop: "15px",
            minWidth: "930px",
          }}
        >
          <Container
            style={{
              display: "flex",
              flex: 1,
              padding: "0px",
            }}
          >
            <Group position="left">{active !== null && categoryLinks}</Group>
          </Container>

          <Container
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-end",
              padding: "0px",
              margin: "0px",
            }}
          >
            <Container
              style={{
                display: "flex",
                justifyContent: "flex-end",
                padding: "0px",
                margin: "0px",
              }}
            >
              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  navigate(`/SearchResults?criteria=${form.values.criteria}`);
                }}
              >
                <TextInput
                  variant="unstyled"
                  className={classes.search}
                  placeholder="Search"
                  icon={<IconSearch size="15px" stroke={1.5} />}
                  {...form.getInputProps("criteria")}
                />
              </form>
              <ImageSearch />
            </Container>
            <Divider
              style={{
                width: "210px",
                margin: "0 auto",
              }}
            />
          </Container>
        </Container>
      </Container>
    </Header>
  );
}

export default DoubleHeader;
