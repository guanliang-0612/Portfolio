/* 
 Usecase:
 B11
 B12
*/

import React, { useState } from "react";
import { Menu, createStyles } from "@mantine/core";
import { IconCamera } from "@tabler/icons-react";
import ImageSearchDrop from "./ImageSearchContent";

const useStyles = createStyles((theme) => ({
  iconContainer: {
    position: "relative",
    display: "inline-block",
  },
}));

function ImageSearch() {
  const [imageiconVisible, setimageiconVisible] = useState(false);

  const { classes } = useStyles();

  return (
    <Menu
      key={"imageicon"}
      trigger="click"
      transitionProps={{ exitDuration: 0 }}
      withinPortal
    >
      <Menu.Target>
        <div className={classes.iconContainer}>
          <IconCamera size="20px" stroke={1} style={{ marginTop: "10px" }} />
        </div>
      </Menu.Target>
      <Menu.Dropdown>
        <ImageSearchDrop />
      </Menu.Dropdown>
    </Menu>
  );
}

export default ImageSearch;
