/* eslint-disable react/display-name */
/* 
 Usecase:
 B36
*/
import React, { forwardRef, useState } from "react";
import {
  Menu,
  createStyles,
  ActionIcon,
  UnstyledButton,
  Indicator,
  Container,
  Text,
} from "@mantine/core";
import { IconListSearch } from "@tabler/icons-react";
import { IconBell } from "@tabler/icons-react";
import NotificationContent from "./NotificationContent";
import { useAuth } from "../../contexts/AuthContext";
import useNotifications from "../../hooks/useNotifications";

const useStyles = createStyles((theme) => ({
  /* iconContainer: {
    position: "relative",
    display: "inline-block",
    marginTop: "4px",
  }, */
  notificationIndicator: {
    position: "absolute",
    top: 0,
    right: 0,
    width: "10px", // Adjust as needed
    height: "10px",
    borderRadius: "50%",
    backgroundColor: "red",
  },
}));

function NotificationBell() {
  const [notificationsVisible, setNotificationsVisible] = useState(false);
  const [opened, setOpened] = useState(false);
  const [hasNewNotification, setHasNewNotification] = useState(true); // can set this based on actual data
  const { classes } = useStyles();
  const { currentUser } = useAuth();
  const notifications = useNotifications(currentUser.id);
  const NotificationButton = forwardRef(({ onClick, ...others }, ref) => (
    <ActionIcon
      color="dark"
      ref={ref}
      component={UnstyledButton}
      onClick={(event) => {
        onClick(event);
        setHasNewNotification(false);
      }}
      {...others}
    >
      <Indicator color="red" disabled={!hasNewNotification}>
        <IconBell />
      </Indicator>
      {/* {hasNewNotification && <div className={classes.notificationIndicator} />} */}
    </ActionIcon>
  ));

  return (
    <Menu
      key={"notifications"}
      trigger="click"
      transitionProps={{ exitDuration: 0 }}
      withinPortal
    >
      <Menu.Target>
        <NotificationButton />
      </Menu.Target>
      <Menu.Dropdown>
        {notifications.length > 0 ? (
          <NotificationContent notifications={notifications} />
        ) : (
          <Container
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "200px",
              width: "180px",
            }}
          >
            <IconListSearch size={40} stroke={1.5} />
            <Text size="sm" align="center" weight={450} mt="5px">
              No Notifications
            </Text>
          </Container>
        )}
      </Menu.Dropdown>
    </Menu>
  );
}

export default NotificationBell;
