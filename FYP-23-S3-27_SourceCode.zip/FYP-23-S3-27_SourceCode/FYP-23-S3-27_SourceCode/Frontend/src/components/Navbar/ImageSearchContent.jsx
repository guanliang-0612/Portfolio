/* 
 Usecase:
 B11
 B12
*/

import { Group, Text, useMantineTheme, rem } from "@mantine/core";
import { IconUpload, IconPhoto, IconX } from "@tabler/icons-react";
import { Dropzone, IMAGE_MIME_TYPE } from "@mantine/dropzone";
import { useUploadedImage } from "../../contexts/UploadImageContext";
import { useNavigate } from "react-router-dom";

export default function ImageSearchDrop(props) {
  const theme = useMantineTheme();
  const { setUploadedImage } = useUploadedImage();
  const navigate = useNavigate();

  const handleDrop = (files) => {
    if (files.length > 0) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result);

        // Navigate to the search result page after image is set
        navigate("/ImageSearchResult");
      };
      reader.readAsDataURL(files[0]);
    }
  };
  return (
    <Dropzone
      onDrop={handleDrop}
      onReject={(files) => alert("rejected files", files)}
      accept={IMAGE_MIME_TYPE}
      {...props}
    >
      <Group
        position="center"
        spacing="xl"
        style={{ pointerEvents: "none", maxWidth: "242px" }}
      >
        <Dropzone.Accept>
          <IconUpload
            size="1.5rem"
            stroke={1.5}
            color={
              theme.colors[theme.primaryColor][
                theme.colorScheme === "dark" ? 4 : 6
              ]
            }
          />
        </Dropzone.Accept>
        <Dropzone.Reject>
          <IconX
            size="1.5rem"
            stroke={1.5}
            color={theme.colors.red[theme.colorScheme === "dark" ? 4 : 6]}
          />
        </Dropzone.Reject>
        <Dropzone.Idle>
          <IconPhoto size="1.5rem" stroke={1.5} />
        </Dropzone.Idle>

        <div style={{ marginTop: "-10px", position: "center" }}>
          <Text size="sm" inline ta="center">
            Drag an Image here or click to select Image
          </Text>
          <Text size="xs" color="dimmed" inline mt={7} ta="center">
            Attach a file as you like, each file should not exceed 5mb
          </Text>
        </div>
      </Group>
    </Dropzone>
  );
}
