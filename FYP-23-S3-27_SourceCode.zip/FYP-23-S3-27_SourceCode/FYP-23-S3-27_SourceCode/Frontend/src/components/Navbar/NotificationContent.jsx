/* 
 Usecase:
 B36
*/
import {
  UnstyledButton,
  Group,
  Avatar,
  Text,
  createStyles,
  ScrollArea,
} from "@mantine/core";
import useNotifications from "../../hooks/useNotifications";
import { useAuth } from "../../contexts/AuthContext";

const useStyles = createStyles((theme) => ({
  user: {
    display: "block",
    width: "100%",
    padding: theme.spacing.md,
    color: theme.colorScheme === "dark" ? theme.colors.dark[0] : theme.black,

    "&:hover": {
      backgroundColor:
        theme.colorScheme === "dark"
          ? theme.colors.dark[8]
          : theme.colors.gray[0],
    },
  },
  ellipsisText: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    // textOverflow: "ellipsis",
    maxWidth: "380px", // Adjust this value based on your requirements
  },
}));

const mockUserData = [
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
  {
    listingimg:
      "https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    listingname: "This is a test to test for over flow does the test work ",
    message: "The Listing you liked is sold",
  },
];
export default function NotificationContent({ notifications = [] }) {
  const { classes } = useStyles();

  return (
    <ScrollArea h={350} w={380}>
      {notifications.map((notification) => (
        <UnstyledButton key={notification.id} className={classes.user}>
          <Group>
            <Avatar src={notification.photo_url} />

            <div style={{ flex: 1 }}>
              <Text size="sm" weight={500} className={classes.ellipsisText}>
                {notification.listingName}
              </Text>

              <Text color="dimmed" size="xs" className={classes.ellipsisText}>
                {notification.message}
              </Text>
            </div>
          </Group>
        </UnstyledButton>
      ))}
    </ScrollArea>
  );
}
