import DoubleHeader from "./DoubleHeader";

const Navbar = () => {
  const userLinks = [
    /*  {
      link: "/admin", // Updated this line
      label: "Hello sir",
    }  ,
    {
      "link": "#",
      "label": "Sign Up"
    } , */
  ];

  const genders = [
    {
      link: "/SearchResults?section=Women",
      label: "Women",
    },
    {
      link: "/SearchResults?section=Men",
      label: "Men",
    },
  ];

  const categories = [
    {
      link: "&category=topwear",
      label: "Top",
    },
    {
      link: "&category=outerwear",
      label: "OuterWear",
    },
    {
      link: "&category=bottomwear",
      label: "Bottoms",
    },
    {
      link: "&category=footwear",
      label: "Footwear",
    },
    {
      link: "&category=dress",
      label: "dress",
    },
  ];

  return (
    <DoubleHeader
      userLinks={userLinks}
      categories={categories}
      genders={genders}
    />
  );
};

export default Navbar;
