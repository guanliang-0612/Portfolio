import {
  Anchor,
  Image,
  Button,
  Text,
  rem,
  Skeleton,
  ActionIcon,
} from "@mantine/core";
import { IconHeart, IconHeartFilled } from "@tabler/icons-react";
import { createStyles } from "@mantine/core";
import { AiOutlineHeart } from "react-icons/ai";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { saveIndividualListing } from "../services/listingService";
import { removeSavedListing } from "../services/listingService";
import { isListingSaved } from "../services/listingService";
import { useAuth } from "../contexts/AuthContext";

const useStyles = createStyles((theme) => ({
  link: {
    display: "block",
    textDecoration: "none",
    color: "inherit",
    "&:hover,": {
      textDecoration: "none",
      color: "inherit",
    },
  },

  imageContainer: {
    width: rem(230),
    height: rem(280), // Set a fixed height
    overflow: "hidden", // Ensure images don't spill out
    flexShrink: 0, // Prevents the container from shrinking
  },

  detailsContainer: {
    flexGrow: 0, // Prevent the container from growing
    flexShrink: 1, // Allow the container to shrink if necessary
    overflow: "hidden", // Prevent text or any other content from spilling out
    padding: "5px",
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontWeight: 700,
  },

  item: {
    position: "relative",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start", // Align children to the top
    textAlign: "center",
    borderRadius: 0, // Adjusted for a more rectangular appearance
    overflow: "hidden", // Ensure images don't spill out
    border: "black", // Remove border
    height: rem(380), // Extended height
    padding: rem(10),
    width: rem(220), // Adjusted width
    margin: "0 0.010%", // Adjusted margin to reduce space between cards
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.white,
    transition: "box-shadow 150ms ease",
    "&:hover": {
      boxShadow: theme.shadows.md,
    },
  },

  saveButtonUnclicked: {
    position: "absolute",
    bottom: rem(10),
    right: rem(10),
    color: "black", // Set the color of the heart icon to black
    borderColor: "black", // Set the border color of the button to black
  },

  saveButtonClicked: {
    position: "absolute",
    bottom: rem(10),
    right: rem(10),
    color: "black", // Set the color of the heart icon to white when clicked
    borderColor: "black", // Set the border color of the button to blue when clicked
  },

  productImage: {
    width: rem(150), // Set a fixed width
    height: rem(300), // Set a fixed height for 1:2 proportion
    objectFit: "cover", // Cover the container without spilling out
    marginBottom: rem(10), // Add some margin at the bottom for spacing
    border: "black",
  },

  productDetails: {
    textAlign: "left", // Align details to the left
    width: rem(210), // Ensure the details take up the full width of the card
    paddingLeft: "10px",
    overflow: "hidden", // Hide any overflow
    whiteSpace: "nowrap", // Prevent wrapping to the next line
    textOverflow: "ellipsis", // Add ellipsis for overflow text
  },

  card: {
    backgroundColor: "transparent", // Remove gray background
    border: "none", // Remove border
  },
}));

export default function ListingCard({
  product: {
    id = "",
    image = "",
    name = "",
    price = "",
    condition = "",
    savedBy = [],
  },
}) {
  const { classes } = useStyles();
  const { currentUser } = useAuth();
  const [imgIsLoading, setImgIsLoading] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [buttonClicked, setButtonClicked] = useState(
    currentUser && savedBy.includes(currentUser.id)
  );

  const iconStyle = {
    opacity: 0.8, // Adjust as needed
  };

  const iconSavedStyle = {
    opacity: 1, // Adjust as needed
    color: "#FF8787",
  };

  const handleClick = async (e) => {
    e.preventDefault();
    setButtonClicked((prev) => !prev);
    // Check if the listing is already saved
    const isSaved = await isListingSaved(id, currentUser.id);

    if (isSaved) {
      // If the listing is already saved, remove it
      try {
        const result = await removeSavedListing(id, currentUser.id);
        if (result === true) {
          setButtonClicked(false);
        } else {
          console.error("Error removing the listing");
        }
      } catch (error) {
        console.error("Error removing the listing:", error);
      }
    } else {
      // If the listing is not saved, save it
      try {
        const result = await saveIndividualListing(id, currentUser.id);
        if (result === true) {
          setButtonClicked(true);
        } else {
          console.error("Error saving the listing");
        }
      } catch (error) {
        console.error("Error saving the listing:", error);
      }
    }
  };

  return (
    <div key={id} className={classes.item}>
      <Anchor
        component={Link}
        to={`/listing/${id}`}
        className={classes.link} // Apply the link class
      >
        <div className={classes.imageContainer}>
          <Skeleton visible={imgIsLoading}>
            <Image
              src={image}
              alt={name}
              className={classes.productImage}
              imageProps={{ onLoad: () => setImgIsLoading(false) }}
            />
          </Skeleton>
        </div>
        <div className={classes.detailsContainer}>
          <div className={classes.productDetails}>
            <Text size="sm" fw={500} mt={7}>
              {name}
            </Text>
            <Text size="sm" mt={7}>
              S${parseFloat(price).toFixed(2)}
            </Text>
            <Text size="xs" mt={7}>
              {condition}
            </Text>
          </div>
          <ActionIcon
            className={
              buttonClicked
                ? classes.saveButtonClicked
                : classes.saveButtonUnclicked
            }
            variant="transparent"
            size="lg"
            onClick={handleClick}
          >
            {buttonClicked ? (
              <IconHeartFilled style={iconSavedStyle} />
            ) : (
              <IconHeart style={iconStyle} strokeWidth="1.5" />
            )}
          </ActionIcon>
        </div>
      </Anchor>
    </div>
  );
}
