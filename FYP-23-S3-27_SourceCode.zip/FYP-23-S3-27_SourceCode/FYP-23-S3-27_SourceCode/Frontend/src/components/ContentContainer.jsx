import { Container, createStyles, rem } from "@mantine/core";

const useStyles = createStyles((theme) => ({
  wrapper: {
    position: "relative",
    boxSizing: "border-box",
    backgroundColor:
      theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.white,
    borderRadius: "8px",
    border: `1px solid ${
      theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[2]
    }`,

    overflow: "hidden",
    height: "1080px",
    // display: "flex", // Use flex display
    // flexDirection: "column", // Column layout to expand vertically
  },

  header: {
    width: "100%", // This ensures it takes the full width of the wrapper
    height: "5%", // Set the height to be 8% of the wrapper
    backgroundColor: "rgba(0, 0, 0, 1)",
  },

  body: { height: "95%" },
}));

function Header({ children }) {
  const { classes } = useStyles();
  return (
    <Container className={classes.header} p={0}>
      {children}
    </Container>
  );
}

function Body({ children }) {
  const { classes } = useStyles();
  return (
    <Container className={classes.body} p={0}>
      {children}
    </Container>
  );
}

function ContentContainer({ children }) {
  const { classes } = useStyles();
  return (
    <Container className={classes.wrapper} p={0}>
      {children}
    </Container>
  );
}

ContentContainer.Header = Header;
ContentContainer.Body = Body;

export default ContentContainer;
