import { useEffect, useMemo, useState, createContext, useContext } from "react";
import { db, functions } from "../libs/firebase";
import {
  doc,
  orderBy,
  collection,
  onSnapshot,
  addDoc,
  query,
  serverTimestamp,
  limit,
  setDoc,
  where,
  or,
} from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { useAuth } from "./AuthContext";
import { getUserDetails } from "../services/authService";
import { getListing } from "../services/listingService";

const ChatRoomsContext = createContext();

// Create a custom hook to use the auth context
export function useChatRooms() {
  const {
    chatRooms,
    createChatRoom,
    getChatRoomInfo,
    getChatRoomIdIfExists,
    deleteChatRoom,
    isLoading,
  } = useContext(ChatRoomsContext);
  return {
    chatRooms,
    createChatRoom,
    getChatRoomInfo,
    getChatRoomIdIfExists,
    deleteChatRoom,
    isLoading,
  };
}

export function ChatRoomsProvider({ children }) {
  const { currentUser } = useAuth();
  const chatRoomsRef = useMemo(
    () =>
      currentUser?.id
        ? query(
            collection(db, "chatRooms"),
            or(
              where("sellerId", "==", currentUser?.id),
              where("buyerId", "==", currentUser?.id)
            ),
            orderBy("lastUpdated", "desc")
          )
        : null,
    [currentUser]
  );
  /*
  {
    lastUpdated: new Date(),
    sellerId,
    buyerId: currentUser.id,
    listingId,
  } */
  const [chatRooms, setChatRooms] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    try {
      if (!chatRoomsRef) return;
      const unsubscribe = onSnapshot(chatRoomsRef, async (snapshot) => {
        if (snapshot.empty) {
          setIsLoading(true);
          setChatRooms([]);
          return () => unsubscribe();
        }

        const newChatRooms = await Promise.all(
          snapshot.docs.map(async (doc) => {
            const data = doc.data();

            /* const [buyerDetails, sellerDetails, listingDetails] =
              await Promise.all([
                getUserDetails(data.buyerId),
                getUserDetails(data.sellerId),
                getListing(data.listingId),
              ]); */
            return {
              id: doc.id,
              /*  buyerName: `${buyerDetails.dname}`,
              buyerImage: buyerDetails.imageUrl,
              buyerId: data.buyerId,
              sellerName: `${sellerDetails.dname}`,
              sellerImage: sellerDetails.imageUrl,
              sellerId: `${sellerDetails.id}`,
              listingName: listingDetails.name,
              listingStatus: listingDetails.status,
              listingPrice: listingDetails.price,
              listingImage: listingDetails.imageUrls[0],
              listingId: listingDetails.id,
              lastUpdated: doc.data().lastUpdated.toDate(), */
              ...doc.data(),
            };
          })
        );
        setIsLoading(true);
        setChatRooms(newChatRooms);
      });

      return () => unsubscribe();
    } catch (err) {}
  }, [chatRoomsRef]);

  useEffect(() => {
    setIsLoading(false);
  }, [chatRooms]);

  function getChatRoomIdIfExists(sellerId, listingId) {
    const result = chatRooms.find(
      (chatRoom) =>
        chatRoom.sellerId === sellerId &&
        chatRoom.listingId === listingId &&
        chatRoom.buyerId === currentUser.id
    );
    return result?.id;
  }

  function getChatRoomInfo(roomId) {
    const result = chatRooms.find((chatRoom) => chatRoom.id === roomId);
    return result;
  }

  function createChatRoom(sellerId, listingId) {
    try {
      // Optimistically render message before it is saved to firestore to improve responsiveness
      setIsLoading(true);
      const newChatRoomRef = doc(collection(db, "chatRooms"));
      setChatRooms([
        {
          lastUpdated: new Date(),
          sellerId,
          buyerId: currentUser.id,
          listingId,
          id: newChatRoomRef.id,
        },
        ...chatRooms,
      ]);
      setDoc(newChatRoomRef, {
        lastUpdated: new Date(),
        sellerId,
        buyerId: currentUser.id,
        listingId,
      });
      Promise.all([
        getUserDetails(currentUser.id),
        getUserDetails(sellerId),
        getListing(listingId),
      ]).then((results) => {
        const [buyerDetails, sellerDetails, listingDetails] = results;
        setDoc(newChatRoomRef, {
          lastUpdated: new Date(),
          buyerName: `${buyerDetails.dname}`,
          buyerImage: buyerDetails.imageUrl,
          buyerId: currentUser.id,
          sellerName: `${sellerDetails.dname}`,
          sellerImage: sellerDetails.imageUrl,
          sellerId,
          listingName: listingDetails.name,
          listingStatus: listingDetails.status,
          listingPrice: listingDetails.price,
          listingImage: listingDetails.imageUrls[0],
          listingId,
        });
      });

      return newChatRoomRef.id;
    } catch (err) {
      console.error("Error sending message: ", err);
    }
  }

  async function deleteChatRoom(id) {
    setIsLoading(true);
    const recursiveDelete = httpsCallable(functions, "deleteChatRoom");
    await recursiveDelete({ chatRoomId: id });
    return "Delete successful";
  }
  const value = {
    chatRooms,
    createChatRoom,
    getChatRoomInfo,
    getChatRoomIdIfExists,
    deleteChatRoom,
    isLoading,
  };
  return (
    <ChatRoomsContext.Provider value={value}>
      {children}
    </ChatRoomsContext.Provider>
  );
}
