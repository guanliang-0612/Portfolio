import React, { useState, useEffect, createContext, useContext } from "react";
import { auth, db } from "../libs/firebase";
import { doc, onSnapshot } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { getUserDetails } from "../services/authService";
// Create a context
const AuthContext = createContext();

// Create a custom hook to use the auth context
export function useAuth() {
  const { currentUser, userIsLoading } = useContext(AuthContext);
  return { currentUser, userIsLoading };
}

// Create a provider component
export function AuthProvider({ children }) {
  const [authStatus, setAuthStatus] = useState("checking");
  const [id, setId] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  /* {
    id: "",
    dname: "",
    fname: "",
    lname: "",
    birthday: new Date(),
    gender: "",
    role: "",
    email: "",
  } */
  const [userIsLoading, setUserIsLoading] = useState(true);
  // Listen to onAuthStateChanged
  useEffect(() => {
    const unsubscribeFromAuth = onAuthStateChanged(auth, async (user) => {
      setUserIsLoading(true);
      if (user) {
        setId(user.uid);
        setAuthStatus("logged in");
      } else {
        setId(null);
        setAuthStatus("logged out");
      }
    });

    // Cleanup subscription on unmount
    return unsubscribeFromAuth;
  }, []);

  useEffect(() => {
    if (authStatus === "checking") return;
    if (authStatus === "logged out") {
      setCurrentUser(null);
      setUserIsLoading(false);
      return;
    }
    const unsubscribeFromFirestore = onSnapshot(
      doc(db, "accountDetails", id),
      (doc) => {
        if (doc.exists()) {
          if (doc.data().role === "customer") {
            const { birthday, ...userData } = doc.data();
            setCurrentUser({
              id,
              birthday: birthday?.toDate(),
              ...userData,
            });
          } else {
            const userData = doc.data();
            setCurrentUser({
              id,
              ...userData,
            });
          }
          // If the document exists, update the user data
        } else {
          // If the document does not exist, set user to null
          setCurrentUser(null);
        }
        setUserIsLoading(false);
      }
    );
    return unsubscribeFromFirestore;
  }, [authStatus, id]);

  /* useEffect(() => {}, [currentUser]); */

  const value = {
    currentUser,
    userIsLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
