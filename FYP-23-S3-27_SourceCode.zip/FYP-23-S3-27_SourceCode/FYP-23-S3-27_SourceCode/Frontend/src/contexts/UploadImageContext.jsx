/* 
 Usecase:
 B11
*/
import React, { createContext, useContext, useState } from "react";

const UploadedImageContext = createContext();

export function useUploadedImage() {
  const context = useContext(UploadedImageContext);
  if (!context) {
    throw new Error(
      "useUploadedImage must be used within a UploadedImageProvider"
    );
  }
  return context;
}

export function UploadedImageProvider(props) {
  const [uploadedImage, setUploadedImage] = useState(null);
  const value = { uploadedImage, setUploadedImage };

  return <UploadedImageContext.Provider value={value} {...props} />;
}
