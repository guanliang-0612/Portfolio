import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import { MantineProvider } from "@mantine/core";
import { BrowserRouter as Router } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext.jsx";
import ScrollToTop from "./components/ScrollToTop.jsx";
import { UploadedImageProvider } from "./contexts/UploadImageContext.jsx";
import { ChatRoomsProvider } from "./contexts/ChatRoomsContext.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider>
      <ChatRoomsProvider>
        <MantineProvider withGlobalStyles withNormalizeCSS>
          <Router>
            <ScrollToTop />
            <UploadedImageProvider>
              <App />
            </UploadedImageProvider>
          </Router>
        </MantineProvider>
      </ChatRoomsProvider>
    </AuthProvider>
  </React.StrictMode>
);
