/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable object-curly-spacing */
/* eslint-disable comma-dangle */
/* eslint-disable max-len */
/* eslint-disable indent */
/* eslint-disable require-jsdoc */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { Timestamp } = require("firebase-admin/firestore");
const axios = require("axios");
/* const { getStorage } = require("firebase-admin/storage"); */
admin.initializeApp();
const db = admin.firestore();
const bucket = admin.storage().bucket();
const auth = admin.auth();

exports.detectStatusChange = functions.firestore
  .document("listings/{listingId}")
  .onUpdate((change, context) => {
    const newValue = change.after.data();
    const previousValue = change.before.data();

    if (
      newValue.status !== previousValue.status &&
      (newValue.status === "unavailable" || newValue.status === "reserved")
    ) {
      const promises = [];
      newValue.savedBy.forEach((userId) => {
        const p = db
          .collection("accountDetails")
          .doc(userId)
          .collection("notifications")
          .add({
            listingId: context.params.listingId,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            message: `The listing you saved has been marked as ${newValue.status}`,
            listingName: newValue.name,
            photo_url: newValue.imageUrls[0],
            read: false,
          });
        promises.push(p);
      });
      return Promise.all(promises);
    } else {
      return null;
    }
  });

async function deleteImage(imageUrl) {
  const fileName = decodeURIComponent(imageUrl.split("/").pop().split("?")[0]);
  // Get the file name from the image URL

  // Specify the bucket name if it's different from your Firebase project ID
  await bucket.file(fileName).delete();
  console.log(`Successfully deleted image ${fileName} from Firebase Storage.`);
  // Delete the file from Firebase Storage
  return;
}

exports.deleteUnusedImages = functions.firestore
  .document("accountDetails/{accountId}")
  .onUpdate((change, context) => {
    const before = change.before.data();
    const after = change.after.data();

    const oldUrl = before.imageUrl;
    const newUrl = after.imageUrl;

    // Get all the old URLs that are not in the new array
    if (oldUrl === newUrl) return;

    // Delete each unused image

    return deleteImage(oldUrl);
  });

exports.deleteOldProfileImage = functions.firestore
  .document("accountDetails/{accountId}")
  .onUpdate((change, context) => {
    const before = change.before.data();
    const after = change.after.data();

    const oldUrl = before.imageUrl;
    const newUrl = after.imageUrl;

    // Get all the old URLs that are not in the new array
    if (oldUrl === newUrl) return;

    // Delete each unused image

    return deleteImage(oldUrl);
  });

exports.CreateEmbeddingsForNewListing = functions.firestore
  .document("listings/{listingId}")
  .onCreate((snap, context) => {
    try {
      const listingData = snap.data();

      const urls = listingData.imageUrls;
      return updateEmbeddings(context.params.listingId, urls[0]);
    } catch (error) {
      console.error("Error updating embeddings", error);
      throw new functions.https.HttpsError(error.code, error.message);
    }
  });

exports.listingUpdateCleanup = functions.firestore
  .document("listings/{listingId}")
  .onUpdate((change, context) => {
    const before = change.before.data();
    const after = change.after.data();

    const oldUrls = before.imageUrls;
    const newUrls = after.imageUrls;

    // Get all the old URLs that are not in the new array
    const urlsToDelete = oldUrls.filter((url) => !newUrls.includes(url));
    // Delete each unused image
    const deletePromises = urlsToDelete.map(
      async (url) => await deleteImage(url)
    );

    if (oldUrls[0] !== newUrls[0]) {
      const updatePromise = updateEmbeddings(
        context.params.listingId,
        newUrls[0]
      );
      return Promise.all([updatePromise, ...deletePromises]);
    }

    return Promise.all(deletePromises);
  });

exports.updateDenormalizedData = functions.firestore
  .document("listings/{listingId}")
  .onUpdate(async (change, context) => {
    const after = change.after.data();
    const before = change.before.data();

    // Check if the fields that we care about have changed
    if (
      after.name === before.name &&
      after.price === before.price &&
      after.imageUrls[0] === before.imageUrls[0] &&
      after.status === before.status
    ) {
      return null;
    }

    // Get the listing id
    const listingId = context.params.listingId;

    // Define the new data
    const newData = {
      listingName: after.name,
      listingPrice: after.price,
      listingImage: after.imageUrls[0],
      listingStatus: after.status,
    };

    // Update the denormalized data in the chatrooms collections
    // Reviews are not updated as they represent the product sold at the time, so the listingName should stay the same
    const batch = admin.firestore().batch();

    const chatroomsSnapshot = await admin
      .firestore()
      .collection("chatRooms")
      .where("listingId", "==", listingId)
      .get();
    chatroomsSnapshot.docs.forEach((doc) => {
      batch.update(doc.ref, {
        listingName: newData.listingName,
        listingPrice: newData.listingPrice,
        listingImage: newData.listingImage,
        listingStatus: newData.listingStatus,
      });
    });

    return batch.commit();
  });

async function updateEmbeddings(id, imageUrl) {
  return axios.post(
    "https://backend-o3eyyr46pq-de.a.run.app/listing/updateembeddings",
    {
      id,
      imageUrl,
    }
  );
}

exports.deleteAllListingImages = functions.firestore
  .document("listings/{listingId}")
  .onDelete((snap, context) => {
    const data = snap.data();
    const urlsToDelete = data.imageUrls;

    // Delete all images linked to the listing
    const deletePromises = urlsToDelete.map(
      async (url) => await deleteImage(url)
    );

    return Promise.all(deletePromises);
  });

exports.deleteChatRoom = functions.https.onCall(async (data, context) => {
  // Check if the user is authenticated
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "You must be logged in to delete a chat room."
    );
  }
  // Get the chatRoom document ID from the data
  const chatRoomId = data.chatRoomId;
  if (!chatRoomId) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "You must provide a chat room ID."
    );
  }
  // Get the chatRoom document reference
  const chatRoomRef = admin.firestore().collection("chatRooms").doc(chatRoomId);
  const chatRoomDoc = await chatRoomRef.get();
  // Check if the chatRoom document exists and if the user is the seller or the buyer
  if (!chatRoomDoc.exists) {
    throw new functions.https.HttpsError(
      "not-found",
      "The chat room does not exist."
    );
  }
  const chatRoomData = chatRoomDoc.data();
  const userId = context.auth.uid;
  if (chatRoomData.sellerId !== userId && chatRoomData.buyerId !== userId) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "You do not have permission to delete this chat room."
    );
  }
  try {
    // Use the firestore.recursiveDelete function to delete the chatRoom document and its subcollections
    await db.recursiveDelete(chatRoomRef);
    return { message: "Chat room deleted successfully." };
  } catch (error) {
    throw new functions.https.HttpsError(
      "delete-failure",
      "Chat room deletion failed."
    );
  }
});

// Define the function trigger
exports.updateLastUpdated = functions.firestore
  .document("chatRooms/{chatroomId}/messages/{messageId}")
  .onCreate(async (snap, context) => {
    // Get the chatroom document reference
    const chatroomRef = snap.ref.parent.parent;
    // Get the server timestamp
    const timestamp = admin.firestore.FieldValue.serverTimestamp();
    // Update the lastUpdated field of the chatroom document
    return chatroomRef.update({ lastUpdated: timestamp });
  });

async function addNotification(userId, notification) {
  // Get a reference to the accountDetails document with the sellerId
  const accountRef = db.collection("accountDetails").doc(userId);

  // Add the notification to the notifications subcollection
  await accountRef.collection("notifications").add(notification);
}

exports.onOfferCreate = functions.firestore
  .document("offers/{offerId}")
  .onCreate(async (snap, context) => {
    const offerData = snap.data();
    const { listingId, buyerId, sellerId, amount } = offerData;
    const listingDoc = await db.collection("listings").doc(listingId).get();
    const listingData = listingDoc.data();
    // Find the chatroom where the listingId and sellerId match the offer's
    const chatroomsSnapshot = await admin
      .firestore()
      .collection("chatRooms")
      .where("listingId", "==", listingId)
      .where("buyerId", "==", buyerId)
      .get();

    // If no matching chatroom is found, log an error and exit
    if (chatroomsSnapshot.empty) {
      console.error(
        `No matching chatroom found for listingId: ${listingId} and sellerId: ${sellerId}`
      );
      return;
    }

    // Get the first matching chatroom
    const chatroom = chatroomsSnapshot.docs[0];

    // Add a new message to the chatroom's messages subcollection
    await chatroom.ref.collection("messages").add({
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      text: `Offer of $${amount.toFixed(2)} has been sent.`,
      senderId: buyerId,
    });

    await addNotification(sellerId, {
      message: `Someone made an offer of $${amount.toFixed(
        2
      )} for your listing.`,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      read: false,
      listingId: listingId,
      listingName: listingData.name,
      userId: buyerId,
      photo_url: listingData.imageUrls[0],
      // ...other fields...
    });
  });

exports.onOfferUpdate = functions.firestore
  .document("offers/{offerId}")
  .onUpdate(async (change, context) => {
    const offerBefore = change.before.data();
    const offerAfter = change.after.data();
    if (offerBefore.status === offerAfter.status) {
      return console.log("Status is not updated");
    }
    const { listingId, buyerId, sellerId, amount } = offerAfter;
    const listingDoc = await db.collection("listings").doc(listingId).get();
    const listingData = listingDoc.data();
    if (offerAfter.status === "cancelled") {
      // Find the chatroom where the listingId and sellerId match the offer's
      const chatroomsSnapshot = await admin
        .firestore()
        .collection("chatRooms")
        .where("listingId", "==", listingId)
        .where("buyerId", "==", buyerId)
        .get();

      // If no matching chatroom is found, log an error and exit
      if (chatroomsSnapshot.empty) {
        console.error(
          `No matching chatroom found for listingId: ${listingId} and sellerId: ${sellerId}`
        );
        return;
      }

      // Get the first matching chatroom
      const chatroom = chatroomsSnapshot.docs[0];

      // Add a new message to the chatroom's messages subcollection
      await chatroom.ref.collection("messages").add({
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        text: `Offer of $${amount.toFixed(2)} has been cancelled.`,
        senderId: buyerId,
      });

      await addNotification(sellerId, {
        message: `An offer of $${amount.toFixed(
          2
        )} for your listing has been cancelled.`,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        read: false,
        listingId: listingId,
        listingName: listingData.name,
        userId: buyerId,
        imageUrl: listingData.imageUrls[0],
        // ...other fields...
      });
    }
    if (offerAfter.status === "accepted" || offerAfter.status === "rejected") {
      // Check if the offer status has been updated to 'accepted' or 'rejected'

      // Find the chatroom where the listingId and buyerId match the offer's
      const chatroomsSnapshot = await db
        .collection("chatRooms")
        .where("listingId", "==", listingId)
        .where("buyerId", "==", buyerId)
        .get();

      // If no matching chatroom is found, log an error and exit
      if (chatroomsSnapshot.empty) {
        console.error(
          `No matching chatroom found for listingId: ${listingId} and buyerId: ${buyerId}`
        );
        return;
      }

      // Get the first matching chatroom
      const chatroom = chatroomsSnapshot.docs[0];

      // Add a new message to the chatroom's messages subcollection
      await chatroom.ref.collection("messages").add({
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        text: `Offer of $${amount.toFixed(2)} has been ${
          offerAfter.status === "accepted" ? "accepted" : "rejected"
        }`,
        senderId: sellerId,
      });

      await addNotification(buyerId, {
        message: `Your offer of $${amount.toFixed(2)} has been ${
          offerAfter.status === "accepted" ? "accepted" : "rejected"
        }`,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        read: false,
        listingId: listingId,
        listingName: listingData.name,
        userId: sellerId,
        photo_url: listingData.imageUrls[0],
        // ...other fields...
      });
    }
  });

// This function is triggered when a user account is deleted
// This function is triggered when a user account is deleted
exports.onUserDelete = functions.auth.user().onDelete(async (user) => {
  // Get the user id
  const uid = user.uid;

  // Get a batch to perform multiple updates atomically
  const batch = db.batch();

  // Query all the listings where the sellerId is equal to the user id
  const listingsQuery = db.collection("listings").where("sellerId", "==", uid);

  // Get the query snapshot
  const listingsSnapshot = await listingsQuery.get();

  // Update each listing document to set the status to 'unavailable'
  listingsSnapshot.forEach((doc) => {
    batch.update(doc.ref, { status: "unavailable" });
  });

  // Query the accountDetails document for the user
  const accountDetailsQuery = db.collection("accountDetails").doc(uid);

  // Get the document snapshot
  const accountDetailsSnapshot = await accountDetailsQuery.get();
  if (accountDetailsSnapshot.exists) {
    // Get the imageUrl from the document data
    const imageUrl = accountDetailsSnapshot.data().imageUrl;
    if (imageUrl) {
      // Parse the file name from the download URL
      await deleteImage(imageUrl);
    }

    // Update the accountDetails document to set the status to 'deleted' and other fields to empty values
    batch.update(accountDetailsQuery, {
      status: "deleted",
      imageUrl: "",
      dname: "Deleted user",
      email: "not available",
      fname: "",
      lname: "",
      gender: "",
      birthday: null,
    });
  }

  const sellerOffersQuery = db
    .collection("offers")
    .where("sellerId", "==", uid);
  const buyerOffersQuery = db.collection("offers").where("buyerId", "==", uid);
  // Query all the offers where the sellerId or the buyerId is equal to the user id
  // Get the documents from the queries
  const [sellerOffers, buyerOffers] = await Promise.all([
    sellerOffersQuery.get(),
    buyerOffersQuery.get(),
  ]);
  sellerOffers.forEach((doc) => {
    batch.update(doc.ref, { status: "rejected" });
  });
  buyerOffers.forEach((doc) => {
    batch.update(doc.ref, { status: "cancelled" });
  });

  /*   // Get the query snapshot
  const offersSnapshot = await offersQuery.get();

  // Update each offer document to set the status to 'rejected' or 'cancelled' depending on the role of the user
  offersSnapshot.forEach((doc) => {
    const offerData = doc.data();
    if (offerData.sellerId === uid) {
      batch.update(doc.ref, { status: "rejected" });
    } else if (offerData.buyerId === uid) {
      batch.update(doc.ref, { status: "cancelled" });
    }
  }); */

  // Commit the batch
  await batch.commit();

  // Log the success message
  console.log("User deletion handled successfully");
});

exports.onChatRoomCreate = functions.firestore
  .document("chatRooms/{chatRoomId}")
  .onCreate(async (snap, context) => {
    const chatRoom = snap.data();
    const { sellerId } = chatRoom;

    // Get a reference to the accountDetails document with the sellerId
    const accountRef = admin
      .firestore()
      .collection("autoReplies")
      .doc(sellerId);

    // Check if the accountDetails document has an autoReply document in the autoReply subcollection
    const autoReplyDoc = await accountRef.get();

    // If an active autoReply document is found, add a new message to the chatRoom's messages subcollection
    if (autoReplyDoc.exists) {
      const autoReply = autoReplyDoc.data();

      await snap.ref.collection("messages").add({
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        senderId: sellerId,
        text: autoReply.message,
      });
    }
  });

// TODO When user/listing updates
/* exports.onUserUpdate = functions.firestore
  .document("accountDetails/{listingId}")
  .onUpdate(async (change, context) => {
    const { collection, docId } = context.params;
    const newData = change.after.data();

    // Check if the updated document is a user or a listing
    if (collection === "users" || collection === "listings") {
      // Define the field to update based on the collection
      const fieldToUpdate =
        collection === "users"
          ? newData.isSeller
            ? "sellerId"
            : "buyerId"
          : "listingId";

      // Get all chatRooms where the fieldToUpdate matches the docId
      const chatRoomsSnapshot = await admin
        .firestore()
        .collection("chatRooms")
        .where(fieldToUpdate, "==", docId)
        .get();

      // Update each matching chatRoom
      const updates = chatRoomsSnapshot.docs.map((doc) => {
        const chatRoomRef = doc.ref;

        // Define the fields to update in the chatRoom
        const fieldsToUpdate = {
          sellerName: newData.sellerName,
          sellerImage: newData.sellerImage,
          buyerName: newData.buyerName,
          buyerImage: newData.buyerImage,
          listingImage: newData.listingImage,
          listingName: newData.listingName,
          listingPrice: newData.listingPrice,
        };

        // Remove undefined fields
        Object.keys(fieldsToUpdate).forEach((key) => {
          if (typeof fieldsToUpdate[key] === "undefined") {
            delete fieldsToUpdate[key];
          }
        });

        // Update the chatRoom
        return chatRoomRef.update(fieldsToUpdate);
      });

      // Wait for all updates to complete
      await Promise.all(updates);
    }
  });

exports.onUserOrListingUpdate = functions.firestore
  .document("listings/{listingId}")
  .onUpdate(async (change, context) => {
    const docId = context.params;
    const newData = change.after.data();

    // Check if the updated document is a user or a listing
    if (collection === "users" || collection === "listings") {
      // Define the field to update based on the collection
      const fieldToUpdate =
        collection === "users"
          ? newData.isSeller
            ? "sellerId"
            : "buyerId"
          : "listingId";

      // Get all chatRooms where the fieldToUpdate matches the docId
      const chatRoomsSnapshot = await admin
        .firestore()
        .collection("chatRooms")
        .where(fieldToUpdate, "==", docId)
        .get();
      const sellerSnapshot = await admin
        .firestore()
        .collection("chatRooms")
        .where("sellerId", "==", docId)
        .get();

      // Update each matching chatRoom
      const updates = chatRoomsSnapshot.docs.map((doc) => {
        const chatRoomRef = doc.ref;

        // Define the fields to update in the chatRoom
        const fieldsToUpdate = {
          sellerName: newData.sellerName,
          sellerImage: newData.sellerImage,
          buyerName: newData.buyerName,
          buyerImage: newData.buyerImage,
          listingImage: newData.listingImage,
          listingName: newData.listingName,
          listingPrice: newData.listingPrice,
        };

        // Remove undefined fields
        Object.keys(fieldsToUpdate).forEach((key) => {
          if (typeof fieldsToUpdate[key] === "undefined") {
            delete fieldsToUpdate[key];
          }
        });

        // Update the chatRoom
        return chatRoomRef.update(fieldsToUpdate);
      });

      // Wait for all updates to complete
      await Promise.all(updates);
    }
  });
 */

exports.adminEditUser = functions.https.onCall(async (data, context) => {
  try {
    // Check if the user is authenticated
    if (!context.auth) {
      const error = new Error(
        "The function must be called while authenticated."
      );
      error.code = "unauthenticated";
      throw error;
    }

    const { userId, detailsToUpdate } = data;
    const { email, role, birthday, gender, ...accountDetails } =
      detailsToUpdate;
    // Get the role of the current user
    const doc = await db
      .collection("accountDetails")
      .doc(context.auth.uid)
      .get();
    const user = doc.data();

    if (user.role !== "admin") {
      const error = new Error("The function must be called by an admin.");
      error.code = "permission-denied";
      throw error;
    }
    // Update the email and password
    if (email) {
      await auth.updateUser(userId, { email });
    }
    if (role === "customer") {
      // Update the account details
      await db
        .collection("accountDetails")
        .doc(userId)
        .update({
          ...accountDetails,
          birthday: Timestamp.fromDate(new Date(birthday)),
          gender,
        });
    } else {
      await db
        .collection("accountDetails")
        .doc(userId)
        .update({
          ...accountDetails,
        });
    }

    return { message: "User details updated successfully." };
  } catch (error) {
    console.error("Error updating user details:", error);
    throw new functions.https.HttpsError(error.code, error.message);
  }
});

exports.createStaff = functions.https.onCall(async (data, context) => {
  const { email, password, ...accountDetails } = data;

  try {
    if (!context.auth) {
      const error = new Error(
        "The function must be called while authenticated."
      );
      error.code = "unauthenticated";
      throw error;
    }

    // Get the role of the current user
    const doc = await db
      .collection("accountDetails")
      .doc(context.auth.uid)
      .get();
    const user = doc.data();

    if (user.role !== "admin") {
      const error = new Error("The function must be called by an admin.");
      error.code = "permission-denied";
      throw error;
    }
    // Create the user using the provided email and password
    const userRecord = await auth.createUser({ email, password });

    // Save the account details in Firestore
    const accountDetailsRef = db.collection("accountDetails");
    await accountDetailsRef
      .doc(userRecord.uid)
      .set({ email, ...accountDetails });

    return { message: "User created successfully" };
  } catch (error) {
    console.error("Error creating user:", error);
    throw new functions.https.HttpsError(error.code, error.message);
  }
});

async function buildEmbeddings() {
  return await axios.post(
    "https://backend-o3eyyr46pq-de.a.run.app/listing/buildembeddings"
  );
}

async function buildRecommender() {
  return await axios.post(
    "https://backend-o3eyyr46pq-de.a.run.app/listing/trainrecommender"
  );
}

exports.scheduledFunction = functions.pubsub
  .schedule("every 1 hours")
  .onRun((context) => {
    console.log("This will be run every hour!");
    return Promise.all([buildEmbeddings(), buildRecommender()]);
  });

exports.adminDeleteUser = functions.https.onCall(async (data, context) => {
  // Get the target user id
  const targetUserId = data.id;

  // Check if the function is called by an authenticated user
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "You must be signed in to call this function."
    );
  }

  // Get the role of the caller
  const callerId = context.auth.uid;
  const callerAccountDetails = await db
    .collection("accountDetails")
    .doc(callerId)
    .get();
  const callerRole = callerAccountDetails.data().role;

  // Check if the caller is an admin
  if (callerRole !== "admin") {
    throw new functions.https.HttpsError(
      "permission-denied",
      "You must be an admin to call this function."
    );
  }

  // If the caller is an admin, delete the target user account
  await auth.deleteUser(targetUserId);

  return { success: true };
});
